# Campus Relay

Independent issue-reporting prototype with a working browser-local public demonstration.

## Explore

Create a fictional report, filter by category, simulate acceptance and progress, propose a fix, confirm it, reopen it, and refresh to check persistence. All demo records remain in localStorage on the visitor's device. No photos, GPS, names or contact details are requested. No responder receives a report.

## Run

Node.js 22+. `npm ci`, `npm run build`, then `npm run dev -- --port 5181`. Open http://localhost:5181.

## Production service source

The API, database schema and role-aware status logic are retained as prototype source. Production requires a configured database/storage, authentication, responder permissions, real responder partners, privacy and operational review. The demo does not claim to provide those services.

Build, lint and TypeScript checks passed. The browser workflow through confirmation and persistence was verified. Public deployment is pending.
