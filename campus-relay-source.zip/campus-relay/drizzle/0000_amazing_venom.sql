CREATE TABLE `events` (
	`id` text PRIMARY KEY NOT NULL,
	`report_id` text NOT NULL,
	`actor` text NOT NULL,
	`kind` text NOT NULL,
	`note` text NOT NULL,
	`photo` text,
	`created` integer NOT NULL,
	FOREIGN KEY (`report_id`) REFERENCES `reports`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `idx_events_report_created` ON `events` (`report_id`,`created`);--> statement-breakpoint
CREATE INDEX `idx_events_actor_created` ON `events` (`actor`,`created`);--> statement-breakpoint
CREATE TABLE `reports` (
	`id` text PRIMARY KEY NOT NULL,
	`title` text NOT NULL,
	`description` text NOT NULL,
	`category` text NOT NULL,
	`location` text NOT NULL,
	`lat` real NOT NULL,
	`lng` real NOT NULL,
	`photo` text NOT NULL,
	`reporter` text NOT NULL,
	`status` text DEFAULT 'Reported' NOT NULL,
	`team` text,
	`assignee` text,
	`priority` text DEFAULT 'Routine' NOT NULL,
	`created` integer NOT NULL,
	`updated` integer NOT NULL,
	`version` integer DEFAULT 1 NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_reports_category_status` ON `reports` (`category`,`status`);--> statement-breakpoint
CREATE INDEX `idx_reports_created` ON `reports` (`created`);--> statement-breakpoint
CREATE INDEX `idx_reports_reporter_created` ON `reports` (`reporter`,`created`);--> statement-breakpoint
CREATE TABLE `supports` (
	`report_id` text NOT NULL,
	`user_id` text NOT NULL,
	`created` integer NOT NULL,
	PRIMARY KEY(`report_id`, `user_id`),
	FOREIGN KEY (`report_id`) REFERENCES `reports`(`id`) ON UPDATE no action ON DELETE no action
);
