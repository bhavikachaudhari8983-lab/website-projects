export const categories = ['Lighting','Waste','Water','Paths & roads','Accessibility','Other'] as const;
export const statuses = ['Reported','Accepted','In progress','Fix proposed','Confirmed fixed','Reopened','Referred'] as const;
export const teams = ['Electrical','Grounds','Plumbing','Access & maintenance'] as const;
export function distanceMeters(a:number,b:number,c:number,d:number){const r=Math.PI/180;const x=Math.sin((c-a)*r/2)**2+Math.cos(a*r)*Math.cos(c*r)*Math.sin((d-b)*r/2)**2;return 6371000*2*Math.atan2(Math.sqrt(x),Math.sqrt(Math.max(0,1-x)))}
export function coordinates(lat:unknown,lng:unknown){if(lat===''||lng===''||lat==null||lng==null)throw new Error('Enter both latitude and longitude.');const a=Number(lat),b=Number(lng);if(!Number.isFinite(a)||!Number.isFinite(b)||Math.abs(a)>90||Math.abs(b)>180)throw new Error('Enter a valid latitude and longitude.');return [a,b] as const}
export function textField(v:unknown,min:number,max:number,label:string){if(typeof v!=='string'||v.trim().length<min||v.trim().length>max)throw new Error(`${label} must be ${min}–${max} characters.`);return v.trim()}
export function nextStatus(action:string,status:string,responder:boolean,reporter:boolean){
 const rules:Record<string,{from:string[],to:string,allowed:boolean}>={accept:{from:['Reported','Reopened','Referred'],to:'Accepted',allowed:responder},start:{from:['Accepted'],to:'In progress',allowed:responder},resolve:{from:['In progress'],to:'Fix proposed',allowed:responder},refer:{from:['Reported','Accepted','In progress','Reopened'],to:'Referred',allowed:responder},confirm:{from:['Fix proposed'],to:'Confirmed fixed',allowed:reporter},reopen:{from:['Fix proposed','Confirmed fixed'],to:'Reopened',allowed:reporter}};
 const r=rules[action];if(!r||!r.allowed)throw new Error('You are not allowed to make this update.');if(!r.from.includes(status))throw new Error('This update is not available at the current status.');return r.to;
}
// Remove metadata and trailing payloads from baseline/progressive JPEG uploads.
export function cleanJpeg(bytes:Uint8Array){
 if(bytes.length<20||bytes.length>2*1024*1024||bytes[0]!==255||bytes[1]!==216)throw new Error('Use a JPEG image up to 2 MB.');
 const chunks:Uint8Array[]=[bytes.slice(0,2)];let p=2,dimensions=false;
 while(p<bytes.length){if(bytes[p]!==255)throw new Error('Invalid JPEG image.');const marker=bytes[p+1];if(marker===218){let end=bytes.length-2;while(end>p && !(bytes[end]===255&&bytes[end+1]===217))end--;if(end<=p||!dimensions)throw new Error('Incomplete JPEG image.');chunks.push(bytes.slice(p,end+2));return new Uint8Array(chunks.reduce((n,c)=>n+c.length,0)).map((_,i)=>{let offset=0;for(const c of chunks){if(i<offset+c.length)return c[i-offset];offset+=c.length}return 0})}
 const len=(bytes[p+2]<<8)|bytes[p+3];if(len<2||p+2+len>bytes.length)throw new Error('Invalid JPEG image.');if(marker===192||marker===194){const h=(bytes[p+5]<<8)|bytes[p+6],w=(bytes[p+7]<<8)|bytes[p+8];if(!w||!h||w>4096||h>4096)throw new Error('Image dimensions must be at most 4096 × 4096.');dimensions=true}if(!(marker>=224&&marker<=239)&&marker!==254)chunks.push(bytes.slice(p,p+2+len));p+=2+len;
 }throw new Error('Incomplete JPEG image.');
}
