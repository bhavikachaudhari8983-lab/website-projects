import {env} from 'cloudflare:workers';
import {getChatGPTUser} from '@/app/chatgpt-auth';
import {handle,type Bindings} from '@/lib/service';
export const dynamic='force-dynamic';
async function route(req:Request){const user=await getChatGPTUser();const bindings=env as unknown as Bindings;const allowed=(bindings.RESPONDER_EMAILS||'').split(',').map(x=>x.trim().toLowerCase());return handle(req,bindings,user?{id:user.userId,email:user.email,responder:allowed.includes(user.email.toLowerCase())||(process.env.NODE_ENV==='development'&&user.email==='seedy@sites.test')}:null)}
export const GET=route;export const POST=route;export const PATCH=route;
