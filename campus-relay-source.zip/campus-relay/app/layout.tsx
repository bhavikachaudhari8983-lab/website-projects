import type { Metadata } from 'next';
import './globals.css';
export const metadata:Metadata={title:'Campus Relay — report, respond, resolve',description:'Report shared-space campus issues and follow an accountable response.'};
export default function RootLayout({children}:Readonly<{children:React.ReactNode}>){return <html lang="en"><body>{children}</body></html>}
