# COSMOS astronomy website concept

Independent student website concept by Bhavika; not an official club website.

## Working demo

Responsive homepage, section pages, site search, event tabs, interest selection, resources, and an illustrated gallery. Original SVG design artwork replaces institutional photos and logos in this publication copy. The official university COSMOS page is linked for club information; event dates, recruitment and telemetry are not represented as live services.

## Run

Use Node.js 22+; run `npm ci`, `npm run build`, then `npm run start -- --port 5180`. Open http://localhost:5180.

## Checks and limits

Production build passed. ESLint has no errors and 11 advisory image-optimization warnings. Public deployment is pending. No membership applications, booking system, live telemetry, or institutional approval is claimed.

Source: https://mitwpu.edu.in/cosmos
