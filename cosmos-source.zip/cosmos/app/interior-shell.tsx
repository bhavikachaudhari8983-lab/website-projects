'use client';
import Link from 'next/link';

import { useMemo, useState } from 'react';
import { pageSlugs, sitePages } from './site-data';

const navItems = [
  ['About', '/about'], ['Events', '/events'], ['Projects', '/projects'],
  ['Observatory', '/observatory'], ['Ground station', '/ground-station'], ['Gallery', '/gallery'],
  ['Resources', '/resources'], ['Team', '/team'],
];

export function InteriorHeader() {
  const [open, setOpen] = useState(false);
  return (
    <header className="interior-header">
      <Link className="brand" href="/" aria-label="COSMOS home"><img className="cosmos-logo" src="/images/astronomy-study.svg" alt="" /><span><b>COSMOS</b><small>Astronomy Club • MIT-WPU</small></span></Link>
      <nav className={open ? 'open' : ''} aria-label="Site navigation">
        {navItems.map(([label, href]) => <Link href={href} key={href} onClick={() => setOpen(false)}>{label}</Link>)}
      </nav>
      <div className="interior-actions">
        <Link href="/search" aria-label="Search COSMOS">Search</Link>
        <Link className="mini-join" href="/join">Join us ↗</Link>
        <button type="button" onClick={() => setOpen(!open)} aria-label="Toggle menu" aria-expanded={open}><span /><span /></button>
      </div>
    </header>
  );
}

export function InteriorFooter() {
  return (
    <footer className="interior-footer">
      <div><Link className="brand" href="/"><img className="cosmos-logo" src="/images/astronomy-study.svg" alt="" /><span><b>COSMOS</b><small>Astronomy Club • MIT-WPU</small></span></Link><p>See you among the stars</p></div>
      <div className="footer-map">
        {navItems.slice(0, 6).map(([label, href]) => <Link href={href} key={href}>{label}</Link>)}
      </div>
      <div><Link href="https://mitwpu.edu.in/cosmos" target="_blank" rel="noreferrer">Instagram ↗</Link><Link href="https://mitwpu.edu.in/cosmos" target="_blank" rel="noreferrer">LinkedIn ↗</Link><Link href="/join">Join COSMOS ↗</Link></div>
    </footer>
  );
}

export function SiteSearch() {
  const [query, setQuery] = useState('');
  const directory = useMemo(() => pageSlugs.filter((slug) => slug !== 'search').map((slug) => ({ slug, ...sitePages[slug] })), []);
  const results = directory.filter((item) => {
    const text = `${item.eyebrow} ${item.title} ${item.accent} ${item.description} ${item.details.join(' ')}`.toLowerCase();
    return !query.trim() || text.includes(query.trim().toLowerCase());
  });

  return (
    <div className="directory-search">
      <label htmlFor="directory-query">Search COSMOS</label>
      <div className="directory-input"><span aria-hidden="true" /><input id="directory-query" type="search" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Try events, telescope, beginner…" /><b>{results.length}</b></div>
      <div className="directory-results" aria-live="polite">
        {results.map((result) => <Link href={`/${result.slug}`} key={result.slug}><span>{result.number}</span><div><b>{result.eyebrow}</b><h2>{result.title} {result.accent}</h2></div><i>↗</i></Link>)}
        {!results.length && <p>No matches yet. Try a broader word such as “events”, “projects”, or “join”.</p>}
      </div>
    </div>
  );
}
