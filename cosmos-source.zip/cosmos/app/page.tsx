'use client';
import Link from 'next/link';

import { useMemo, useState } from 'react';

const activities = [
  { number: '01', code: 'OBS', title: 'Observational astronomy', copy: 'Learn the night sky, plan observations, and join guided telescope sessions—no experience needed.', tone: 'blue' },
  { number: '02', code: 'IMG', title: 'Astrophotography', copy: 'Turn photons into photographs. Learn capture, tracking, stacking, and processing with the club.', tone: 'violet' },
  { number: '03', code: 'RF', title: 'Ground station', copy: 'Explore radio astronomy, antennas, satellite passes, signals, and hands-on instrumentation.', tone: 'acid' },
  { number: '04', code: 'LAB', title: 'Space projects', copy: 'Build practical, interdisciplinary projects with students who like to ask ambitious questions.', tone: 'orange' },
  { number: '05', code: 'LIVE', title: 'Events & workshops', copy: 'Sky watches, talks, demonstrations, learning circles, and open sessions for the campus community.', tone: 'paper' },
];

const upcomingEvents = [
  { day: 'NEXT', month: 'TBA', type: 'Official update', title: 'Next COSMOS event', place: 'MIT-WPU, Kothrud', note: 'Watch the official COSMOS social channels for the next announcement' },
];

const pastEvents: typeof upcomingEvents = [];

const projects = [
  { tag: 'Radio astronomy', title: 'Ground station', copy: 'Explore antennas, satellite signals, receivers, and radio-astronomy learning.', status: 'Concept overview', visual: 'signal' },
  { tag: 'Optical astronomy', title: 'Aryabhatta Observatory', copy: 'Explore the principles of telescope observations, imaging, and sky watching.', status: 'Facility details await confirmation', visual: 'observatory' },
  { tag: 'Open science', title: 'NOAA data', copy: 'A proposed space for learning about satellite weather data and documenting experiments.', status: 'No live data connected', visual: 'project' },
];

const resources = [
  { label: 'Start here', title: 'Beginner astronomy', copy: 'A friendly path from identifying directions to reading your first sky chart.' },
  { label: 'Field guide', title: 'Observation basics', copy: 'Plan a session, protect your night vision, record notes, and observe responsibly.' },
  { label: 'Toolkit', title: 'Astrophotography', copy: 'Understand exposure, focus, stacking, and the gear you actually need to begin.' },
  { label: 'Reference', title: 'Astronomy glossary', copy: 'Plain-language explanations for the terms you will meet in sessions and projects.' },
];

const searchItems = [
  ...activities.map((item) => ({ title: item.title, detail: 'Activity', href: '/projects' })),
  ...projects.map((item) => ({ title: item.title, detail: 'Project', href: '/projects' })),
  ...resources.map((item) => ({ title: item.title, detail: 'Resource', href: '/resources' })),
  { title: 'Upcoming events', detail: 'Schedule', href: '/events' },
  { title: 'How to join COSMOS', detail: 'Membership', href: '/join' },
  { title: 'Frequently asked questions', detail: 'Help', href: '/faq' },
];

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [eventView, setEventView] = useState<'upcoming' | 'past'>('upcoming');

  const results = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    if (!normalized) return searchItems.slice(0, 5);
    return searchItems.filter((item) => `${item.title} ${item.detail}`.toLowerCase().includes(normalized));
  }, [query]);

  const closeNavigation = () => setMenuOpen(false);

  return (
    <main id="top">
      <Link className="skip-link" href="#today">Skip to club information</Link>
      <header className="site-header">
        <Link className="brand" href="#top" aria-label="COSMOS home" onClick={closeNavigation}>
          <img className="cosmos-logo" src="/images/astronomy-study.svg" alt="" />
          <span><b>COSMOS</b><small>Astronomy Club • MIT-WPU</small></span>
        </Link>

        <nav className={menuOpen ? 'nav-open' : ''} aria-label="Primary navigation">
          <Link href="/about" onClick={closeNavigation}>About</Link>
          <Link href="/events" onClick={closeNavigation}>Events</Link>
          <Link href="/projects" onClick={closeNavigation}>Projects</Link>
          <Link href="/observatory" onClick={closeNavigation}>Observatory</Link>
          <Link href="/gallery" onClick={closeNavigation}>Gallery</Link>
        </nav>

        <div className="header-actions">
          <button className="search-button" type="button" onClick={() => setSearchOpen(true)} aria-label="Search COSMOS">
            <span aria-hidden="true" /> Search
          </button>
          <Link className="header-cta" href="/join">Join <span aria-hidden="true">↗</span></Link>
          <button
            className="menu-button"
            type="button"
            aria-label="Toggle navigation"
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen(!menuOpen)}
          >
            <span /><span />
          </button>
        </div>
      </header>

      <section className="hero" aria-labelledby="hero-title">
        <div className="sky" aria-hidden="true">
          <img className="hero-club-photo" src="/images/astronomy-study.svg" alt="" />
          <span className="orbit orbit-one" />
          <span className="orbit orbit-two" />
          <span className="orbit-dot" />
          <span className="planet" />
        </div>
        <div className="hero-content">
          <p className="eyebrow"><span /> Astronomy, made for the curious</p>
          <h1 id="hero-title">Look up.<br /><em>Go beyond.</em></h1>
          <p className="hero-copy">
            Based at MIT World Peace University, Pune, COSMOS brings students
            together through astrophotography, observational astronomy and radio astronomy.
          </p>
          <div className="hero-actions">
            <Link className="button button-primary" href="/join">Find your club wing <span>↗</span></Link>
            <Link className="text-link" href="/join">I want to join <span>↗</span></Link>
          </div>
        </div>
        <div className="hero-index" aria-label="Featured activities">
          {activities.slice(0, 4).map((item) => (
            <Link className="index-item" href="/projects" key={item.number}>
              <span>{item.number}</span><p>{item.title}</p><b aria-hidden="true">↗</b>
            </Link>
          ))}
        </div>
        <Link className="scroll-cue" href="#today"><span /> Scroll to discover</Link>
      </section>

      <section className="quick-access" aria-label="Quick access">
        <div className="quick-label"><span>Quick access</span><b>Choose a destination</b></div>
        <div className="quick-grid">
          {[
            ['CAL', 'Events', 'View & register', '/events'],
            ['OBS', 'Observatory', 'Plan a session', '/observatory'],
            ['RF', 'Ground station', 'Explore the station', '/ground-station'],
            ['LAB', 'Projects', 'Explore our work', '/projects'],
            ['IMG', 'Gallery', 'Astrophotography', '/gallery'],
            ['YOU', 'Join us', 'Become a member', '/join'],
          ].map(([code, title, copy, href]) => (
            <Link className="quick-card" href={href} key={title}>
              <span>{code}</span><h2>{title}</h2><p>{copy}</p><b>↗</b>
            </Link>
          ))}
        </div>
      </section>

      <section className="research-strip" aria-label="Design highlights">
        <div><span>Home</span><b>MIT World Peace University</b><small>Department of Physics • Pune</small></div>
        <div><span>Learning concept</span><b>Satellite data</b><small>No live telemetry connected</small></div>
        <div><span>Activity ideas</span><b>Concept programme</b><small>Dates require confirmation</small></div>
        <div><span>Facility</span><b>Aryabhatta Observatory</b><small>Optical astronomy • Eco Park</small></div>
      </section>

      <section className="today-section section" id="today" aria-labelledby="today-title">
        <div className="section-kicker"><span>Inside COSMOS</span><b>01</b></div>
        <div className="section-heading split-heading">
          <div>
            <p className="eyebrow dark"><span /> COSMOS today</p>
            <h2 id="today-title">The sky<br />doesn’t wait.</h2>
          </div>
          <p>A window into COSMOS facilities, recent activity and proposed website sections at MIT-WPU.</p>
        </div>

        <div className="today-grid">
          <article className="today-card moon-card">
            <div className="card-top"><span>01 / Imaging</span><b>Explore</b></div>
            <div className="moon-visual" aria-hidden="true" />
            <div><p className="mini-label">Official club pillar</p><h3>Astrophotography</h3><p>COSMOS members capture the Moon, deep-sky objects and solar phenomena.</p></div>
          </article>
          <article className="today-card sky-card">
            <div className="card-top"><span>02 / Sky</span><b>Field guide</b></div>
            <div className="constellation" aria-hidden="true"><i /><i /><i /><i /><i /></div>
            <div><p className="mini-label">Vishwaroop Darshan</p><h3>Aryabhatta Observatory</h3><p>Explore telescope observations and celestial imaging.</p></div>
          </article>
          <article className="today-card event-card">
            <div className="card-top"><span>03 / Event archive</span><b>Past event</b></div>
            <div className="big-date"><strong>AX</strong><span>22–23<br />Aug 2026</span></div>
            <div><p className="mini-label">Recent milestone</p><h3>Activity ideas</h3><p>A proposed space for event announcements once the club confirms them.</p></div>
          </article>
          <article className="today-card station-card">
            <div className="card-top"><span>04 / Ground station</span><b>Radio astronomy</b></div>
            <div className="signal-visual" aria-hidden="true"><span /><span /><span /></div>
            <div><p className="mini-label">OpenWeather network</p><h3>Listening for signals</h3><p>A radio-astronomy learning concept, with no live satellite data connected.</p></div>
          </article>
        </div>
      </section>

      <section className="explore-section section" id="explore" aria-labelledby="explore-title">
        <div className="section-kicker light"><span>What can I do here?</span><b>02</b></div>
        <div className="section-heading centered">
          <p className="eyebrow"><span /> Find your orbit</p>
          <h2 id="explore-title">There’s room<br />for your curiosity.</h2>
        </div>
        <div className="activity-list">
          {activities.map((item) => (
            <article className={`activity-row tone-${item.tone}`} key={item.number}>
              <span className="activity-number">{item.number}</span>
              <span className="activity-code">{item.code}</span>
              <h3>{item.title}</h3>
              <p>{item.copy}</p>
              <Link href="/join" aria-label={`Join ${item.title}`}>↗</Link>
            </article>
          ))}
        </div>
      </section>

      <section className="events-section section" id="events" aria-labelledby="events-title">
        <div className="section-kicker"><span>Gather • Observe • Learn</span><b>03</b></div>
        <div className="section-heading split-heading compact">
          <div>
            <p className="eyebrow dark"><span /> Events archive</p>
            <h2 id="events-title">What’s<br />happening.</h2>
          </div>
          <div className="event-switch" role="group" aria-label="Event archive view">
            <button aria-pressed={eventView === 'upcoming'} className={eventView === 'upcoming' ? 'active' : ''} onClick={() => setEventView('upcoming')}>Upcoming</button>
            <button aria-pressed={eventView === 'past'} className={eventView === 'past' ? 'active' : ''} onClick={() => setEventView('past')}>Past events</button>
          </div>
        </div>
        <div className="event-list">
          {(eventView === 'upcoming' ? upcomingEvents : pastEvents).map((event, index) => (
            <article className="event-row" key={`${event.title}-${index}`}>
              <div className="event-date"><strong>{event.day}</strong><span>{event.month}</span></div>
              <div className="event-main"><span>{event.type}</span><h3>{event.title}</h3></div>
              <div className="event-meta"><span>{event.place}</span><p>{event.note}</p></div>
              <Link href="/events" aria-label={`Learn more about ${event.title}`}>↗</Link>
            </article>
          ))}
        </div>
      </section>

      <section className="projects-section section" id="projects" aria-labelledby="projects-title">
        <div className="section-kicker light"><span>Build the unknown</span><b>04</b></div>
        <div className="section-heading split-heading on-dark">
          <div>
            <p className="eyebrow"><span /> Projects & facilities</p>
            <h2 id="projects-title">Ideas become<br /><em>instruments.</em></h2>
          </div>
          <p>From optical observation to radio experiments, members learn by doing—together.</p>
        </div>
        <div className="project-grid">
          {projects.map((project, index) => (
            <article className="project-card" key={project.title}>
              <div className={`project-visual ${project.visual}`} aria-hidden="true">
                <span className="project-index">0{index + 1}</span>
                <i /><i /><i />
              </div>
              <div className="project-copy">
                <span>{project.tag}</span><h3>{project.title}</h3><p>{project.copy}</p><b>{project.status}</b>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="gallery-section" id="gallery" aria-labelledby="gallery-title">
        <div className="gallery-copy">
          <p className="eyebrow"><span /> Astrophotography showcase</p>
          <h2 id="gallery-title">Illustrating<br /><em>the universe.</em></h2>
          <p>Original abstract illustrations demonstrate the gallery layout. They are not club photographs or observational data.</p>
          <Link className="button button-outline" href="/gallery">View the gallery <span>↗</span></Link>
        </div>
        <div className="gallery-mosaic" aria-label="Gallery categories">
          <div className="gallery-tile tile-moon"><img src="/images/astronomy-study.svg" alt="Original abstract astronomy illustration" /><span>Moon / Illustration</span></div>
          <div className="gallery-tile tile-nebula"><img src="/images/astronomy-study.svg" alt="Original abstract astronomy illustration" /><span>Deep sky / Illustration</span></div>
          <div className="gallery-tile tile-solar"><img src="/images/astronomy-study.svg" alt="Original abstract astronomy illustration" /><span>Radio / Illustration</span></div>
          <div className="gallery-tile tile-events"><img src="/images/astronomy-study.svg" alt="Original abstract astronomy illustration" /><span>Community / Illustration</span></div>
        </div>
      </section>

      <section className="learn-section section" id="learn" aria-labelledby="learn-title">
        <div className="section-kicker"><span>Learn at your pace</span><b>05</b></div>
        <div className="section-heading split-heading compact">
          <div>
            <p className="eyebrow dark"><span /> The COSMOS library</p>
            <h2 id="learn-title">Start with<br />a question.</h2>
          </div>
          <p>You do not need a telescope or prior astronomy knowledge. Bring curiosity; we’ll help with the rest.</p>
        </div>
        <div className="resource-grid">
          {resources.map((resource, index) => (
            <article className="resource-card" key={resource.title}>
              <div><span>0{index + 1}</span><b>{resource.label}</b></div>
              <h3>{resource.title}</h3>
              <p>{resource.copy}</p>
              <Link href="/resources">Open guide <span>↗</span></Link>
            </article>
          ))}
        </div>
      </section>

      <section className="join-section section" id="join" aria-labelledby="join-title">
        <div className="join-orbit" aria-hidden="true"><span /><i /></div>
        <div className="join-intro">
          <p className="eyebrow"><span /> Open to every branch</p>
          <h2 id="join-title">Your place<br />is among<br /><em>the stars.</em></h2>
        </div>
        <div className="join-details">
          <p>No prior knowledge. No telescope required. COSMOS welcomes students who want to observe, build, document, organize, or simply learn.</p>
          <ol>
            <li><span>01</span><div><b>Check recruitment</b><p>See the current intake window and available club wings.</p></div></li>
            <li><span>02</span><div><b>Register interest</b><p>Share what you are curious about and how you would like to contribute.</p></div></li>
            <li><span>03</span><div><b>Meet the community</b><p>Attend an orientation, explore the teams, and begin your first activity.</p></div></li>
          </ol>
          <Link className="button button-primary wide" href="/join">Find your starting point <span>↗</span></Link>
          <small>Recruitment dates are announced by the club. Explore your interests first.</small>
        </div>
      </section>

      <section className="faq-section section" id="faq" aria-labelledby="faq-title">
        <div className="section-kicker"><span>Questions, answered</span><b>06</b></div>
        <div className="faq-layout">
          <div>
            <p className="eyebrow dark"><span /> Astronomy FAQ</p>
            <h2 id="faq-title">Before<br />you ask.</h2>
          </div>
          <div className="faq-list">
            {[
              ['Do I need prior astronomy knowledge?', 'Not at all. Beginner sessions are designed to help you build a foundation from scratch.'],
              ['Do I need to own a telescope?', 'No. Club activities can use shared equipment and many observations begin with the unaided eye.'],
              ['Can students from other branches participate?', 'Yes. Astronomy crosses physics, engineering, design, software, communication, and more.'],
              ['What do members actually do?', 'Members observe, photograph, build projects, operate equipment, organize events, document work, and learn together.'],
              ['When does recruitment happen?', 'The confirmed recruitment window and registration form will be posted in the Join section.'],
            ].map(([question, answer], index) => (
              <details key={question} open={index === 0}>
                <summary><span>0{index + 1}</span>{question}<b>+</b></summary>
                <p>{answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <footer id="contact">
        <div className="footer-top">
          <div><span className="footer-star" aria-hidden="true">✦</span><h2>Stay curious.<br /><em>Stay connected.</em></h2></div>
          <div className="footer-contact">
            <p>Follow the official COSMOS channels for current announcements, recruitment and events.</p>
            <Link href="https://mitwpu.edu.in/cosmos" target="_blank" rel="noreferrer">Instagram <span>↗</span></Link>
            <Link href="https://mitwpu.edu.in/cosmos" target="_blank" rel="noreferrer">LinkedIn <span>↗</span></Link>
            <Link href="https://mitwpu.edu.in/cosmos" target="_blank" rel="noreferrer">MIT-WPU club page <span>↗</span></Link>
          </div>
        </div>
        <div className="footer-bottom">
          <Link className="brand" href="#top"><img className="cosmos-logo" src="/images/astronomy-study.svg" alt="" /><span><b>COSMOS</b><small>Astronomy Club • MIT-WPU</small></span></Link>
          <p>Observe • Build • Discover</p>
          <Link href="#top">Back to top ↑</Link>
        </div>
      </footer>

      {searchOpen && (
        <div className="search-overlay" role="dialog" aria-modal="true" aria-label="Search COSMOS">
          <button className="search-close" type="button" onClick={() => { setSearchOpen(false); setQuery(''); }} aria-label="Close search">×</button>
          <div className="search-panel">
            <p className="eyebrow"><span /> Search the universe</p>
            <label htmlFor="site-search">What are you looking for?</label>
            <input
              autoFocus
              id="site-search"
              type="search"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Events, projects, joining…"
            />
            <div className="search-results" aria-live="polite">
              {results.length ? results.map((result) => (
                <Link href={result.href} key={`${result.detail}-${result.title}`} onClick={() => { setSearchOpen(false); setQuery(''); }}>
                  <span>{result.detail}</span><b>{result.title}</b><i>↗</i>
                </Link>
              )) : <p>No results yet. Try “events”, “ground station”, or “join”.</p>}
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
