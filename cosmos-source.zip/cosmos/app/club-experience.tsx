'use client';
import Link from 'next/link';
import { useState } from 'react';

const wings = [
  { name: 'Observe', title: 'Observational astronomy', text: 'Start by learning the sky alongside other curious students.', first: 'Ask about the next beginner observation session.', href: '/observatory' },
  { name: 'Capture', title: 'Astrophotography', text: 'Bring your interest in photography, editing or visual storytelling.', first: 'Explore the gallery and ask how members learn imaging.', href: '/gallery' },
  { name: 'Build', title: 'Radio & instrumentation', text: 'Explore the intersection of electronics, software and space.', first: 'Read about the ground station and ask about an introductory visit.', href: '/ground-station' },
  { name: 'Organize', title: 'Events & community', text: 'Contribute through design, documentation and bringing people together.', first: 'Ask the club about volunteering at its next event.', href: '/events' },
];
const photos = [
  { category: 'Moon', src: 'astronomy-study.svg', title: 'Lunar illustration concept' },
  { category: 'Deep sky', src: 'astronomy-study.svg', title: 'Deep-sky gallery concept' },
  { category: 'Radio', src: 'astronomy-study.svg', title: 'Orbital illustration concept' },
  { category: 'Community', src: 'astronomy-study.svg', title: 'Community gallery concept' },
  { category: 'Community', src: 'astronomy-study.svg', title: 'Astronomy community concept' },
];
export function ClubExperience({ section }: { section: string }) {
  const [wing, setWing] = useState(0);
  const [category, setCategory] = useState('All');
  if (section === 'join') return <section className="experience-panel" aria-labelledby="wing-title">
    <p className="mini-label">Your first step / 01</p><h2 id="wing-title">What draws you to space?</h2><p>Choose an interest. There is more than one way to contribute.</p>
    <div className="choice-tabs" role="group" aria-label="Choose your interest">{wings.map((item, i) => <button key={item.name} aria-pressed={wing === i} onClick={() => setWing(i)}>{item.name} <span>↗</span></button>)}</div>
    <div className="wing-result" aria-live="polite"><div><span>A starting point for you</span><h3>{wings[wing].title}</h3><p>{wings[wing].text}</p><Link href={wings[wing].href}>Explore this interest ↗</Link></div><div><span>Your next move</span><p>{wings[wing].first}</p><Link className="button button-primary" href="https://mitwpu.edu.in/cosmos" target="_blank" rel="noreferrer">Visit university club page ↗</Link><small>This opens the club profile. No application is submitted here.</small></div></div>
  </section>;
  if (section === 'gallery') return <section className="experience-panel gallery-browser" aria-labelledby="collection-title"><p className="mini-label">The COSMOS collection</p><h2 id="collection-title">Different ways to see.</h2><div className="choice-tabs" role="group" aria-label="Filter gallery">{['All', 'Moon', 'Deep sky', 'Radio', 'Community'].map(item => <button key={item} aria-pressed={category === item} onClick={() => setCategory(item)}>{item}</button>)}</div><p aria-live="polite">{photos.filter(p => category === 'All' || p.category === category).length} illustrations · Original illustrative artwork</p><div className="photo-collection">{photos.filter(p => category === 'All' || p.category === category).map(photo => <figure key={photo.title}><Link href={`/images/${photo.src}`} target="_blank" rel="noreferrer" aria-label={`Open full image: ${photo.title}`}><img loading="lazy" src={`/images/${photo.src}`} alt={photo.title}/></Link><figcaption><span>{photo.category}</span><h3>{photo.title}</h3><Link href="https://mitwpu.edu.in/cosmos" target="_blank" rel="noreferrer">University collection ↗</Link></figcaption></figure>)}</div><small>Original vector illustration; no university photographs are reproduced.</small></section>;
  if (section === 'resources') return <section className="experience-panel guides" aria-labelledby="guides-title"><p className="mini-label">Start without buying equipment</p><h2 id="guides-title">Your first night of astronomy.</h2>{[
    ['01 / Before you go', 'Choose a safe, accessible place with a clear view of the sky. Tell someone where you are going, check local weather, and bring a friend. Ask the club about supervised sessions.'],
    ['02 / Look, then record', 'Begin with what you can see without equipment. Write down the date, time, location, cloud cover and a description or sketch of your observation. Questions make useful notes too.'],
    ['03 / Bring your curiosity', 'A notebook, a charged phone and a comfortable layer are enough for a first visit. Ask the session lead before touching or adjusting shared equipment. Never look at the Sun through optical equipment without expert supervision and appropriate solar equipment.'],
    ['04 / Share what you noticed', 'Compare your notes with another observer. Ask what you were looking at, how the equipment works and what you could try next. Your first observation can become the start of a project.'],
  ].map(([title, text], i) => <details key={title} open={i === 0}><summary>{title}<span>+</span></summary><p>{text}</p></details>)}</section>;
  if (section === 'events') return <section className="experience-panel"><p className="mini-label">Before you plan your visit</p><h2>Confirmed plans start here.</h2><p>No upcoming date or registration link has been supplied for this website. Check the club’s announcements before travelling.</p><Link className="button button-primary" href="https://mitwpu.edu.in/cosmos" target="_blank" rel="noreferrer">Check club announcements ↗</Link></section>;
  return null;
}
