export type SiteCard = {
  eyebrow: string;
  title: string;
  copy: string;
  meta?: string;
};

export type SitePage = {
  number: string;
  eyebrow: string;
  title: string;
  accent: string;
  description: string;
  status: string;
  cards: SiteCard[];
  detailsTitle: string;
  details: string[];
  cta: string;
  ctaHref: string;
};

export const sitePages: Record<string, SitePage> = {
  about: {
    number: '01', eyebrow: 'Who we are', title: 'Curiosity is our', accent: 'common ground.',
    description: 'COSMOS is a student astronomy community where observation, engineering, photography, research, and storytelling meet.',
    status: 'Student-led • Beginner-friendly',
    cards: [
      { eyebrow: 'Our vision', title: 'Make the universe feel closer', copy: 'Create an open, practical astronomy culture where any student can begin exploring the sky.' },
      { eyebrow: 'Our mission', title: 'Learn by looking and building', copy: 'Pair foundational learning with observations, instruments, projects, workshops, and shared documentation.' },
      { eyebrow: 'Our difference', title: 'Many disciplines, one sky', copy: 'Bring together science, engineering, software, design, media, and community around meaningful space work.' },
    ],
    detailsTitle: 'What happens inside COSMOS',
    details: ['Guided sky observations', 'Astrophotography sessions', 'Ground station experiments', 'Student space projects', 'Talks and workshops', 'Open learning circles'],
    cta: 'Meet the community', ctaHref: '/team',
  },
  events: {
    number: '02', eyebrow: 'Events archive', title: 'Meet under the', accent: 'same sky.',
    description: 'Find official event announcements and explore ideas for your next club activity. Only the club can confirm dates and registration.',
    status: 'New dates published after club approval',
    cards: [
      { eyebrow: 'Activity idea • Not scheduled', title: 'Open sky watch', copy: 'A guided campus observation session designed for first-time and returning observers.', meta: 'Campus observatory • Open to students' },
      { eyebrow: 'Activity idea • Not scheduled', title: 'Astrophotography 101', copy: 'A practical introduction to planning, capture, focus, exposure, stacking, and editing.', meta: 'Beginner workshop • Ask the club about availability' },
      { eyebrow: 'Archive • 2026', title: 'Past events collection', copy: 'Event reports, highlights, media, and outcomes organized by year and event type.', meta: 'Club-approved archive pending' },
    ],
    detailsTitle: 'Every event record can include',
    details: ['Date and time', 'Venue and directions', 'Registration link', 'Who can attend', 'Event description', 'Photos and report'],
    cta: 'Get event updates', ctaHref: '/join',
  },
  projects: {
    number: '03', eyebrow: 'Projects & research', title: 'Turn questions into', accent: 'working systems.',
    description: 'Discover club initiatives, member-led experiments, observation programmes, software, instruments, and research work.',
    status: 'Open for approved member submissions',
    cards: [
      { eyebrow: 'Radio astronomy', title: 'Ground station', copy: 'Antennas, receivers, satellite passes, signals, and practical communications experiments.', meta: 'Active club wing' },
      { eyebrow: 'Optical astronomy', title: 'Observatory programme', copy: 'Telescope observations, equipment orientation, logging, imaging, and public sessions.', meta: 'Sessions by schedule' },
      { eyebrow: 'Member work', title: 'Research & builds', copy: 'A home for student instruments, software, observational studies, and interdisciplinary space ideas.', meta: 'Portfolio submissions welcome' },
    ],
    detailsTitle: 'Project pages are built to show',
    details: ['Problem or research question', 'Team and contributors', 'Methods and equipment', 'Progress updates', 'Results and media', 'Ways to participate'],
    cta: 'Explore the ground station', ctaHref: '/ground-station',
  },
  observatory: {
    number: '04', eyebrow: 'Optical astronomy', title: 'A closer look at', accent: 'the night.',
    description: 'Learn about the observatory, available equipment, session formats, access rules, and how observation requests will work.',
    status: 'Booking opens when the club publishes a schedule',
    cards: [
      { eyebrow: 'Facility', title: 'Inside the observatory', copy: 'An overview of the space, instruments, capabilities, and the kinds of targets members can observe.' },
      { eyebrow: 'Sessions', title: 'Guided observations', copy: 'Planned evenings with target lists, equipment leads, weather checks, and observation logs.' },
      { eyebrow: 'Access', title: 'Request a visit', copy: 'A future request flow for club sessions, academic visits, demonstrations, and approved group bookings.' },
    ],
    detailsTitle: 'Before every observing session',
    details: ['Check the confirmed schedule', 'Review weather updates', 'Follow equipment guidance', 'Use red light after dark', 'Log observations carefully', 'Respect capacity and access rules'],
    cta: 'View upcoming events', ctaHref: '/events',
  },
  'ground-station': {
    number: '05', eyebrow: 'Radio astronomy', title: 'Listen beyond', accent: 'the visible.',
    description: 'The ground station page brings together publicly shareable system status, recent activity, pass planning, and learning material.',
    status: 'Facility overview • No live telemetry',
    cards: [
      { eyebrow: 'System', title: 'Station status', copy: 'A clear operational summary for equipment that the club approves for public display.', meta: 'Live operational status is not available' },
      { eyebrow: 'Activity', title: 'Recent signals', copy: 'A chronological log for approved receptions, decoded data, experiments, and observations.', meta: 'Data feed can be connected later' },
      { eyebrow: 'Planning', title: 'Pass predictions', copy: 'An organized space for upcoming passes, observation windows, frequencies, and team assignments.', meta: 'Club validation required' },
    ],
    detailsTitle: 'The station archive can document',
    details: ['Equipment configuration', 'Public system status', 'Recent receptions', 'Pass prediction windows', 'Experiment notes', 'Learning resources'],
    cta: 'See all projects', ctaHref: '/projects',
  },
  gallery: {
    number: '06', eyebrow: 'Astrophotography', title: 'Light, collected', accent: 'over time.',
    description: 'Explore lunar images, deep-sky observations, satellite imagery and club moments in a gallery interface illustrated with original artwork.',
    status: 'Original illustrative artwork • gallery design demo',
    cards: [
      { eyebrow: 'Lunar', title: 'The Moon', copy: 'Phases, craters, eclipses, and detailed lunar studies from COSMOS observers.', meta: 'Illustration, not an observation' },
      { eyebrow: 'Planetary', title: 'Planets', copy: 'Images, sketches, and processed observations of planets across different nights and instruments.', meta: 'Illustration, not an observation' },
      { eyebrow: 'Deep sky', title: 'Stars & nebulae', copy: 'Long-exposure work, stacking experiments, constellations, clusters, and wide-field nightscapes.', meta: 'Technique notes included' },
    ],
    detailsTitle: 'A gallery made for finding things',
    details: ['Explore lunar imaging', 'Filter by category', 'Explore community photographs', 'View the university image source', 'Ask the club for capture details', 'Contact the club to contribute'],
    cta: 'Submit gallery work', ctaHref: '/contact',
  },
  resources: {
    number: '07', eyebrow: 'Learning library', title: 'Begin with', accent: 'one question.',
    description: 'A beginner-friendly collection of observation guides, astronomy concepts, astrophotography notes, radio resources, and useful tools.',
    status: 'Designed for first-time learners',
    cards: [
      { eyebrow: 'Start here', title: 'Beginner astronomy', copy: 'Learn directions, coordinates, sky movement, magnitudes, and how to read a basic chart.' },
      { eyebrow: 'Field guide', title: 'Observation basics', copy: 'Plan your session, preserve night vision, record useful notes, and use equipment responsibly.' },
      { eyebrow: 'Toolkit', title: 'Photography & radio', copy: 'Practical starter material for imaging, processing, antennas, receivers, and signals.' },
    ],
    detailsTitle: 'Resource formats',
    details: ['Beginner guides', 'Observation checklists', 'Recommended books', 'Useful websites and tools', 'Club-created study material', 'Astronomy glossary'],
    cta: 'Ask a question', ctaHref: '/faq',
  },
  team: {
    number: '08', eyebrow: 'The people of COSMOS', title: 'Built by students,', accent: 'shared by everyone.',
    description: 'Meet the current core team, understand what each wing does, and preserve an alumni record as the club grows.',
    status: 'Names and portraits added after club approval',
    cards: [
      { eyebrow: 'Leadership', title: 'Core team', copy: 'Club direction, coordination, faculty communication, planning, and member experience.' },
      { eyebrow: 'Technical', title: 'Observatory & radio', copy: 'Equipment, sessions, research, station operations, safety, documentation, and training.' },
      { eyebrow: 'Community', title: 'Events, media & design', copy: 'Workshops, registrations, storytelling, photography, archives, outreach, and partnerships.' },
    ],
    detailsTitle: 'Team profiles can include',
    details: ['Name and portrait', 'Role and club wing', 'Short introduction', 'Current responsibilities', 'Selected project work', 'Alumni year'],
    cta: 'Become a member', ctaHref: '/join',
  },
  join: {
    number: '09', eyebrow: 'Join COSMOS', title: 'There is a place for', accent: 'your curiosity.',
    description: 'Find a starting point that matches your interests, then ask the club about its next intake. Beginners are welcome.',
    status: 'Recruitment window to be confirmed',
    cards: [
      { eyebrow: 'Step 01', title: 'Check the intake', copy: 'See recruitment dates, available teams, eligibility, expectations, and the selection process.' },
      { eyebrow: 'Step 02', title: 'Register interest', copy: 'Use the official club form once it is supplied and connected by the COSMOS team.' },
      { eyebrow: 'Step 03', title: 'Meet the club', copy: 'Attend orientation, explore the teams, and take part in a first learning or observation activity.' },
    ],
    detailsTitle: 'Good to know',
    details: ['Beginners are welcome', 'No telescope required', 'Students across branches can contribute', 'Roles include technical and creative work', 'Regular participation matters', 'Club process will be published clearly'],
    cta: 'Contact COSMOS', ctaHref: '/contact',
  },
  contact: {
    number: '10', eyebrow: 'Contact', title: 'Start a', accent: 'conversation.',
    description: 'This page will become the verified directory for the club email, university page, social channels, location, and enquiry options.',
    status: 'Official contact details awaiting club approval',
    cards: [
      { eyebrow: 'General enquiry', title: 'Contact the club', copy: 'Questions about membership, events, visits, collaborations, and the COSMOS community.' },
      { eyebrow: 'Academic & facility', title: 'Observatory requests', copy: 'Requests related to observatory access, demonstrations, approved visits, and equipment.' },
      { eyebrow: 'Projects & media', title: 'Submit your work', copy: 'Share an approved member project, observation report, resource, or astrophotograph.' },
    ],
    detailsTitle: 'Official links to connect',
    details: ['Club email', 'Instagram profile', 'University page', 'Registration form', 'Campus location', 'Collaboration enquiries'],
    cta: 'Read common questions', ctaHref: '/faq',
  },
  faq: {
    number: '11', eyebrow: 'Questions answered', title: 'Everything you need', accent: 'to begin.',
    description: 'Clear answers for students exploring astronomy, deciding whether to join, planning an event, or looking for club information.',
    status: 'Answers can be updated by the club',
    cards: [
      { eyebrow: 'Getting started', title: 'Do I need a telescope?', copy: 'No. Shared equipment and unaided-eye observation make it possible to begin without owning gear.' },
      { eyebrow: 'Experience', title: 'Can beginners join?', copy: 'Yes. COSMOS is designed to help curious students build knowledge through guided participation.' },
      { eyebrow: 'Participation', title: 'What do members do?', copy: 'Observe, photograph, build, research, document, organize events, teach, and learn together.' },
    ],
    detailsTitle: 'Browse by topic',
    details: ['Joining and recruitment', 'Equipment and observatory', 'Events and registration', 'Projects and submissions', 'Ground station access', 'Gallery permissions and credit'],
    cta: 'Search the website', ctaHref: '/search',
  },
  search: {
    number: '12', eyebrow: 'Site search', title: 'Find it at', accent: 'light speed.',
    description: 'Search the COSMOS information hub for events, projects, facilities, resources, team information, gallery categories, and joining details.',
    status: 'Search all website sections',
    cards: [], detailsTitle: 'Popular destinations',
    details: ['Upcoming events', 'Ground station', 'Observatory sessions', 'Beginner resources', 'Astrophotography gallery', 'How to join'],
    cta: 'Return home', ctaHref: '/',
  },
};

export const pageSlugs = Object.keys(sitePages);
