import Link from 'next/link';
import { ClubExperience } from '../club-experience';
import { notFound } from 'next/navigation';
import type { Metadata } from 'next';
import { InteriorFooter, InteriorHeader, SiteSearch } from '../interior-shell';
import { pageSlugs, sitePages } from '../site-data';

type Props = { params: Promise<{ slug: string }> };

const pageImages: Record<string, string[]> = {
  about: ['/images/astronomy-study.svg', '/images/astronomy-study.svg', '/images/astronomy-study.svg'],
  events: ['/images/astronomy-study.svg', '/images/astronomy-study.svg', '/images/astronomy-study.svg'],
  projects: ['/images/astronomy-study.svg', '/images/astronomy-study.svg', '/images/astronomy-study.svg'],
  observatory: ['/images/astronomy-study.svg', '/images/astronomy-study.svg', '/images/astronomy-study.svg'],
  'ground-station': ['/images/astronomy-study.svg', '/images/astronomy-study.svg', '/images/astronomy-study.svg'],
  gallery: ['/images/astronomy-study.svg', '/images/astronomy-study.svg', '/images/astronomy-study.svg'],
  team: ['/images/astronomy-study.svg', '/images/astronomy-study.svg', '/images/astronomy-study.svg'],
};

export function generateStaticParams() {
  return pageSlugs.map((slug) => ({ slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const page = sitePages[slug];
  if (!page) return { title: 'COSMOS' };
  const title = `${page.eyebrow} | COSMOS`;
  return {
    title,
    description: page.description,
    openGraph: { title, description: page.description, images: (pageImages[slug] ?? []).slice(0, 1).map(url => ({ url: new URL(url, "https://cosmos-astronomy-club.bhavikachaudhari8983.chatgpt.site").href })) },
    twitter: { title, description: page.description, images: (pageImages[slug] ?? []).slice(0, 1).map(url => new URL(url, "https://cosmos-astronomy-club.bhavikachaudhari8983.chatgpt.site").href) },
  };
}

export default async function SiteSectionPage({ params }: Props) {
  const { slug } = await params;
  const page = sitePages[slug];
  if (!page) notFound();
  const images = pageImages[slug] ?? [];
  return (
    <main className={`interior-page page-${slug}`}>
      <InteriorHeader />
      <section className="interior-hero">
        <div className="interior-stars" aria-hidden="true"><span /><i /><b /></div>
        <div className="interior-hero-copy">
          <p className="eyebrow"><span /> {page.eyebrow}</p>
          <h1>{page.title}<br /><em>{page.accent}</em></h1>
          <p>{page.description}</p>
        </div>
        <div className="interior-status"><span>{page.number} / 12</span><b>{page.status}</b></div>
      </section>

      <section className="interior-body">
        {slug === 'search' ? <SiteSearch /> : (
          <>
            <ClubExperience section={slug} />
            <div className="interior-grid">
              {page.cards.map((card, index) => (
                <article className="interior-card" key={card.title}>
                  <div className={`card-graphic graphic-${index + 1}`}>
                    {images[index] ? <img src={images[index]} alt={card.title} /> : <><span /><i /><b /></>}
                  </div>
                  <div className="interior-card-copy"><span>{card.eyebrow}</span><h2>{card.title}</h2><p>{card.copy}</p>{card.meta && <small>{card.meta}</small>}</div>
                </article>
              ))}
            </div>
            <div className="verified-sources">
              <span>Explore official channels</span>
              <Link href="https://mitwpu.edu.in/cosmos" target="_blank" rel="noreferrer">MIT-WPU COSMOS page ↗</Link>
              <Link href="https://mitwpu.edu.in/events/space-axpo-2026-brings-space-science-innovation-and-exploration-to-mit-wpu" target="_blank" rel="noreferrer">Space Axpo report ↗</Link>
              <Link href="https://mitwpu.edu.in/cosmos" target="_blank" rel="noreferrer">University club source ↗</Link>
              <Link href="https://mitwpu.edu.in/cosmos" target="_blank" rel="noreferrer">Club information ↗</Link>
            </div>
            <div className="interior-details">
              <div><p className="eyebrow dark"><span /> Explore further</p><h2>{page.detailsTitle}</h2></div>
              <ol>{page.details.map((detail, index) => <li key={detail}><span>0{index + 1}</span><b>{detail}</b></li>)}</ol>
            </div>
          </>
        )}
        <div className="interior-cta"><span>Next step</span><h2>Ready to go further?</h2><Link className="button button-primary" href={page.ctaHref}>{page.cta} <b>↗</b></Link></div>
      </section>
      <InteriorFooter />
    </main>
  );
}
