import type { Metadata } from 'next';

import './globals.css';



export const metadata: Metadata = {
  title: 'COSMOS — Look Up. Go Beyond.',
  description: 'A single place to explore COSMOS events, projects, astronomy resources, gallery, team, and joining information.',
  metadataBase: new URL('https://cosmos-astronomy-club.bhavikachaudhari8983.chatgpt.site'),
  openGraph: {
    title: 'COSMOS — Look Up. Go Beyond.',
    description: 'Explore COSMOS events, projects, astronomy resources, gallery, and joining information.',
    images: [{ url: '/images/astronomy-study.svg', width: 1740, height: 909, alt: 'COSMOS — Look Up. Go Beyond.' }],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'COSMOS — Look Up. Go Beyond.',
    description: 'Explore COSMOS events, projects, astronomy resources, gallery, and joining information.',
    images: ['/images/astronomy-study.svg'],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className="antialiased"
      >
        <div className="demo-notice">Independent astronomy website concept by Bhavika. Not an official club website. Events and recruitment require club confirmation.</div>
        {children}
      </body>
    </html>
  );
}
