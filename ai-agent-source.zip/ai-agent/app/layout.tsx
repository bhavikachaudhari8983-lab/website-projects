import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {title:'AI Agent Studio — Build from an idea',description:'Create websites, browser games, and AI tools with natural language. Edit, preview, and export your code.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en" className="dark"><body>{children}</body></html>}
