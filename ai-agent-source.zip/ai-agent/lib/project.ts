export type Kind = 'website' | 'game' | 'ai';
export type Artifact = { title:string; summary:string; plan:string[]; html:string; css:string; js:string };
export type Revision = { id:string; createdAt:string; prompt:string; artifact:Artifact };
export type Project = { id:string; kind:Kind; revisions:Revision[] };
export const artifactSchema = {type:'object',additionalProperties:false,properties:{title:{type:'string'},summary:{type:'string'},plan:{type:'array',items:{type:'string'}},html:{type:'string'},css:{type:'string'},js:{type:'string'}},required:['title','summary','plan','html','css','js']};
export function validateArtifact(value:unknown):Artifact {
 if(!value||typeof value!=='object')throw new Error('The AI did not return a project. Try again.');
 const a=value as Artifact;
 for(const key of ['title','summary','html','css','js'] as const)if(typeof a[key]!=='string'||a[key].length>180000)throw new Error('Invalid project output: '+key);
 if(!a.html.trim()||!a.title.trim()||!Array.isArray(a.plan)||a.plan.length>20||a.plan.some(x=>typeof x!=='string'||x.length>2000))throw new Error('The project output was incomplete. Try again.');
 if(a.title.length>150||a.summary.length>5000)throw new Error('Project description is too long.');
 return {title:a.title,summary:a.summary,plan:a.plan,html:a.html,css:a.css,js:a.js};
}
export function parseProjects(raw:string):Project[]{const p=JSON.parse(raw);if(!Array.isArray(p)||p.length>30)throw new Error('Invalid workspace.');return p.map(x=>{if(typeof x.id!=='string'||!['website','game','ai'].includes(x.kind)||!Array.isArray(x.revisions)||!x.revisions.length||x.revisions.length>20)throw new Error('Invalid saved project.');return {id:x.id,kind:x.kind,revisions:x.revisions.map((r:Revision)=>{if(typeof r.id!=='string'||typeof r.prompt!=='string'||typeof r.createdAt!=='string')throw new Error('Invalid revision.');return {...r,artifact:validateArtifact(r.artifact)}})}})}
export function extractResponse(data:unknown):string{
 if(!data||typeof data!=='object')throw new Error('Invalid provider response.');
 const response=data as Record<string,unknown>;
 if(response.status==='incomplete')throw new Error('Generation reached its output limit. Try a smaller request.');
 const content:Record<string,unknown>[]=[];
 for(const entry of Array.isArray(response.output)?response.output:[]){
  if(!entry||typeof entry!=='object')continue;
  for(const item of Array.isArray((entry as Record<string,unknown>).content)?(entry as {content:unknown[]}).content:[]){if(item&&typeof item==='object')content.push(item as Record<string,unknown>);}
 }
 if(content.some(item=>item.type==='refusal'))throw new Error('The model declined this request. Try a different project description.');
 const text=content.filter(item=>item.type==='output_text'&&typeof item.text==='string').map(item=>item.text as string).join('');
 if(!text)throw new Error('The model returned no output.');return text;
}
