# AI Agent Studio

A browser project-builder prototype, not a universal autonomous coding agent.

## Working features

Built-in website/game/AI-tool examples, a sandboxed live preview, editable HTML/CSS/JavaScript, browser-local projects, version history, workspace backup/import, and source ZIP export. Custom generation and AI replies use the visitor's OpenAI API account; examples and manual editing require no API key. API keys stay in tab memory and are forwarded to OpenAI only for requests, not saved in project history or exports.

## Run

Node.js 22+. `npm ci`, `npm run build`, then `npm run dev -- --port 5182`. Open http://localhost:5182.

## Limits

No API key is bundled. Live provider requests have not been exercised in this preparation task and may incur charges on the visitor's account. Generated artifacts require review. The app does not run arbitrary terminal code, train models, or deploy generated projects. The research section is dated desk research, not a current ranking or subscription test.

Build, lint and TypeScript checks passed. The website example rendered in the sandbox. Public deployment is pending.
