export type Role = "member" | "captain" | "organizer" | "admin" | "super_admin";
export type RideStatus =
  | "draft"
  | "registration_open"
  | "registration_closed"
  | "upcoming"
  | "active"
  | "completed"
  | "cancelled";
export type RegistrationStatus =
  | "pending"
  | "approved"
  | "waitlisted"
  | "rejected"
  | "cancelled"
  | "checked_in"
  | "completed";
export type Ride = {
  id: string;
  title: string;
  destination: string;
  description: string;
  ride_date: string;
  assembly_time: string;
  departure_time: string;
  expected_return: string | null;
  meeting_point: string;
  distance_km: number;
  difficulty: string;
  capacity: number;
  status: RideStatus;
  required_gear: string;
  safety_instructions: string;
  route_info: string;
  latitude: number | null;
  longitude: number | null;
  registration_opens: string;
  registration_deadline: string;
  minimum_experience: string;
  cover_url: string | null;
  captain_id: string | null;
  sweep_id: string | null;
  organizer_id: string | null;
  created_by: string | null;
};
export type Profile = {
  id: string;
  full_name: string;
  email: string;
  student_id: string | null;
  phone: string | null;
  program: string | null;
  academic_year: number | null;
  experience: string;
  preferred_pace: string;
  emergency_contact: string | null;
  emergency_relationship: string | null;
  blood_group: string | null;
  avatar_path: string | null;
};
export type Registration = {
  id: string;
  ride_id: string;
  user_id: string;
  status: RegistrationStatus;
  created_at: string;
  rides?: Ride;
};
