import { z } from "zod";
export const idSchema = z.string().uuid();
const text = (max = 200) => z.string().trim().min(1).max(max);
const optional = z
  .string()
  .trim()
  .max(200)
  .optional()
  .transform((v) => v || null);
export const profileSchema = z.object({
  full_name: text(100).min(2),
  student_id: optional,
  phone: optional,
  program: optional,
  academic_year: z.coerce.number().int().min(1).max(8),
  experience: z.enum(["beginner", "intermediate", "experienced"]),
  preferred_pace: z.enum(["relaxed", "steady"]),
  emergency_contact: optional,
  emergency_relationship: optional,
  blood_group: z
    .enum(["", "A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"])
    .transform((v) => v || null),
});
export const bikeSchema = z.object({
  manufacturer: text(80),
  model: text(80),
  registration_identifier: text(30),
  engine_cc: z.coerce.number().int().min(1).max(3000),
  year: z.coerce.number().int().min(1950).max(2100),
  category: z.enum([
    "street",
    "touring",
    "adventure",
    "cruiser",
    "sport",
    "scooter",
  ]),
  status: z.enum(["active", "inactive"]),
});
export const rideSchema = z
  .object({
    title: text(120).min(3),
    destination: text(),
    description: text(5000),
    ride_date: z.iso.date(),
    assembly_time: z.string().regex(/^\d{2}:\d{2}$/),
    departure_time: z.string().regex(/^\d{2}:\d{2}$/),
    meeting_point: text(),
    distance_km: z.coerce.number().int().min(1).max(3000),
    difficulty: z.enum(["easy", "moderate", "challenging"]),
    capacity: z.coerce.number().int().min(1).max(500),
    minimum_experience: z.enum(["beginner", "intermediate", "experienced"]),
    required_gear: text(2000),
    safety_instructions: text(3000),
    route_info: text(2000),
    registration_opens: text(),
    registration_deadline: text(),
    latitude: z.preprocess(
      (v) => (v === "" ? null : v),
      z.coerce.number().min(-90).max(90).nullable(),
    ),
    longitude: z.preprocess(
      (v) => (v === "" ? null : v),
      z.coerce.number().min(-180).max(180).nullable(),
    ),
    expected_return: z
      .string()
      .optional()
      .transform((v) => v || null),
    captain_id: z.union([idSchema, z.literal("")]).transform((v) => v || null),
    sweep_id: z.union([idSchema, z.literal("")]).transform((v) => v || null),
  })
  .refine((v) => v.departure_time >= v.assembly_time, {
    message: "Departure must follow assembly",
  })
  .refine(
    (v) =>
      Date.parse(v.registration_deadline) > Date.parse(v.registration_opens),
    { message: "Registration deadline must follow opening" },
  )
  .refine(
    (v) =>
      Date.parse(v.registration_deadline) <=
      Date.parse(`${v.ride_date}T23:59:59+05:30`),
    { message: "Registration must close by the ride date" },
  );
export const incidentSchema = z.object({
  ride_id: idSchema,
  type: z.enum([
    "puncture",
    "mechanical",
    "fuel",
    "separated",
    "minor",
    "medical",
    "emergency",
    "other",
  ]),
  description: text(2000).min(5),
  location: optional,
});
export function safeNext(value: string | null) {
  return value &&
    value.startsWith("/") &&
    !value.startsWith("//") &&
    !value.includes("\\")
    ? value
    : "/dashboard";
}
