import "server-only";
import { createClient } from "@/lib/supabase/server";
import { isConfigured } from "@/lib/config";
import { sampleRides } from "@/lib/seed-data";
import type { Ride } from "@/types/domain";
export async function getRides() {
  if (!isConfigured()) return sampleRides;
  const db = await createClient();
  const { data, error } = await db
    .from("rides")
    .select("*")
    .neq("status", "draft")
    .order("ride_date");
  if (error) throw new Error("Rides could not be loaded. Please try again.");
  return data as Ride[];
}
export async function getRide(id: string) {
  if (!isConfigured()) return sampleRides.find((r) => r.id === id) ?? null;
  const db = await createClient();
  const { data, error } = await db
    .from("rides")
    .select("*")
    .eq("id", id)
    .maybeSingle();
  if (error) throw new Error("Ride could not be loaded.");
  return data as Ride | null;
}
