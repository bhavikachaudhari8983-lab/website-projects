export const brand = {
  name: "MIT-WPU Riders Hub",
  short: "RIDERS HUB",
  institution: "MIT-WPU",
  location: "Pune, Maharashtra",
  description:
    "Good roads. Better company. A safety-first riding community at MIT-WPU.",
};
export const isConfigured = () =>
  Boolean(
    process.env.NEXT_PUBLIC_SUPABASE_URL &&
    process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY,
  );
export const safetyItems = [
  "Helmet",
  "Riding gear",
  "Driving licence",
  "Fuel",
  "Tyres",
  "Brakes",
  "Lights",
  "Emergency contact",
  "Basic bike condition",
] as const;
