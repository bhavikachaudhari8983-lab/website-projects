// Replace these representative images with approved club photography here.
export const media = {
  hero: {
    src: "/images/riders-hero.jpg",
    alt: "A helmeted motorcyclist on a winding mountain road at sunset",
    credit: "Isaac Mitchell",
    source:
      "https://unsplash.com/photos/a-person-riding-a-motorcycle-on-a-mountain-road-n1PVZb71EB4",
  },
  community: {
    src: "/images/riders-community.jpg",
    alt: "Helmeted riders travelling together on a rural road",
    credit: "DM David",
    source:
      "https://unsplash.com/photos/a-motorcycle-convoy-rides-down-a-rural-road--WmUttQmXvc",
  },
  road: {
    src: "/images/riders-road.jpg",
    alt: "A winding mountain road through a dark green forest",
    credit: "Andrei R. Popescu",
    source:
      "https://unsplash.com/photos/a-winding-road-in-the-middle-of-a-mountain-kpNVfTT7pZs",
  },
};
export const inspirationGallery = [
  {
    id: "road",
    src: media.road.src,
    alt: media.road.alt,
    title: "Take the scenic route.",
    location: "Mountain road / inspiration",
    date: "Representative photography",
    credit: media.road.credit,
  },
  {
    id: "community",
    src: media.community.src,
    alt: media.community.alt,
    title: "Good company. Great roads.",
    location: "On the road / inspiration",
    date: "Representative photography",
    credit: media.community.credit,
  },
  {
    id: "hero",
    src: media.hero.src,
    alt: media.hero.alt,
    title: "Chasing the horizon.",
    location: "Mountain pass / inspiration",
    date: "Representative photography",
    credit: media.hero.credit,
  },
];
