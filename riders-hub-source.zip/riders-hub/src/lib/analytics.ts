export function summarize(
  registrations: { status: string; ride_id: string }[],
  rides: { id: string; distance_km: number; status: string }[],
  checks: { status: string }[],
) {
  const completed = registrations.filter((r) => r.status === "completed");
  const eligible = registrations.filter((r) =>
    ["approved", "checked_in", "completed"].includes(r.status),
  );
  const attended = eligible.filter((r) =>
    ["checked_in", "completed"].includes(r.status),
  );
  const finalized = new Set(
    rides.filter((r) => r.status === "completed").map((r) => r.id),
  );
  const finalEligible = eligible.filter((r) => finalized.has(r.ride_id));
  return {
    completedRides: rides.filter((r) => r.status === "completed").length,
    participations: completed.length,
    clubKm: completed.reduce(
      (sum, r) =>
        sum + (rides.find((x) => x.id === r.ride_id)?.distance_km ?? 0),
      0,
    ),
    attendance: finalEligible.length
      ? Math.round(
          (finalEligible.filter((r) => r.status === "completed").length /
            finalEligible.length) *
            100,
        )
      : null,
    safety: checks.length
      ? Math.round(
          (checks.filter((c) => c.status === "organizer_verified").length /
            checks.length) *
            100,
        )
      : null,
    checkedIn: attended.length,
  };
}
