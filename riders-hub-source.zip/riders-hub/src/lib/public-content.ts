export const content: Record<
  string,
  {
    eyebrow: string;
    title: string;
    intro: string;
    sections: { title: string; text: string }[];
  }
> = {
  about: {
    eyebrow: "THE PEOPLE BEHIND THE HELMETS",
    title: "A shared love of the road.",
    intro:
      "Riders Hub is designed for the MIT-WPU riding community: a place to plan responsibly, learn together and make every member feel included.",
    sections: [
      {
        title: "Everyone starts somewhere.",
        text: "New to group riding? Start with an easy ride, join a safety workshop, and learn the signals and formation from your captain. Confidence grows through preparation.",
      },
      {
        title: "The community comes first.",
        text: "We ride as a group, respect other road users and the places we visit, and leave no rider behind. Public roads are never a racetrack.",
      },
      {
        title: "A club with continuity.",
        text: "Ride records, committee history and shared responsibilities stay with the club as new students take the lead.",
      },
    ],
  },
  safety: {
    eyebrow: "OUR NON-NEGOTIABLE",
    title: "A safe return. Every time.",
    intro:
      "Responsible riding starts before the engine does. Check your gear, know your route, and be honest about your readiness.",
    sections: [
      {
        title: "Before every ride",
        text: "Check helmet, riding gear, driving licence, fuel, tyres, brakes, lights, emergency contact and basic bike condition. Complete your self-check, then attend organizer verification.",
      },
      {
        title: "On the road",
        text: "Attend the briefing, follow your captain, keep a safe following distance and respect posted limits. Never overtake the captain or leave the group without informing the team. Take breaks when tired.",
      },
      {
        title: "If something goes wrong",
        text: "Move to safety when possible and alert your captain. This platform is not an emergency-response service. For serious emergencies, contact official emergency services immediately. Do not wait for an app response.",
      },
      {
        title: "What we never reward",
        text: "No fastest-rider rankings, speed challenges or dangerous distance competitions. Our milestones celebrate participation, learning, safety and service.",
      },
    ],
  },
  join: {
    eyebrow: "THERE IS A PLACE FOR YOU HERE",
    title: "Find your riding community.",
    intro:
      "Create your Rider Passport to begin. Membership approval helps the committee keep the community accountable and prepared.",
    sections: [
      {
        title: "01 / Create your account",
        text: "Sign up using your college email and verify your address. Never share account credentials with another rider.",
      },
      {
        title: "02 / Make your passport yours",
        text: "Add your student information, experience, emergency contact and bike. Private details stay behind member and authorized organizer access.",
      },
      {
        title: "03 / Join your first ride",
        text: "After membership approval, apply for a suitable ride. Complete the safety checklist, meet your organizer for verification, and collect your digital Ride Pass.",
      },
    ],
  },
  contact: {
    eyebrow: "STAY CONNECTED",
    title: "Talk to your ride team.",
    intro:
      "For a specific ride, use the captain and assembly details provided in your Rider Passport. The club’s verified public contact information will be published here after committee review.",
    sections: [
      {
        title: "Membership and general questions",
        text: "The committee directory lists published club representatives. No unverified student contact details are displayed on this site.",
      },
      {
        title: "Ride-day support",
        text: "Contact your assigned captain directly for urgent ride-day questions. Incident reports support recordkeeping and are not continuously monitored.",
      },
    ],
  },
  privacy: {
    eyebrow: "PRIVACY BY DEFAULT",
    title: "Your information has a purpose.",
    intro:
      "Rider information supports membership, ride preparation and safe group operations. It is not a public student directory.",
    sections: [
      {
        title: "Private member records",
        text: "Student IDs, phone numbers, emergency contacts, optional blood group and bike registration identifiers are protected. Members access their own records; authorized staff access participant information needed for assigned rides.",
      },
      {
        title: "Public club content",
        text: "Only published events, committee display names and roles, partners, achievements and moderated gallery images are public. Obtain consent before uploading identifiable photographs.",
      },
      {
        title: "Secure passes",
        text: "QR codes contain a random server-validated identifier, never your raw contact or student information. Treat your pass like a ticket and keep it private.",
      },
      {
        title: "Account and retention requests",
        text: "Contact the club committee to request access, corrections or account deletion. Before production launch, the committee must approve retention periods, a contact channel and the final privacy policy.",
      },
    ],
  },
};
