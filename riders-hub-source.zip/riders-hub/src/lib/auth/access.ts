import "server-only";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { isConfigured } from "@/lib/config";
import type { Role } from "@/types/domain";
export async function requireUser() {
  if (!isConfigured()) redirect("/login?setup=1");
  const db = await createClient();
  const {
    data: { user },
    error,
  } = await db.auth.getUser();
  if (error || !user) redirect("/login");
  if (!user.email_confirmed_at) redirect("/login?verify=1");
  const { data: roles, error: roleError } = await db
    .from("user_roles")
    .select("role")
    .eq("user_id", user.id);
  if (roleError) throw new Error("Unable to verify access. Please try again.");
  return { db, user, roles: (roles ?? []).map((r) => r.role as Role) };
}
export async function requireStaff(adminOnly = false) {
  const context = await requireUser();
  const allowed = adminOnly
    ? ["admin", "super_admin"]
    : ["captain", "organizer", "admin", "super_admin"];
  if (!context.roles.some((r) => allowed.includes(r)))
    redirect("/unauthorized");
  return context;
}
