import Image from "next/image";
import { Compass } from "lucide-react";
export type DigitalPassData = {
  id: string;
  riderName: string;
  riderNumber: string;
  rideTitle: string;
  rideNumber: string;
  date: string;
  group: string;
  captain: string;
  route: string;
  safety: string;
  checkIn: string;
  inactive: boolean;
  qr: string;
};
export function DigitalPass({ pass }: { pass: DigitalPassData }) {
  return (
    <article className="pass" aria-label="Digital Ride Pass">
      <div className="pass-top">
        <div className="pass-brandline">
          <span>
            <Compass
              size={16}
              style={{
                display: "inline",
                verticalAlign: "middle",
                marginRight: 8,
              }}
            />
            MIT-WPU / RIDERS
          </span>
          <p className="eyebrow">DIGITAL CREDENTIAL</p>
        </div>
        <h2>{pass.rideTitle}</h2>
        <p className="pass-route">{pass.route}</p>
      </div>
      <div className="pass-main">
        <p className="pass-rider-label">RIDER / {pass.riderNumber}</p>
        <h3>{pass.riderName}</h3>
        <dl>
          <div>
            <dt>RIDE NUMBER</dt>
            <dd>{pass.rideNumber}</dd>
          </div>
          <div>
            <dt>RIDE DATE</dt>
            <dd>{pass.date}</dd>
          </div>
          <div>
            <dt>RIDING GROUP</dt>
            <dd>{pass.group}</dd>
          </div>
          <div>
            <dt>CAPTAIN</dt>
            <dd>{pass.captain}</dd>
          </div>
          <div>
            <dt>SAFETY</dt>
            <dd>{pass.safety}</dd>
          </div>
          <div>
            <dt>CHECK-IN</dt>
            <dd>{pass.checkIn}</dd>
          </div>
        </dl>
        <div className="pass-status">
          <span>
            <span className="status-dot" />
            {pass.inactive ? "PASS INACTIVE" : "CLEARED FOR ASSEMBLY"}
          </span>
          <span>MIT-WPU →</span>
        </div>
      </div>
      <div className="pass-tear" />
      <div className="pass-scan">
        {pass.inactive ? (
          <p>
            Pass inactive or expired. Contact the organizer if you need help.
          </p>
        ) : (
          <Image
            className="pass-qr"
            src={pass.qr}
            width={240}
            height={240}
            alt="Secure Ride Pass QR code for organizer check-in"
            unoptimized
          />
        )}
        <small>PASS / {pass.id}</small>
        <p>
          Show to your organizer at assembly.
          <br />
          Keep the QR code private.
        </p>
      </div>
    </article>
  );
}
