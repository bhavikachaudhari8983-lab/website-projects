import Link from "next/link";
import { logout } from "@/app/auth/actions";
export function WorkspaceNav({ admin = false }: { admin?: boolean }) {
  const links = admin
    ? [
        ["/admin", "Overview"],
        ["/admin/rides", "Rides & operations"],
        ["/admin/check-in", "QR check-in"],
        ["/admin/members", "Members"],
        ["/admin/records", "Club records"],
        ["/admin/analytics", "Analytics"],
        ["/dashboard", "My passport"],
      ]
    : [
        ["/dashboard", "Passport"],
        ["/dashboard/profile", "Profile & bikes"],
        ["/dashboard/rides", "My rides"],
        ["/dashboard/passes", "Ride passes"],
        ["/dashboard/incidents", "Report an incident"],
      ];
  return (
    <>
      <nav
        className="workspace-nav"
        aria-label={admin ? "Organizer navigation" : "Member navigation"}
      >
        {links.map(([url, label]) => (
          <Link key={url} href={url}>
            {label}
          </Link>
        ))}
      </nav>
      <form action={logout} style={{ textAlign: "right", marginBottom: 20 }}>
        <button
          style={{
            background: "none",
            border: 0,
            color: "var(--muted)",
            fontSize: 14,
          }}
        >
          Sign out
        </button>
      </form>
    </>
  );
}
