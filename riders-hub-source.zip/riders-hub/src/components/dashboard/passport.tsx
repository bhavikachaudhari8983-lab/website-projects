import Image from "next/image";
import { ArrowUpRight } from "lucide-react";
import { Badge, ButtonLink, Stat } from "@/components/ui";
import { RouteStrip } from "@/components/home/featured-ride";
import { media } from "@/lib/media";
import type { Ride } from "@/types/domain";
export function PassportIdentity({
  name,
  number,
  status,
  completed,
  km,
  safety,
}: {
  name: string;
  number: string;
  status: string;
  completed: number;
  km: number;
  safety: number;
}) {
  return (
    <section className="passport-shell">
      <div className="passport-heading">
        <div>
          <p className="eyebrow">MIT-WPU / RIDER PASSPORT</p>
          <h2>{name}</h2>
          <p>RIDER / {number}</p>
        </div>
        <Badge tone={status === "active" ? "green" : "orange"}>
          {status === "active" ? "● ACTIVE MEMBER" : status}
        </Badge>
      </div>
      <div className="stats">
        <Stat value={completed} label="Rides completed" />
        <Stat value={km} label="Club kilometres" />
        <Stat value={safety} label="Safety checks" />
      </div>
    </section>
  );
}
export function NextRideCockpit({
  ride,
  registrationId,
  status,
}: {
  ride: Ride;
  registrationId: string;
  status: string;
}) {
  return (
    <section className="cockpit-next">
      <Image
        src={media.road.src}
        alt="Mountain road inspiration"
        fill
        sizes="(max-width: 700px) 100vw, 70vw"
      />
      <p className="eyebrow">NEXT RIDE / {ride.ride_date}</p>
      <h2>{ride.destination}</h2>
      <div className="ride-meta">
        <span>{ride.departure_time.slice(0, 5)} IST</span>
        <span>{ride.distance_km} KM</span>
        <Badge>{status}</Badge>
      </div>
      <RouteStrip stops={[ride.meeting_point, ride.destination]} />
      <ButtonLink href={`/dashboard/safety/${registrationId}`}>
        Ride preparation <ArrowUpRight size={17} />
      </ButtonLink>
    </section>
  );
}
