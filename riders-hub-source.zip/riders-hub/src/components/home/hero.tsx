import Image from "next/image";
import { ArrowDown, ArrowUpRight } from "lucide-react";
import { ButtonLink } from "@/components/ui";
import { RouteLine } from "@/components/motion/reveal";
import { media } from "@/lib/media";
export function Hero() {
  return (
    <section className="cinematic-hero" aria-labelledby="hero-heading">
      <Image
        className="hero-photograph"
        src={media.hero.src}
        alt={media.hero.alt}
        fill
        sizes="100vw"
        preload
        quality={85}
      />
      <div className="hero-shade" />
      <div className="hero-content">
        <p className="eyebrow">
          <span className="status-dot" /> MIT-WPU MOTORCYCLE COMMUNITY
        </p>
        <h1 id="hero-heading">
          RIDE TOGETHER.
          <br />
          <span>RIDE RESPONSIBLY.</span>
        </h1>
        <div className="hero-lower">
          <p>
            A community built around
            <br />
            riding, safety and exploration.
          </p>
          <div className="actions">
            <ButtonLink href="/rides">
              Explore rides <ArrowUpRight size={18} />
            </ButtonLink>
            <ButtonLink href="/join" secondary>
              Join riders <ArrowUpRight size={18} />
            </ButtonLink>
          </div>
        </div>
      </div>
      <div className="hero-route">
        <RouteLine />
        <span>START / MIT-WPU, PUNE</span>
      </div>
      <div className="hero-bottom">
        <a className="scroll-cue" href="#club">
          <span className="scroll-circle">
            <ArrowDown size={17} />
          </span>
          SCROLL TO EXPLORE
        </a>
        <span className="hero-coordinate">
          18.5184° N &nbsp; 73.8157° E<br />
          <b>GOOD ROADS. BETTER COMPANY.</b>
        </span>
        <span className="hero-edition">
          THE RIDERS JOURNAL
          <br />
          <b>01 — THE BEGINNING</b>
        </span>
      </div>
    </section>
  );
}
