import Link from "next/link";
import Image from "next/image";
import {
  ArrowUpRight,
  ShieldCheck,
  HardHat,
  Shirt,
  Wrench,
  Users,
  HeartHandshake,
  Compass,
  Flag,
} from "lucide-react";
import { ButtonLink } from "@/components/ui";
import { Reveal, AnimatedNumber } from "@/components/motion/reveal";
import { media } from "@/lib/media";
export function ClubIdentity() {
  return (
    <section className="identity-section section-shell" id="club">
      <div className="section-rail">
        <span>01</span>
        <i />
        <span>THE CLUB</span>
      </div>
      <Reveal className="identity-layout">
        <p className="eyebrow">ONE CAMPUS. COUNTLESS ROADS.</p>
        <h2>
          DIFFERENT BIKES.
          <br />
          SAME <span className="outline-text">DIRECTION.</span>
        </h2>
        <div className="identity-description">
          <p>
            It starts with a shared love of two wheels. It becomes early starts,
            open roads, and people who look out for each other.
          </p>
          <p>
            From your first group ride to your next big adventure, find your
            place in the MIT-WPU riding community.
          </p>
          <Link href="/about" className="text-link">
            Meet the club <ArrowUpRight size={17} />
          </Link>
        </div>
        <span className="identity-stamp">
          <Compass size={45} strokeWidth={1} />
          <small>
            PUNE ROOTS
            <br />
            OPEN ROADS
          </small>
        </span>
      </Reveal>
    </section>
  );
}
export function ClubStats({
  stats,
  sample,
}: {
  stats: {
    members: number | null;
    rides: number | null;
    km: number | null;
    attendance: number | null;
  };
  sample: boolean;
}) {
  return (
    <section className="club-statistics section-shell">
      <div className="statistics-top">
        <p className="eyebrow">THE JOURNEY, SO FAR.</p>
        <span>
          {sample
            ? "SAMPLE METRICS / DEVELOPMENT PREVIEW"
            : "VERIFIED CLUB RECORDS"}
        </span>
      </div>
      <div className="big-stats">
        {[
          { value: stats.members, label: "COMMUNITY MEMBERS", suffix: "" },
          { value: stats.rides, label: "RIDES COMPLETED", suffix: "" },
          { value: stats.km, label: "CLUB KILOMETRES", suffix: "" },
          { value: stats.attendance, label: "ATTENDANCE", suffix: "%" },
        ].map((s) => (
          <div key={s.label}>
            <strong>
              <AnimatedNumber value={s.value} suffix={s.suffix} />
            </strong>
            <span>{s.label}</span>
          </div>
        ))}
      </div>
    </section>
  );
}
export function Experience() {
  return (
    <section className="experience-section section-shell">
      <Reveal>
        <div className="section-top">
          <div>
            <p className="eyebrow">03 / MORE THAN THE DESTINATION</p>
            <h2>
              THIS IS WHAT
              <br />
              WE RIDE FOR.
            </h2>
          </div>
          <p>
            Not the fastest route.
            <br />
            The moments along the way.
          </p>
        </div>
      </Reveal>
      <div className="experience-image">
        <Image
          src={media.community.src}
          alt={media.community.alt}
          fill
          sizes="(max-width: 700px) 100vw, 90vw"
        />
        <div className="experience-caption">
          <span>
            THE RIDE IS BETTER
            <br />
            WHEN IT IS SHARED.
          </span>
          <small>REPRESENTATIVE RIDING PHOTOGRAPHY</small>
        </div>
      </div>
      <div className="experience-values">
        {[
          [
            "01",
            "Explore more",
            "Leave the familiar behind. Find a new perspective around the next bend.",
          ],
          [
            "02",
            "Learn together",
            "Build confidence through workshops, shared knowledge and steady progress.",
          ],
          [
            "03",
            "Belong somewhere",
            "Different courses, different bikes. One community that has your back.",
          ],
        ].map(([n, title, text]) => (
          <div key={n}>
            <small>{n} /</small>
            <h3>{title}</h3>
            <p>{text}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
export function SafetyStatement() {
  return (
    <section className="safety-statement" id="safety">
      <div className="section-shell">
        <Reveal>
          <p className="eyebrow">04 / OUR NON-NEGOTIABLE</p>
          <h2>
            THE BEST RIDE
            <br />
            IS THE ONE
            <br />
            <span>EVERYONE RETURNS FROM.</span>
          </h2>
        </Reveal>
        <div className="safety-bottom">
          <p>
            Good preparation is part of the adventure.
            <br />
            Every rider. Every bike. Every time.
          </p>
          <ButtonLink href="/safety" secondary>
            Our safety promise <ArrowUpRight size={18} />
          </ButtonLink>
        </div>
        <div className="safety-principles">
          {[
            [HardHat, "HELMET ON"],
            [Shirt, "GEAR UP"],
            [Wrench, "BIKE CHECKED"],
            [Users, "RIDE TOGETHER"],
            [ShieldCheck, "STAY RESPONSIBLE"],
          ].map(([Icon, label]) => {
            const Symbol = Icon as typeof ShieldCheck;
            return (
              <div key={String(label)}>
                <Symbol size={27} strokeWidth={1.3} />
                <span>{String(label)}</span>
              </div>
            );
          })}
        </div>
      </div>
      <span className="safety-watermark" aria-hidden="true">
        RETURN.
      </span>
    </section>
  );
}
export function Milestones() {
  return (
    <section className="milestone-section section-shell">
      <Reveal>
        <div className="section-top">
          <div>
            <p className="eyebrow">05 / EARNED, NOT RACED</p>
            <h2>THE MILES THAT MATTER.</h2>
          </div>
          <Link href="/achievements" className="text-link">
            All achievements <ArrowUpRight size={17} />
          </Link>
        </div>
      </Reveal>
      <div className="milestone-row">
        {[
          [Flag, "FIRST RIDE", "Your first chapter with the community."],
          [ShieldCheck, "SAFE RIDER", "Prepared. Responsible. Consistent."],
          [HeartHandshake, "VOLUNTEER", "Showing up for your fellow riders."],
        ].map(([Icon, title, text], i) => {
          const Symbol = Icon as typeof Flag;
          return (
            <div key={String(title)} className="milestone">
              <div className="milestone-emblem">
                <Symbol size={35} strokeWidth={1.1} />
              </div>
              <div>
                <small>ACHIEVEMENT / 0{i + 1}</small>
                <h3>{String(title)}</h3>
                <p>{String(text)}</p>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
export function Community() {
  return (
    <section className="community-section section-shell">
      <Reveal className="community-copy">
        <p className="eyebrow">06 / FIND YOUR PEOPLE</p>
        <h2>
          YOUR TRIBE.
          <br />
          YOUR NEXT
          <br />
          <span className="outline-text">CHAPTER.</span>
        </h2>
        <p>
          Come for the motorcycles. Stay for the people.
          <br />A shared road is only the beginning.
        </p>
        <ButtonLink href="/join">
          Find your community <ArrowUpRight size={18} />
        </ButtonLink>
      </Reveal>
      <div className="community-photo">
        <Image
          src={media.community.src}
          alt={media.community.alt}
          fill
          sizes="(max-width: 700px) 100vw, 45vw"
        />
        <span>TOGETHER IS A BETTER WAY TO GO.</span>
      </div>
    </section>
  );
}
export function JoinCta() {
  return (
    <section className="join-section">
      <div className="section-shell">
        <p className="eyebrow">08 / YOUR NEXT CHAPTER</p>
        <Reveal>
          <h2>
            THE ROAD
            <br />
            IS <span>CALLING.</span>
          </h2>
        </Reveal>
        <div className="join-bottom">
          <p>
            Bring your passion. We will bring the company.
            <br />
            Your Rider Passport starts here.
          </p>
          <ButtonLink href="/join">
            Join MIT-WPU Riders <ArrowUpRight size={19} />
          </ButtonLink>
        </div>
        <div className="join-route">
          <span className="route-node" />
          <i />
          <span>MIT-WPU</span>
          <i />
          <span className="route-node" />
          <b>YOU ARE HERE.</b>
        </div>
      </div>
    </section>
  );
}
