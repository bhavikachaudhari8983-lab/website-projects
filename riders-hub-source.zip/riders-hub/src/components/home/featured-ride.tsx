import Image from "next/image";
import { ArrowUpRight } from "lucide-react";
import { ButtonLink } from "@/components/ui";
import { Reveal } from "@/components/motion/reveal";
import { media } from "@/lib/media";
import type { Ride } from "@/types/domain";
export function RouteStrip({
  stops = ["MIT-WPU", "MULSHI", "TAMHINI GHAT"],
}: {
  stops?: string[];
}) {
  return (
    <div className="route-strip" aria-label={`Route: ${stops.join(" to ")}`}>
      {stops.map((stop, i) => (
        <div className="route-stop" key={`${i}-${stop}`}>
          <span className="route-node" />
          <small>
            {i === 0
              ? "START"
              : i === stops.length - 1
                ? "DESTINATION"
                : `CHECKPOINT 0${i}`}
          </small>
          <b>{stop}</b>
        </div>
      ))}
    </div>
  );
}
export function FeaturedRide({
  ride,
  occupied,
  sample,
}: {
  ride: Ride;
  occupied: number | null;
  sample: boolean;
}) {
  const date = new Date(`${ride.ride_date}T12:00:00`);
  return (
    <section className="featured-ride" id="next-ride">
      <div className="featured-image">
        <Image
          src={media.road.src}
          alt="Representative mountain switchbacks; not the verified ride route"
          fill
          sizes="100vw"
          quality={85}
        />
        <div className="featured-image-shade" />
      </div>
      <div className="featured-content">
        <Reveal>
          <p className="eyebrow">
            <span className="section-number">02 /</span>{" "}
            {sample ? "THE NEXT ROAD / SAMPLE RIDE" : "THE NEXT ROAD"}
          </p>
          <h2>
            {ride.destination.split(" ").map((word, i) => (
              <span key={i}>
                {word}
                <br />
              </span>
            ))}
          </h2>
        </Reveal>
        <div className="featured-aside">
          <span className="ride-index">
            RIDE / {ride.id.slice(0, 4).toUpperCase()}
          </span>
          <p className="featured-date">
            {date.toLocaleDateString("en-IN", {
              day: "2-digit",
              month: "long",
            })}
            <br />
            {ride.departure_time.slice(0, 5)} AM / IST
          </p>
          <div className="featured-facts">
            <div>
              <strong>
                {ride.distance_km}
                <small> KM</small>
              </strong>
              <span>ROUND TRIP</span>
            </div>
            <div>
              <strong>{ride.difficulty}</strong>
              <span>RIDE LEVEL</span>
            </div>
            <div>
              <strong>
                {occupied ?? "—"}
                <small> / {ride.capacity}</small>
              </strong>
              <span>{sample ? "SAMPLE CAPACITY" : "APPROVED RIDERS"}</span>
            </div>
          </div>
          <ButtonLink href={`/rides/${ride.id}`}>
            View ride <ArrowUpRight size={18} />
          </ButtonLink>
        </div>
        <div className="featured-route">
          <RouteStrip
            stops={ride.route_info
              .split("→")
              .slice(0, 4)
              .map((s) => s.trim())}
          />
          <span className="coordinates">
            {ride.latitude?.toFixed(4)}° N / {ride.longitude?.toFixed(4)}° E
            <br />
            ROUTE OVERVIEW · NOT FOR NAVIGATION
          </span>
        </div>
      </div>
    </section>
  );
}
