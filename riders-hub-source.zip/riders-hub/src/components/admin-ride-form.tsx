import { ActionForm, type Field } from "@/components/ui/action-form";
export function AdminRideForm({
  people,
}: {
  people: { id: string; full_name: string }[];
}) {
  const opts = (v: string[]) => v.map((value) => ({ value, label: value }));
  const leaders = [
    { value: "", label: "Assign later" },
    ...people.map((p) => ({ value: p.id, label: p.full_name })),
  ];
  const fields: Field[] = [
    { name: "title", label: "Ride title", required: true },
    { name: "destination", label: "Destination", required: true },
    {
      name: "description",
      label: "Description",
      type: "textarea",
      required: true,
    },
    { name: "ride_date", label: "Ride date", type: "date", required: true },
    {
      name: "assembly_time",
      label: "Assembly time (IST)",
      type: "time",
      required: true,
    },
    {
      name: "departure_time",
      label: "Departure time (IST)",
      type: "time",
      required: true,
    },
    {
      name: "expected_return",
      label:
        "Expected return (include timezone, e.g. 2026-10-18T14:00:00+05:30)",
    },
    { name: "meeting_point", label: "Meeting point", required: true },
    {
      name: "distance_km",
      label: "Distance (km)",
      type: "number",
      min: 1,
      max: 3000,
      required: true,
    },
    {
      name: "capacity",
      label: "Maximum participants",
      type: "number",
      min: 1,
      max: 500,
      required: true,
    },
    {
      name: "difficulty",
      label: "Difficulty",
      options: opts(["easy", "moderate", "challenging"]),
    },
    {
      name: "minimum_experience",
      label: "Minimum experience",
      options: opts(["beginner", "intermediate", "experienced"]),
    },
    {
      name: "required_gear",
      label: "Required gear",
      type: "textarea",
      required: true,
    },
    {
      name: "safety_instructions",
      label: "Safety instructions",
      type: "textarea",
      required: true,
    },
    {
      name: "route_info",
      label: "Route information",
      type: "textarea",
      required: true,
    },
    {
      name: "latitude",
      label: "Destination latitude",
      type: "number",
      min: -90,
      max: 90,
    },
    {
      name: "longitude",
      label: "Destination longitude",
      type: "number",
      min: -180,
      max: 180,
    },
    {
      name: "registration_opens",
      label: "Registration opens (include timezone)",
      required: true,
      help: "For example: 2026-10-01T09:00:00+05:30",
    },
    {
      name: "registration_deadline",
      label: "Registration closes (include timezone)",
      required: true,
    },
    { name: "captain_id", label: "Ride captain", options: leaders },
    { name: "sweep_id", label: "Sweep rider", options: leaders },
  ];
  return (
    <ActionForm action="ride" fields={fields} submit="Create draft ride" />
  );
}
