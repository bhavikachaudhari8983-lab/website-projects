"use client";
import Image from "next/image";
import { useRef, useState } from "react";
import { X, ArrowLeft, ArrowRight, ArrowUpRight } from "lucide-react";
import { motion, useReducedMotion } from "motion/react";
export type GalleryPhoto = {
  id: string;
  src: string;
  alt: string;
  title: string;
  location: string;
  date: string;
  credit: string;
};
export function EditorialGallery({ photos }: { photos: GalleryPhoto[] }) {
  const dialog = useRef<HTMLDialogElement>(null);
  const [index, setIndex] = useState(0);
  const reduced = useReducedMotion();
  const active = photos[index];
  function close() {
    dialog.current?.close();
  }
  function open(i: number) {
    setIndex(i);
    dialog.current?.showModal();
  }
  function move(direction: number) {
    setIndex((i) => (i + direction + photos.length) % photos.length);
  }
  if (!photos.length) return null;
  return (
    <>
      <div className="editorial-gallery">
        {photos.map((photo, i) => (
          <button
            className={`editorial-image editorial-image-${i % 3}`}
            key={photo.id}
            onClick={() => open(i)}
            aria-label={`Open photograph: ${photo.title}`}
          >
            <Image
              src={photo.src}
              alt={photo.alt}
              fill
              sizes={
                i % 3 === 0
                  ? "(max-width: 700px) 100vw, 54vw"
                  : "(max-width: 700px) 100vw, 40vw"
              }
              unoptimized={photo.src.startsWith("https://")}
            />
            <span className="gallery-image-overlay" />
            <span className="image-sequence">FRAME / 0{i + 1}</span>
            <span className="image-caption">
              <small>{photo.location}</small>
              <strong>{photo.title}</strong>
              <span className="image-date">{photo.date}</span>
            </span>
            <span className="image-expand">
              <ArrowUpRight size={24} />
            </span>
          </button>
        ))}
      </div>
      <dialog
        className="gallery-lightbox"
        ref={dialog}
        aria-label="Photo viewer"
        onKeyDown={(e) => {
          if (e.key === "ArrowRight") move(1);
          if (e.key === "ArrowLeft") move(-1);
        }}
      >
        <button
          className="lightbox-close"
          onClick={close}
          aria-label="Close photo viewer"
        >
          <X size={26} />
        </button>
        <motion.div
          key={active.id}
          initial={reduced ? false : { opacity: 0.4 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.2 }}
          className="lightbox-image"
        >
          <Image
            src={active.src}
            alt={active.alt}
            fill
            sizes="90vw"
            style={{ objectFit: "contain" }}
            unoptimized={active.src.startsWith("https://")}
          />
        </motion.div>
        <div className="lightbox-bottom">
          <div>
            <h3>{active.title}</h3>
            <p>
              {active.location} · {active.date}
              <br />
              Photo: {active.credit}
            </p>
          </div>
          <div className="lightbox-controls">
            <button onClick={() => move(-1)} aria-label="Previous photograph">
              <ArrowLeft size={22} />
            </button>
            <span>
              {index + 1} / {photos.length}
            </span>
            <button onClick={() => move(1)} aria-label="Next photograph">
              <ArrowRight size={22} />
            </button>
          </div>
        </div>
      </dialog>
    </>
  );
}
