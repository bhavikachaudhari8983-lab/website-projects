"use client";
import { useActionState } from "react";
import Link from "next/link";
import { mutate } from "@/app/dashboard/actions";
export type Field = {
  name: string;
  label: string;
  type?: string;
  required?: boolean;
  options?: { value: string; label: string }[];
  value?: string | number;
  min?: number;
  max?: number;
  help?: string;
};
export function ActionForm({
  action,
  hidden = {},
  fields = [],
  submit = "Save",
  children,
}: {
  action: string;
  hidden?: Record<string, string>;
  fields?: Field[];
  submit?: string;
  children?: React.ReactNode;
}) {
  const [state, formAction, pending] = useActionState(mutate, { message: "" });
  return (
    <form action={formAction}>
      <input type="hidden" name="action" value={action} />
      {Object.entries(hidden).map(([k, v]) => (
        <input key={k} type="hidden" name={k} value={v} />
      ))}
      {fields.map((f) => (
        <label className="field" key={f.name}>
          {f.label}
          {f.type === "textarea" ? (
            <textarea
              name={f.name}
              defaultValue={f.value}
              required={f.required}
              maxLength={5000}
            />
          ) : f.options ? (
            <select name={f.name} defaultValue={f.value} required={f.required}>
              {f.options.map((o) => (
                <option key={o.value} value={o.value}>
                  {o.label}
                </option>
              ))}
            </select>
          ) : (
            <input
              name={f.name}
              type={f.type || "text"}
              defaultValue={f.value}
              required={f.required}
              min={f.min}
              max={f.max}
              step={f.type === "number" ? "any" : undefined}
              maxLength={5000}
            />
          )}
          {f.help && <small className="muted">{f.help}</small>}
        </label>
      ))}
      {children}
      {state.message && (
        <p
          role="status"
          className={`form-message ${state.error ? "error" : ""}`}
        >
          {state.message}
          {state.href && (
            <>
              {" "}
              <Link style={{ textDecoration: "underline" }} href={state.href}>
                Continue →
              </Link>
            </>
          )}
        </p>
      )}
      <button className="primary" disabled={pending}>
        {pending ? "Saving…" : submit}
      </button>
    </form>
  );
}
export const options = (values: string[]) =>
  values.map((value) => ({ value, label: value.replaceAll("_", " ") }));
