"use client";
import { motion, useReducedMotion, useInView, animate } from "motion/react";
import { useEffect, useRef } from "react";
export function Reveal({
  children,
  className = "",
  delay = 0,
}: {
  children: React.ReactNode;
  className?: string;
  delay?: number;
}) {
  const reduce = useReducedMotion();
  return (
    <motion.div
      className={className}
      initial={false}
      whileInView={reduce ? {} : { y: [18, 0], opacity: [0.65, 1] }}
      viewport={{ once: true, amount: 0.12 }}
      transition={{ duration: 0.65, delay, ease: [0.2, 0.65, 0.3, 1] }}
    >
      {children}
    </motion.div>
  );
}
export function AnimatedNumber({
  value,
  suffix = "",
}: {
  value: number | null;
  suffix?: string;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const visible = useInView(ref, { once: true });
  const reduce = useReducedMotion();
  useEffect(() => {
    if (!visible || reduce || value === null || !ref.current) return;
    const control = animate(0, value, {
      duration: 1.3,
      ease: "easeOut",
      onUpdate: (latest) => {
        if (ref.current)
          ref.current.textContent =
            Math.round(latest).toLocaleString("en-IN") + suffix;
      },
    });
    return () => control.stop();
  }, [visible, reduce, value, suffix]);
  return (
    <span
      ref={ref}
      aria-label={value === null ? "Not available" : `${value}${suffix}`}
    >
      {value === null ? "—" : value.toLocaleString("en-IN") + suffix}
    </span>
  );
}
export function RouteLine({ className = "" }: { className?: string }) {
  const reduce = useReducedMotion();
  return (
    <svg
      className={`route-line ${className}`}
      viewBox="0 0 490 190"
      fill="none"
      aria-hidden="true"
    >
      <path
        d="M12 162H106L153 115H247L306 55H370L413 12H478"
        stroke="currentColor"
        strokeOpacity=".25"
      />
      <motion.path
        d="M12 162H106L153 115H247L306 55H370L413 12H478"
        stroke="currentColor"
        strokeWidth="1.5"
        initial={false}
        whileInView={reduce ? {} : { pathLength: [0, 1] }}
        viewport={{ once: true }}
        transition={{ duration: 2, ease: "easeInOut" }}
      />
      {[
        [12, 162],
        [153, 115],
        [306, 55],
        [478, 12],
      ].map(([cx, cy], i) => (
        <g key={i}>
          <circle cx={cx} cy={cy} r="5" fill="currentColor" />
          <circle
            cx={cx}
            cy={cy}
            r="10"
            stroke="currentColor"
            strokeOpacity=".3"
          />
        </g>
      ))}
    </svg>
  );
}
