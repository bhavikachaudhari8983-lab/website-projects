"use client";
import { useEffect, useRef, useState, useActionState } from "react";
import { mutate } from "@/app/dashboard/actions";
type Detector = {
  detect: (video: HTMLVideoElement) => Promise<{ rawValue: string }[]>;
};
export function QrScanner({
  rides,
  initial,
}: {
  rides: { id: string; title: string }[];
  initial: string;
}) {
  const video = useRef<HTMLVideoElement>(null);
  const stream = useRef<MediaStream | null>(null);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);
  const [token, setToken] = useState("");
  const [notice, setNotice] = useState("");
  const [state, action, pending] = useActionState(mutate, { message: "" });
  const [scanning, setScanning] = useState(false);
  function stop() {
    stream.current?.getTracks().forEach((t) => t.stop());
    if (timer.current) clearInterval(timer.current);
    setScanning(false);
  }
  useEffect(
    () => () => {
      stream.current?.getTracks().forEach((t) => t.stop());
      if (timer.current) clearInterval(timer.current);
    },
    [],
  );
  async function scan() {
    const Native = (
      window as unknown as {
        BarcodeDetector?: new (options: { formats: string[] }) => Detector;
      }
    ).BarcodeDetector;
    if (!Native) {
      setNotice(
        "Camera scanning is not supported by this browser. Use an external scanner or enter the secure code.",
      );
      return;
    }
    try {
      stream.current = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
      });
      if (video.current) {
        video.current.srcObject = stream.current;
        await video.current.play();
      }
      setScanning(true);
      setNotice("Point the camera at a Ride Pass QR code.");
      const detector = new Native({ formats: ["qr_code"] });
      timer.current = setInterval(async () => {
        if (!video.current) return;
        try {
          const codes = await detector.detect(video.current);
          if (codes[0]) {
            setToken(codes[0].rawValue);
            stop();
            setNotice("Code captured. Confirm the ride before checking in.");
          }
        } catch {
          stop();
          setNotice("Scanning stopped. Enter the code below.");
        }
      }, 500);
    } catch {
      stop();
      setNotice("Camera access was unavailable. Enter the code below.");
    }
  }
  return (
    <div className="panel">
      <form action={action}>
        <input type="hidden" name="action" value="checkin" />
        <label className="field">
          Ride
          <select name="ride_id" defaultValue={initial} required>
            {rides.map((r) => (
              <option value={r.id} key={r.id}>
                {r.title}
              </option>
            ))}
          </select>
        </label>
        <video
          ref={video}
          playsInline
          muted
          style={{
            width: "100%",
            maxHeight: 260,
            display: scanning ? "block" : "none",
          }}
          aria-label="QR scanner camera preview"
        />
        <button
          type="button"
          className="button secondary"
          onClick={scanning ? stop : scan}
        >
          {scanning ? "Stop camera" : "Scan with camera"}
        </button>
        {notice && (
          <p role="status" style={{ marginTop: 15 }}>
            {notice}
          </p>
        )}
        <label className="field" style={{ marginTop: 20 }}>
          Secure pass code
          <input
            name="token"
            value={token}
            onChange={(e) => setToken(e.target.value)}
            required
            placeholder="riders-pass:…"
            autoComplete="off"
          />
        </label>
        <p className="muted">
          A USB scanner can type directly into this field. Only secure QR tokens
          are accepted.
        </p>
        {state.message && (
          <p
            role="status"
            className={`form-message ${state.error ? "error" : ""}`}
          >
            {state.message}
          </p>
        )}
        <button className="primary" disabled={pending || !rides.length}>
          {pending ? "Validating…" : "Validate & check in"}
        </button>
      </form>
    </div>
  );
}
