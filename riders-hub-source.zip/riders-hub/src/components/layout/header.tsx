"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { Compass, ArrowUpRight, Menu, X } from "lucide-react";
import { brand } from "@/lib/config";
const links = [
  ["/about", "Club"],
  ["/rides", "Rides"],
  ["/events", "Events"],
  ["/safety", "Safety"],
  ["/gallery", "Gallery"],
  ["/achievements", "Achievements"],
];
export function Header() {
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const dialog = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const update = () => setScrolled(window.scrollY > 30);
    update();
    window.addEventListener("scroll", update, { passive: true });
    return () => window.removeEventListener("scroll", update);
  }, []);
  function close() {
    dialog.current?.close();
  }
  function open() {
    dialog.current?.showModal();
  }
  return (
    <>
      <header
        className={`site-header ${pathname === "/" ? "over-hero" : ""} ${scrolled ? "is-scrolled" : ""}`}
      >
        <Link href="/" className="brand" aria-label={`${brand.name} home`}>
          <span className="brand-icon">
            <Compass size={29} strokeWidth={1.5} />
          </span>
          <span>
            <small>MIT-WPU</small>
            <b>
              RIDERS<span className="orange-text"> /</span>
            </b>
          </span>
        </Link>
        <nav className="desktop-nav" aria-label="Main navigation">
          {links.map(([url, label]) => (
            <Link
              key={url}
              href={url}
              aria-current={pathname === url ? "page" : undefined}
            >
              {label}
            </Link>
          ))}
        </nav>
        <Link href="/dashboard" className="header-cta">
          Member login <ArrowUpRight size={16} />
        </Link>
        <button
          className="mobile-menu-trigger"
          aria-label="Open navigation menu"
          onClick={open}
        >
          <Menu size={25} />
        </button>
      </header>
      <dialog ref={dialog} className="mobile-nav-dialog">
        <div className="mobile-nav-top">
          <span className="eyebrow">MIT-WPU / RIDERS</span>
          <button onClick={close} aria-label="Close navigation menu">
            <X size={28} />
          </button>
        </div>
        <nav aria-label="Mobile navigation">
          {links.map(([url, label], i) => (
            <Link href={url} key={url} onClick={close}>
              <small>0{i + 1}</small>
              {label}
              <ArrowUpRight size={25} />
            </Link>
          ))}
        </nav>
        <Link className="button" href="/dashboard" onClick={close}>
          Open Rider Passport <ArrowUpRight size={18} />
        </Link>
        <p className="mobile-nav-bottom">
          18.5184° N / 73.8157° E<br />
          PUNE ROOTS. OPEN ROADS.
        </p>
      </dialog>
    </>
  );
}
