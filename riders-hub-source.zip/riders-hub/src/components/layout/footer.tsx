import Link from "next/link";
import { ArrowUpRight, Compass } from "lucide-react";
import { brand } from "@/lib/config";
export function Footer() {
  return (
    <footer className="premium-footer">
      <div className="footer-main">
        <div>
          <Link className="brand" href="/" aria-label={`${brand.name} home`}>
            <span className="brand-icon">
              <Compass size={32} strokeWidth={1.2} />
            </span>
            <span>
              <small>MIT-WPU</small>
              <b>
                RIDERS<span className="orange-text"> /</span>
              </b>
            </span>
          </Link>
          <p>
            One community. Many roads.
            <br />
            Always, a safe return.
          </p>
        </div>
        <nav aria-label="Footer club navigation">
          <span className="eyebrow">THE COMMUNITY</span>
          {[
            ["/about", "The club"],
            ["/rides", "Our rides"],
            ["/events", "Events & workshops"],
            ["/committee", "The committee"],
          ].map(([href, text]) => (
            <Link key={href} href={href}>
              {text}
            </Link>
          ))}
        </nav>
        <nav aria-label="Footer resources">
          <span className="eyebrow">THE ESSENTIALS</span>
          {[
            ["/safety", "Ride responsibly"],
            ["/gallery", "The gallery"],
            ["/partners", "Our partners"],
            ["/contact", "Get in touch"],
          ].map(([href, text]) => (
            <Link key={href} href={href}>
              {text}
            </Link>
          ))}
        </nav>
        <div className="footer-passport">
          <span className="eyebrow">YOUR NEXT CHAPTER</span>
          <Link href="/dashboard">
            Rider Passport <ArrowUpRight size={22} />
          </Link>
          <small>YOUR RIDES. YOUR PEOPLE. YOUR PROGRESS.</small>
        </div>
      </div>
      <div className="footer-base">
        <span>MIT-WPU RIDERS HUB / PUNE, INDIA</span>
        <span>18.5184° N &nbsp; 73.8157° E</span>
        <Link href="/privacy">Privacy & data</Link>
      </div>
      <p className="affiliation-note">
        Independent club-platform concept. Institutional affiliation and public
        content require club approval before launch.
      </p>
    </footer>
  );
}
