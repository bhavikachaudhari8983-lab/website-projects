"use client";
import { useActionState } from "react";
import { uploadGallery } from "@/app/admin/records/upload";
export function GalleryUpload({
  albums,
}: {
  albums: { id: string; title: string }[];
}) {
  const [state, action, pending] = useActionState(uploadGallery, {
    message: "",
  });
  return (
    <form action={action}>
      <label className="field">
        Album
        <select name="album_id" required>
          {albums.map((a) => (
            <option key={a.id} value={a.id}>
              {a.title}
            </option>
          ))}
        </select>
      </label>
      <label className="field">
        Image (up to 8 MB)
        <input
          name="image"
          type="file"
          accept="image/jpeg,image/png,image/webp"
          required
        />
      </label>
      <label className="field">
        Caption / alternative text
        <input name="caption" required maxLength={300} />
      </label>
      <label className="field">
        Photographer credit
        <input name="credit" maxLength={150} />
      </label>
      <label className="field">
        Date taken
        <input name="taken_on" type="date" />
      </label>
      {state.message && (
        <p
          className={`form-message ${state.error ? "error" : ""}`}
          role="status"
        >
          {state.message}
        </p>
      )}
      <button className="primary" disabled={pending || !albums.length}>
        {pending ? "Uploading…" : "Upload for moderation"}
      </button>
    </form>
  );
}
