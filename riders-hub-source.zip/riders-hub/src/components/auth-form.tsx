"use client";
import { useActionState } from "react";
import Link from "next/link";
import { authAction } from "@/app/auth/actions";
export function AuthForm({
  mode, enabled = false,
}: {
  mode: "login" | "signup" | "forgot" | "reset";
  enabled?: boolean;
}) {
  const [state, action, pending] = useActionState(authAction, { message: "" });
  const labels = {
    login: "Sign in",
    signup: "Create your account",
    forgot: "Send reset link",
    reset: "Update password",
  };
  if (!enabled) return <div className="sample-note"><p>This portfolio demo does not create accounts or collect credentials. Member workflows require a configured Supabase service and club approval.</p><Link href="/rides">Explore sample rides ↗</Link></div>;
  return (
    <form action={action}>
      <input type="hidden" name="mode" value={mode} />
      {mode === "signup" && (
        <label className="field">
          Full name
          <input
            name="full_name"
            required
            minLength={2}
            maxLength={100}
            autoComplete="name"
          />
        </label>
      )}
      {mode !== "reset" && (
        <label className="field">
          College email
          <input name="email" type="email" required autoComplete="email" />
        </label>
      )}
      {mode !== "forgot" && (
        <label className="field">
          Password
          <input
            name="password"
            type="password"
            required
            minLength={mode === "login" ? 1 : 12}
            maxLength={128}
            autoComplete={
              mode === "login" ? "current-password" : "new-password"
            }
          />
          {mode !== "login" && (
            <small className="muted">At least 12 characters.</small>
          )}
        </label>
      )}
      {state.message && (
        <p
          role="status"
          className={`form-message ${state.error ? "error" : ""}`}
        >
          {state.message}
        </p>
      )}
      <button className="primary" disabled={pending}>
        {pending ? "Please wait…" : labels[mode]}
      </button>
      <div className="auth-links">
        <Link href={mode === "login" ? "/signup" : "/login"}>
          {mode === "login" ? "New here? Join the club" : "Back to sign in"}
        </Link>
        {mode === "login" && (
          <Link href="/forgot-password">Forgot password?</Link>
        )}
      </div>
    </form>
  );
}
