"use client";
import { useEffect, useState } from "react";
import { flushSync } from "react-dom";
import { z } from "zod";
import { RideCard } from "./ride-card";
import { EmptyState } from "@/components/ui";
import type { Ride } from "@/types/domain";
type WebMCP = {
  registerTool: (
    tool: {
      name: string;
      description: string;
      inputSchema: object;
      annotations: object;
      execute: (input: unknown) => unknown;
    },
    options: { signal: AbortSignal },
  ) => Promise<void> | void;
};
const filterSchema = z.object({
  query: z.string().max(120),
  period: z.enum(["upcoming", "past", "all"]),
});
export function RideBrowser({ rides }: { rides: Ride[] }) {
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("upcoming");
  useEffect(() => {
    const context = (document as Document & { modelContext?: WebMCP })
      .modelContext;
    if (!context) return;
    const lifecycle = new AbortController();
    try {
      void Promise.resolve(
        context.registerTool(
          {
            name: "filter_club_rides",
            description:
              "Filter the visible ride catalogue by destination and time period. Does not register a rider.",
            inputSchema: {
              type: "object",
              properties: {
                query: { type: "string", maxLength: 120 },
                period: { type: "string", enum: ["upcoming", "past", "all"] },
              },
              required: ["query", "period"],
              additionalProperties: false,
            },
            annotations: { readOnlyHint: true, untrustedContentHint: true },
            execute(input) {
              const value = filterSchema.parse(input);
              flushSync(() => {
                setQuery(value.query);
                setFilter(value.period);
              });
              return { query: value.query, period: value.period };
            },
          },
          { signal: lifecycle.signal },
        ),
      ).catch(() => {});
    } catch {}
    return () => lifecycle.abort();
  }, []);
  const filtered = rides.filter(
    (r) =>
      `${r.title} ${r.destination}`
        .toLowerCase()
        .includes(query.toLowerCase()) &&
      (filter === "all" ||
        (filter === "past" && r.status === "completed") ||
        (filter === "upcoming" &&
          !["completed", "cancelled"].includes(r.status))),
  );
  return (
    <>
      <div className="filter-bar">
        <input
          aria-label="Search rides"
          placeholder="Search a destination…"
          value={query}
          maxLength={120}
          onChange={(e) => setQuery(e.target.value)}
        />
        <select
          aria-label="Ride period"
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
        >
          <option value="upcoming">Upcoming rides</option>
          <option value="past">Past rides</option>
          <option value="all">All rides</option>
        </select>
      </div>
      <div className="ride-grid">
        {filtered.map((r, i) => (
          <RideCard key={r.id} ride={r} index={i} />
        ))}
      </div>
      {!filtered.length && (
        <EmptyState title="No rides on this road yet">
          Try another search or check back for the next announcement.
        </EmptyState>
      )}
    </>
  );
}
