import Link from "next/link";
import Image from "next/image";
import { media } from "@/lib/media";
import { ArrowUpRight, Route, Mountain, Users } from "lucide-react";
import { Badge } from "@/components/ui";
import type { Ride } from "@/types/domain";
export function RideCard({ ride, index = 0 }: { ride: Ride; index?: number }) {
  return (
    <article className="ride-card">
      <div className={`ride-art ${index % 2 ? "alternate" : ""}`}>
        <Image
          src={index % 2 ? media.community.src : media.road.src}
          alt="Representative motorcycle journey photography"
          fill
          sizes="(max-width: 700px) 100vw, 45vw"
        />
        <Badge tone={ride.status === "registration_open" ? "green" : "neutral"}>
          {ride.status.replaceAll("_", " ")}
        </Badge>
        <span className="ride-date">
          {new Date(`${ride.ride_date}T12:00:00`).toLocaleDateString("en-IN", {
            day: "2-digit",
            month: "long",
            year: "numeric",
          })}
        </span>
      </div>
      <div className="ride-body">
        <h3>
          <Link href={`/rides/${ride.id}`}>{ride.title}</Link>
        </h3>
        <div className="ride-meta">
          <span>
            <Route size={16} />
            {ride.distance_km} km
          </span>
          <span>
            <Mountain size={16} />
            {ride.difficulty}
          </span>
          <span>
            <Users size={16} />
            {ride.capacity} riders max
          </span>
        </div>
        <div className="ride-bottom">
          <span>{ride.destination}</span>
          <Link
            href={`/rides/${ride.id}`}
            aria-label={`Explore ${ride.destination}`}
            className="orange-text"
          >
            Explore ride{" "}
            <ArrowUpRight size={17} style={{ display: "inline" }} />
          </Link>
        </div>
      </div>
    </article>
  );
}
