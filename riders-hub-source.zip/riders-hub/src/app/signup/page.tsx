import { AuthForm } from "@/components/auth-form";
export default function Signup() {
  return (
    <div className="auth-box">
      <p className="eyebrow">FIND YOUR PEOPLE</p>
      <h1>Your journey starts here.</h1>
      <p>
        Create an account, verify your email, and complete your rider profile.
        The committee reviews membership requests.
      </p>
      <AuthForm mode="signup" />
    </div>
  );
}
