import { ButtonLink } from "@/components/ui";
export default function NotFound() {
  return (
    <div className="container">
      <p className="eyebrow">404 / A DIFFERENT ROAD</p>
      <h1>That page is not here.</h1>
      <ButtonLink href="/">Back to the hub</ButtonLink>
    </div>
  );
}
