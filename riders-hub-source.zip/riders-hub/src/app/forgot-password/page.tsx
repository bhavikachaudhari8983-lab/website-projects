import { AuthForm } from "@/components/auth-form";
export default function Forgot() {
  return (
    <div className="auth-box">
      <h1>Reset your password.</h1>
      <p>We will email you a secure reset link.</p>
      <AuthForm mode="forgot" />
    </div>
  );
}
