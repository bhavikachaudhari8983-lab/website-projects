"use server";
import { redirect } from "next/navigation";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { isConfigured } from "@/lib/config";
export type ActionState = { message: string; error?: boolean };
export async function authAction(
  _: ActionState,
  form: FormData,
): Promise<ActionState> {
  if (!isConfigured())
    return {
      error: true,
      message:
        "Member access is not connected yet. Configure Supabase using the setup guide.",
    };
  const mode = String(form.get("mode"));
  const db = await createClient();
  const email = z.email().safeParse(form.get("email"));
  const password = z.string().min(12).max(128).safeParse(form.get("password"));
  const origin = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";
  if (mode !== "reset" && !email.success)
    return { error: true, message: "Enter a valid email address." };
  if (mode === "forgot") {
    await db.auth.resetPasswordForEmail(email.data!, {
      redirectTo: `${origin}/auth/callback?next=/reset-password`,
    });
    return {
      message:
        "If an account exists, a password reset link will arrive in your inbox.",
    };
  }
  if (mode === "signup") {
    if (!password.success)
      return {
        error: true,
        message: "Choose a password between 12 and 128 characters.",
      };
    const name = z
      .string()
      .trim()
      .min(2)
      .max(100)
      .safeParse(form.get("full_name"));
    if (!name.success) return { error: true, message: "Enter your full name." };
    const domain = process.env.ALLOWED_EMAIL_DOMAIN?.toLowerCase();
    if (domain && !email.data!.toLowerCase().endsWith(`@${domain}`))
      return { error: true, message: `Use your ${domain} email address.` };
    const { error } = await db.auth.signUp({
      email: email.data!,
      password: password.data,
      options: {
        data: { full_name: name.data },
        emailRedirectTo: `${origin}/auth/callback`,
      },
    });
    return error
      ? {
          error: true,
          message: "Sign-up could not be completed. Try again shortly.",
        }
      : {
          message:
            "Check your email to verify your account, then sign in. Your membership will need club approval.",
        };
  }
  if (mode === "reset") {
    if (!password.success)
      return {
        error: true,
        message: "Choose a password between 12 and 128 characters.",
      };
    const {
      data: { user },
    } = await db.auth.getUser();
    if (!user)
      return {
        error: true,
        message: "Open a valid reset link from your email first.",
      };
    const { error } = await db.auth.updateUser({ password: password.data });
    if (error)
      return {
        error: true,
        message: "Password update failed. Request a new reset link.",
      };
    await db.auth.signOut();
    redirect("/login?reset=1");
  }
  if (mode !== "login") return { error: true, message: "Invalid action." };
  const loginPassword = z
    .string()
    .min(1)
    .max(128)
    .safeParse(form.get("password"));
  if (!loginPassword.success)
    return { error: true, message: "Enter your password." };
  const { error } = await db.auth.signInWithPassword({
    email: email.data!,
    password: loginPassword.data,
  });
  if (error)
    return {
      error: true,
      message: "Unable to sign in. Check your details and verify your email.",
    };
  redirect("/dashboard");
}
export async function logout() {
  const db = await createClient();
  await db.auth.signOut();
  redirect("/");
}
