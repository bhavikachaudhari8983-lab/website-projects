import Image from "next/image";
import { notFound } from "next/navigation";
import { getRide } from "@/lib/data";
import { Badge, ButtonLink, PageHeading } from "@/components/ui";
import { isConfigured } from "@/lib/config";
import { createClient } from "@/lib/supabase/server";
import { idSchema } from "@/lib/validators";
export const dynamic = "force-dynamic";
export default async function RideDetail({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  if (!idSchema.safeParse(id).success) notFound();
  const r = await getRide(id);
  if (!r) notFound();
  let occupied: number | null = null;
  if (isConfigured()) {
    const db = await createClient();
    const { data, error } = await db.rpc("ride_capacity", { rid: id });
    if (error) throw new Error("Capacity could not be loaded");
    occupied = data;
  }
  const mapToken = process.env.NEXT_PUBLIC_MAPBOX_TOKEN;
  return (
    <div className="container">
      <PageHeading eyebrow={r.destination} title={r.title} />
      <div className="detail-grid">
        <div>
          <div
            className="ride-art"
            style={{ height: 340, borderRadius: 8 }}
            role="img"
            aria-label="Representative mountain motorcycle ride"
          />
          <div className="panel" style={{ marginTop: 25 }}>
            <Badge tone="green">{r.status.replaceAll("_", " ")}</Badge>
            <h2 style={{ marginTop: 25, fontSize: "2rem" }}>The ride ahead</h2>
            <p>{r.description}</p>
            <h3>Route</h3>
            <p>{r.route_info}</p>
            {mapToken && r.latitude && r.longitude && (
              <a
                href={`https://www.openstreetmap.org/?mlat=${r.latitude}&mlon=${r.longitude}#map=11/${r.latitude}/${r.longitude}`}
                target="_blank"
                rel="noreferrer"
              >
                <Image
                  width={800}
                  height={300}
                  unoptimized
                  className="map-frame"
                  src={`https://api.mapbox.com/styles/v1/mapbox/outdoors-v12/static/pin-s+fb783d(${r.longitude},${r.latitude})/${r.longitude},${r.latitude},10/800x300?access_token=${encodeURIComponent(mapToken)}`}
                  alt={`Destination map of ${r.destination}`}
                  loading="lazy"
                />
              </a>
            )}
            <h3>Gear & preparation</h3>
            <p>{r.required_gear}</p>
            <h3>Safety briefing</h3>
            <p>{r.safety_instructions}</p>
          </div>
        </div>
        <aside>
          <div className="panel">
            <p className="eyebrow">RIDE DETAILS</p>
            <h3>
              {new Date(`${r.ride_date}T12:00:00`).toLocaleDateString("en-IN", {
                dateStyle: "long",
              })}
            </h3>
            <dl className="stack">
              {[
                ["Assembly", `${r.assembly_time.slice(0, 5)} IST`],
                ["Departure", `${r.departure_time.slice(0, 5)} IST`],
                ["Meeting point", r.meeting_point],
                ["Distance", `${r.distance_km} km round trip`],
                ["Difficulty", r.difficulty],
                ["Minimum experience", r.minimum_experience],
                [
                  "Places",
                  occupied === null
                    ? `${r.capacity} maximum (sample)`
                    : `${occupied} / ${r.capacity} approved`,
                ],
                [
                  "Registration closes",
                  new Date(r.registration_deadline).toLocaleString("en-IN", {
                    timeZone: "Asia/Kolkata",
                  }),
                ],
              ].map(([label, value]) => (
                <div key={label}>
                  <dt className="muted">{label}</dt>
                  <dd style={{ margin: 0 }}>{value}</dd>
                </div>
              ))}
            </dl>
            <div className="actions">
              <ButtonLink href={`/dashboard/apply/${r.id}`}>
                Apply for this ride ↗
              </ButtonLink>
            </div>
            <small className="muted">
              Membership approval and verified pre-ride checks are required.
              Applying does not guarantee a place.
            </small>
          </div>
        </aside>
      </div>
    </div>
  );
}
