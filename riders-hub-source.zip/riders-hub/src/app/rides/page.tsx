import { PageHeading } from "@/components/ui";
import { RideBrowser } from "@/components/rides/ride-browser";
import { getRides } from "@/lib/data";
import { isConfigured } from "@/lib/config";
export const dynamic = "force-dynamic";
export default async function Rides() {
  const rides = await getRides();
  return (
    <div className="container">
      <PageHeading
        eyebrow="CHOOSE YOUR NEXT CHAPTER"
        title="Good roads ahead."
        description="Small groups, shared moments, and safety at every turn."
      />
      {!isConfigured() && (
        <p className="sample-note">
          Fictional development rides. Dates and capacity are sample content.
        </p>
      )}
      <RideBrowser rides={rides} />
    </div>
  );
}
