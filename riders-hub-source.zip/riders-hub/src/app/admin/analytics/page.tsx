import { requireStaff } from "@/lib/auth/access";
import { summarize } from "@/lib/analytics";
import { PageHeading, Stat } from "@/components/ui";
export default async function Analytics() {
  const { db } = await requireStaff(true);
  const q = await Promise.all([
    db.from("rides").select("id,distance_km,status,ride_date"),
    db.from("ride_registrations").select("ride_id,status"),
    db.from("safety_checklists").select("status"),
    db.from("club_memberships").select("status,joined_at"),
    db.from("events").select("type"),
    db.from("incidents").select("status"),
  ]);
  if (q.some((r) => r.error)) throw new Error("Analytics unavailable");
  const [rides, regs, checks, members, events, incidents] = q;
  const s = summarize(regs.data ?? [], rides.data ?? [], checks.data ?? []);
  const months = new Map<string, number>();
  members.data?.forEach((m) => {
    const month = m.joined_at?.slice(0, 7);
    if (month) months.set(month, (months.get(month) ?? 0) + 1);
  });
  return (
    <>
      <PageHeading
        eyebrow="CLUB HEALTH"
        title="Participation with purpose."
        description="Club kilometres count completed participant-rides. Attendance uses completed rides only; future approvals do not lower the rate."
      />
      <div className="grid-3">
        {[
          ["Members", members.data?.length ?? 0],
          [
            "Active members",
            members.data?.filter((m) => m.status === "active").length ?? 0,
          ],
          ["Completed rides", s.completedRides],
          ["Completed participations", s.participations],
          ["Club kilometres", s.clubKm],
          ["Attendance rate", s.attendance === null ? "—" : `${s.attendance}%`],
          ["Verified safety checks", s.safety === null ? "—" : `${s.safety}%`],
          ["Events", events.data?.length ?? 0],
          ["Reported incidents", incidents.data?.length ?? 0],
        ].map(([label, value]) => (
          <div className="panel" key={label}>
            <Stat label={String(label)} value={value} />
          </div>
        ))}
      </div>
      <div className="panel">
        <h2 style={{ fontSize: "2rem" }}>Membership growth</h2>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Month joined</th>
                <th>New members</th>
              </tr>
            </thead>
            <tbody>
              {[...months].sort().map(([month, count]) => (
                <tr key={month}>
                  <td>{month}</td>
                  <td>{count}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {!months.size && <p>Growth will appear once members join.</p>}
      </div>
      <p>
        Safety completion is verified checklists divided by all submitted
        registration checklists. Cancelled registrations remain in the
        historical denominator. No speed or risky-distance rankings are
        collected.
      </p>
    </>
  );
}
