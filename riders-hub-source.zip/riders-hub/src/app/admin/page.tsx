import { requireStaff } from "@/lib/auth/access";
import { PageHeading, Stat, ButtonLink } from "@/components/ui";
export default async function Admin() {
  const { db, roles } = await requireStaff();
  const admin = roles.some((r) => ["admin", "super_admin"].includes(r));
  const queries = await Promise.all([
    db.from("rides").select("id,status"),
    db.from("ride_registrations").select("status"),
    db.from("incidents").select("status"),
    db.from("club_memberships").select("status"),
  ]);
  if (queries.some((q) => q.error)) throw new Error("Operations unavailable");
  const [rides, regs, incidents, members] = queries;
  return (
    <>
      <PageHeading
        eyebrow="CLUB CONTROL ROOM"
        title="Good rides start here."
        description={
          admin
            ? "Manage the community and keep every ride accountable."
            : "Your assigned rides and permitted participant records."
        }
      />
      <div className="grid-3">
        {[
          [
            admin ? "Total members" : "Visible members",
            members.data?.length ?? 0,
          ],
          [
            "Upcoming rides",
            rides.data?.filter((r) =>
              ["registration_open", "registration_closed", "upcoming"].includes(
                r.status,
              ),
            ).length ?? 0,
          ],
          [
            "Pending applications",
            regs.data?.filter((r) => r.status === "pending").length ?? 0,
          ],
          [
            "Approved riders",
            regs.data?.filter((r) => r.status === "approved").length ?? 0,
          ],
          [
            "Checked in",
            regs.data?.filter((r) => r.status === "checked_in").length ?? 0,
          ],
          [
            "Open incidents",
            incidents.data?.filter((r) => r.status !== "resolved").length ?? 0,
          ],
        ].map(([label, value]) => (
          <div className="panel" key={label}>
            <Stat label={String(label)} value={value} />
          </div>
        ))}
      </div>
      <div className="actions">
        <ButtonLink href="/admin/rides">Manage rides →</ButtonLink>
        <ButtonLink href="/admin/check-in" secondary>
          Open check-in
        </ButtonLink>
      </div>
    </>
  );
}
