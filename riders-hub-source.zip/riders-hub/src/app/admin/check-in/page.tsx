import { requireStaff } from "@/lib/auth/access";
import { PageHeading } from "@/components/ui";
import { QrScanner } from "@/components/qr-scanner";
export default async function CheckIn({
  searchParams,
}: {
  searchParams: Promise<{ ride?: string }>;
}) {
  const { ride } = await searchParams;
  const { db } = await requireStaff();
  const { data, error } = await db
    .from("rides")
    .select("id,title")
    .in("status", [
      "registration_open",
      "registration_closed",
      "upcoming",
      "active",
    ]);
  if (error) throw new Error("Rides unavailable");
  return (
    <>
      <PageHeading
        eyebrow="ASSEMBLY DESK"
        title="One scan. Ready to ride."
        description="The server checks the ride, approval, membership, verified safety, pass expiry and previous attendance."
      />
      <div style={{ maxWidth: 650 }}>
        <QrScanner rides={data} initial={ride ?? data[0]?.id ?? ""} />
      </div>
    </>
  );
}
