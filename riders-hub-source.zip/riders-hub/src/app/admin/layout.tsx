import { requireStaff } from "@/lib/auth/access";
import { WorkspaceNav } from "@/components/dashboard/workspace-nav";
export const dynamic = "force-dynamic";
export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  await requireStaff();
  return (
    <div className="container">
      <WorkspaceNav admin />
      {children}
    </div>
  );
}
