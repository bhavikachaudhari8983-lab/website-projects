import { notFound } from "next/navigation";
import Link from "next/link";
import { requireStaff } from "@/lib/auth/access";
import { PageHeading, Badge, Stat, EmptyState } from "@/components/ui";
import { ActionForm } from "@/components/ui/action-form";
import { idSchema } from "@/lib/validators";
const opts = (v: string[]) =>
  v.map((value) => ({ value, label: value.replaceAll("_", " ") }));
export default async function Operations({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  if (!idSchema.safeParse(id).success) notFound();
  const { db } = await requireStaff();
  const { data: allowed, error: ae } = await db.rpc("manages_ride", {
    rid: id,
  });
  if (ae) throw new Error("Access unavailable");
  if (!allowed) notFound();
  const results = await Promise.all([
    db.from("rides").select("*").eq("id", id).single(),
    db
      .from("ride_registrations")
      .select(
        "*,profiles(full_name,email,phone,emergency_contact,emergency_relationship),safety_checklists(*),ride_group_members(group_id)",
      )
      .eq("ride_id", id)
      .order("created_at"),
    db.from("ride_groups").select("*").eq("ride_id", id).order("group_number"),
    db.from("checkpoints").select("*").eq("ride_id", id).order("sequence"),
    db
      .from("incidents")
      .select("*")
      .eq("ride_id", id)
      .order("created_at", { ascending: false }),
    db.from("announcements").select("*").eq("ride_id", id),
    db.from("profiles").select("id,full_name"),
  ]);
  if (results.some((r) => r.error)) throw new Error("Operations unavailable");
  const [
    ride,
    registrations,
    groups,
    checkpoints,
    incidents,
    announcements,
    people,
  ] = results;
  const r = ride.data;
  const regs = registrations.data ?? [];
  const groupOptions = (groups.data ?? []).map((g) => ({
    value: g.id,
    label: g.name,
  }));
  const leaders = [
    { value: "", label: "Assign later" },
    ...(people.data ?? []).map((p) => ({ value: p.id, label: p.full_name })),
  ];
  return (
    <>
      <PageHeading
        eyebrow="RIDE OPERATIONS"
        title={r.title}
        description={`${r.ride_date} · ${r.meeting_point}`}
      >
        <Badge tone="green">{r.status.replaceAll("_", " ")}</Badge>
      </PageHeading>
      <div className="grid-3">
        {[
          ["Registered", regs.length],
          [
            "Approved",
            regs.filter((x) =>
              ["approved", "checked_in", "completed"].includes(x.status),
            ).length,
          ],
          [
            "Checked in",
            regs.filter((x) => ["checked_in", "completed"].includes(x.status))
              .length,
          ],
          [
            "Not checked in",
            regs.filter((x) => x.status === "approved").length,
          ],
          ["Waitlisted", regs.filter((x) => x.status === "waitlisted").length],
          [
            "Open incidents",
            (incidents.data ?? []).filter((x) => x.status !== "resolved")
              .length,
          ],
        ].map(([label, value]) => (
          <div className="panel" key={label}>
            <Stat label={String(label)} value={value} />
          </div>
        ))}
      </div>
      <div className="grid-2">
        <div className="panel">
          <h3>Ride status</h3>
          <ActionForm
            action="status"
            hidden={{ ride_id: id }}
            fields={[
              {
                name: "status",
                label: "Move to",
                options: opts([
                  "registration_open",
                  "registration_closed",
                  "upcoming",
                  "active",
                  "completed",
                  "cancelled",
                ]),
              },
            ]}
            submit="Update ride status"
          />
          <p style={{ marginTop: 15 }}>
            Completing a ride records attendance history. Cancelling revokes all
            passes.
          </p>
        </div>
        <div className="panel">
          <h3>Assembly check-in</h3>
          <p>
            Verify the pass against this ride. Check-in is available on the ride
            date in IST.
          </p>
          <Link className="button" href={`/admin/check-in?ride=${id}`}>
            Open QR check-in →
          </Link>
        </div>
      </div>
      <h2 style={{ fontSize: "2rem" }}>Applications & safety</h2>
      {!regs.length && (
        <EmptyState title="No applications yet">
          Share the published ride with club members.
        </EmptyState>
      )}
      {regs.map((reg) => {
        const safety = Array.isArray(reg.safety_checklists)
          ? reg.safety_checklists[0]
          : reg.safety_checklists;
        return (
          <details className="panel" key={reg.id}>
            <summary>
              {reg.profiles.full_name} · {reg.status} · Safety:{" "}
              {safety?.status?.replaceAll("_", " ")}
            </summary>
            <div className="grid-3" style={{ marginTop: 25 }}>
              <div>
                <p>{reg.profiles.email}</p>
                <details>
                  <summary>Ride contact details</summary>
                  <p>
                    {reg.profiles.phone || "No phone"}
                    <br />
                    Emergency:{" "}
                    {reg.profiles.emergency_contact || "Not provided"} (
                    {reg.profiles.emergency_relationship || "—"})
                  </p>
                </details>
                <ActionForm
                  action="decision"
                  hidden={{ registration_id: reg.id }}
                  fields={[
                    {
                      name: "decision",
                      label: "Application decision",
                      options: opts(["approved", "waitlisted", "rejected"]),
                    },
                  ]}
                  submit="Save decision"
                />
              </div>
              <div>
                <p>
                  Checks completed:{" "}
                  {Object.values(safety?.checks ?? {}).filter(Boolean).length}/9
                </p>
                <ActionForm
                  action="verify"
                  hidden={{ registration_id: reg.id }}
                  fields={[
                    {
                      name: "passed",
                      label: "Verification outcome",
                      options: [
                        { value: "true", label: "Verified in person" },
                        { value: "false", label: "Action required" },
                      ],
                    },
                    { name: "notes", label: "Safety notes", type: "textarea" },
                  ]}
                  submit="Verify safety"
                />
              </div>
              <div>
                {groupOptions.length > 0 && (
                  <ActionForm
                    action="assign"
                    hidden={{ registration_id: reg.id }}
                    fields={[
                      {
                        name: "group_id",
                        label: "Assign riding group",
                        options: groupOptions,
                        value: reg.ride_group_members?.[0]?.group_id,
                      },
                    ]}
                    submit="Assign group"
                  />
                )}
              </div>
            </div>
          </details>
        );
      })}
      <div className="grid-2">
        <section>
          <h2 style={{ fontSize: "2rem" }}>Riding groups</h2>
          {groups.data?.map((g) => (
            <div className="panel" key={g.id}>
              <h3>
                {g.group_number}. {g.name}
              </h3>
              <p>
                Maximum {g.capacity} riders · Captain:{" "}
                {people.data?.find((p) => p.id === g.captain_id)?.full_name ??
                  "Unassigned"}{" "}
                · Sweep:{" "}
                {people.data?.find((p) => p.id === g.sweep_id)?.full_name ??
                  "Unassigned"}
              </p>
              <ul>
                {regs
                  .filter((rr) =>
                    rr.ride_group_members?.some(
                      (m: { group_id: string }) => m.group_id === g.id,
                    ),
                  )
                  .map((rr) => (
                    <li key={rr.id}>{rr.profiles.full_name}</li>
                  ))}
              </ul>
            </div>
          ))}
          <details className="panel">
            <summary>Create group</summary>
            <ActionForm
              action="group"
              hidden={{ ride_id: id }}
              fields={[
                { name: "name", label: "Group name", required: true },
                {
                  name: "group_number",
                  label: "Number",
                  type: "number",
                  min: 1,
                  required: true,
                },
                {
                  name: "capacity",
                  label: "Maximum group size",
                  type: "number",
                  min: 1,
                  max: 30,
                  value: 8,
                },
                { name: "captain_id", label: "Captain", options: leaders },
                { name: "sweep_id", label: "Sweep", options: leaders },
              ]}
              submit="Create group"
            />
          </details>
        </section>
        <section>
          <h2 style={{ fontSize: "2rem" }}>Checkpoints</h2>
          {checkpoints.data?.map((c) => (
            <div className="panel" key={c.id}>
              <h3>
                {c.sequence}. {c.name}
              </h3>
              <p>
                {c.location} · {c.expected_arrival || "Arrival TBD"}
              </p>
              <ActionForm
                action="checkpoint_status"
                hidden={{ checkpoint_id: c.id }}
                fields={[
                  {
                    name: "status",
                    label: "Checkpoint status",
                    options: opts(["pending", "reached", "skipped"]),
                    value: c.status,
                  },
                ]}
              />
            </div>
          ))}
          <details className="panel">
            <summary>Add checkpoint</summary>
            <ActionForm
              action="checkpoint"
              hidden={{ ride_id: id }}
              fields={[
                { name: "name", label: "Name", required: true },
                { name: "location", label: "Location", required: true },
                {
                  name: "sequence",
                  label: "Sequence",
                  type: "number",
                  min: 1,
                  required: true,
                },
                {
                  name: "expected_arrival",
                  label: "Expected arrival (ISO timestamp with timezone)",
                },
                {
                  name: "latitude",
                  label: "Latitude",
                  type: "number",
                  min: -90,
                  max: 90,
                },
                {
                  name: "longitude",
                  label: "Longitude",
                  type: "number",
                  min: -180,
                  max: 180,
                },
              ]}
              submit="Add checkpoint"
            />
          </details>
        </section>
      </div>
      <h2 style={{ fontSize: "2rem" }}>Announcements</h2>
      {announcements.data?.map((a) => (
        <div className="panel" key={a.id}>
          <Badge>{a.priority}</Badge>
          <h3 style={{ marginTop: 15 }}>{a.title}</h3>
          <p>{a.message}</p>
        </div>
      ))}
      <details className="panel">
        <summary>Post a ride or group announcement</summary>
        <ActionForm
          action="announcement"
          hidden={{ ride_id: id }}
          fields={[
            { name: "title", label: "Title", required: true },
            {
              name: "message",
              label: "Message",
              type: "textarea",
              required: true,
            },
            {
              name: "audience",
              label: "Audience",
              options: opts(["ride", "group"]),
            },
            {
              name: "group_id",
              label: "Group (for group audience)",
              options: [{ value: "", label: "Whole ride" }, ...groupOptions],
            },
            {
              name: "priority",
              label: "Priority",
              options: opts(["normal", "important", "urgent"]),
            },
            {
              name: "expires_at",
              label: "Expires (ISO timestamp with timezone)",
            },
          ]}
          submit="Post announcement"
        />
      </details>
      <h2 style={{ fontSize: "2rem" }}>Incident log</h2>
      <p>
        This platform is not an emergency-response service. Contact official
        emergency services for serious emergencies.
      </p>
      {!incidents.data?.length && (
        <EmptyState title="No incidents reported">
          Keep checking in with your captains throughout the ride.
        </EmptyState>
      )}
      {incidents.data?.map((i) => (
        <div className="panel" key={i.id}>
          <Badge tone="orange">{i.type}</Badge>
          <p style={{ marginTop: 15 }}>{i.description}</p>
          <p>
            {i.location} ·{" "}
            {new Date(i.created_at).toLocaleString("en-IN", {
              timeZone: "Asia/Kolkata",
            })}
          </p>
          <ActionForm
            action="resolve"
            hidden={{ incident_id: i.id }}
            fields={[
              {
                name: "status",
                label: "Status",
                options: opts(["open", "acknowledged", "resolved"]),
                value: i.status,
              },
              {
                name: "notes",
                label: "Organizer notes",
                type: "textarea",
                value: i.organizer_notes ?? "",
              },
            ]}
            submit="Update incident"
          />
        </div>
      ))}
    </>
  );
}
