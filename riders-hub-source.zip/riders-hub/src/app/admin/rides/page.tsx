import Link from "next/link";
import { requireStaff } from "@/lib/auth/access";
import { Badge, PageHeading, EmptyState } from "@/components/ui";
import { AdminRideForm } from "@/components/admin-ride-form";
export default async function AdminRides() {
  const { db, roles } = await requireStaff();
  const [{ data: rides, error }, { data: people, error: pe }] =
    await Promise.all([
      db.from("rides").select("*").order("ride_date", { ascending: false }),
      db.from("profiles").select("id,full_name"),
    ]);
  if (error || pe) throw new Error("Rides unavailable");
  return (
    <>
      <PageHeading eyebrow="PLAN / PREPARE / RIDE" title="Ride management." />
      <div className="grid-2">
        {rides?.map((r) => (
          <Link href={`/admin/rides/${r.id}`} className="panel" key={r.id}>
            <Badge>{r.status.replaceAll("_", " ")}</Badge>
            <h3 style={{ marginTop: 15 }}>{r.title}</h3>
            <p>
              {r.ride_date} · {r.capacity} places
            </p>
            Open operations →
          </Link>
        ))}
      </div>
      {!rides?.length && (
        <EmptyState title="No rides yet">
          Create a draft to start planning your first club ride.
        </EmptyState>
      )}
      {roles.some((r) => ["organizer", "admin", "super_admin"].includes(r)) && (
        <details className="panel">
          <summary>Create a new ride</summary>
          <div style={{ maxWidth: 700, marginTop: 25 }}>
            <AdminRideForm people={people ?? []} />
          </div>
        </details>
      )}
    </>
  );
}
