import { requireStaff } from "@/lib/auth/access";
import { PageHeading, Badge } from "@/components/ui";
import { ActionForm } from "@/components/ui/action-form";
const opts = (values: string[]) =>
  values.map((value) => ({ value, label: value }));
export default async function Members() {
  const { db, roles } = await requireStaff(true);
  const { data, error } = await db
    .from("profiles")
    .select("id,full_name,email,club_memberships(*),user_roles(role)")
    .order("full_name");
  if (error) throw new Error("Members unavailable");
  return (
    <>
      <PageHeading
        eyebrow="THE COMMUNITY"
        title="Member management."
        description="Approve memberships separately from privileged roles. Only super admins can change role assignments."
      />
      {data.map((p) => {
        const m = Array.isArray(p.club_memberships)
          ? p.club_memberships[0]
          : p.club_memberships;
        return (
          <details className="panel" key={p.id}>
            <summary>
              {p.full_name} · {m?.status} · {p.email}
            </summary>
            <p style={{ marginTop: 20 }}>
              {p.user_roles.map((r: { role: string }) => (
                <Badge key={r.role}>{r.role}</Badge>
              ))}
            </p>
            <div className="grid-2">
              <ActionForm
                action="membership"
                hidden={{ user_id: p.id }}
                fields={[
                  {
                    name: "status",
                    label: "Membership status",
                    options: opts(["pending", "active", "suspended", "alumni"]),
                    value: m?.status,
                  },
                ]}
                submit="Update membership"
              />
              {roles.includes("super_admin") && (
                <ActionForm
                  action="role"
                  hidden={{ user_id: p.id }}
                  fields={[
                    {
                      name: "role",
                      label: "Role",
                      options: opts([
                        "member",
                        "captain",
                        "organizer",
                        "admin",
                        "super_admin",
                      ]),
                    },
                    {
                      name: "enabled",
                      label: "Action",
                      options: [
                        { value: "true", label: "Grant role" },
                        { value: "false", label: "Remove role" },
                      ],
                    },
                  ]}
                  submit="Update role"
                />
              )}
            </div>
          </details>
        );
      })}
    </>
  );
}
