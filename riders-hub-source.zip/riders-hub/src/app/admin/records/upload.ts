"use server";
import { revalidatePath } from "next/cache";
import { requireStaff } from "@/lib/auth/access";
import { idSchema } from "@/lib/validators";
import type { Result } from "@/app/dashboard/actions";
export async function uploadGallery(
  _: Result,
  form: FormData,
): Promise<Result> {
  const { db } = await requireStaff(true);
  const file = form.get("image");
  const album = idSchema.safeParse(form.get("album_id"));
  const caption = String(form.get("caption") ?? "").trim();
  if (
    !album.success ||
    !(file instanceof File) ||
    !caption ||
    caption.length > 300
  )
    return { error: true, message: "Choose an album, image and caption." };
  if (
    file.size > 8 * 1024 * 1024 ||
    !["image/jpeg", "image/png", "image/webp"].includes(file.type)
  )
    return {
      error: true,
      message: "Use a JPEG, PNG or WebP image under 8 MB.",
    };
  const bytes = new Uint8Array(await file.arrayBuffer());
  const valid =
    file.type === "image/jpeg"
      ? bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255
      : file.type === "image/png"
        ? bytes.slice(0, 8).join(",") === "137,80,78,71,13,10,26,10"
        : new TextDecoder().decode(bytes.slice(0, 4)) === "RIFF" &&
          new TextDecoder().decode(bytes.slice(8, 12)) === "WEBP";
  if (!valid)
    return {
      error: true,
      message: "The image contents do not match its format.",
    };
  const path = `${album.data}/${crypto.randomUUID()}.${file.type === "image/jpeg" ? "jpg" : file.type.split("/")[1]}`;
  const { error } = await db.storage
    .from("gallery")
    .upload(path, file, { contentType: file.type, upsert: false });
  if (error)
    return {
      error: true,
      message: "Upload failed. Check the storage bucket configuration.",
    };
  const { error: rowError } = await db
    .from("gallery_images")
    .insert({
      album_id: album.data,
      storage_path: path,
      caption,
      photographer_credit: String(form.get("credit") ?? "").slice(0, 150),
      taken_on: form.get("taken_on") || null,
      approved: false,
    });
  if (rowError) {
    await db.storage.from("gallery").remove([path]);
    return { error: true, message: "The image record could not be saved." };
  }
  revalidatePath("/admin/records");
  return {
    message:
      "Uploaded privately. Approve the image and publish its album when ready.",
  };
}
