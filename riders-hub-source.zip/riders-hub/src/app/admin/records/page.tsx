import { requireStaff } from "@/lib/auth/access";
import { PageHeading, Badge } from "@/components/ui";
import { ActionForm, type Field } from "@/components/ui/action-form";
import { GalleryUpload } from "@/components/gallery-upload";
export default async function Records() {
  const { db } = await requireStaff(true);
  const results = await Promise.all([
    db.from("profiles").select("id,full_name"),
    db.from("rides").select("id,title"),
    db.from("events").select("*"),
    db.from("committee_members").select("*"),
    db.from("partners").select("*"),
    db.from("achievements").select("*"),
    db.from("gallery_albums").select("*"),
    db.from("gallery_images").select("*"),
    db
      .from("audit_logs")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(30),
  ]);
  if (results.some((r) => r.error)) throw new Error("Club records unavailable");
  const [
    people,
    rides,
    events,
    committee,
    partners,
    achievements,
    albums,
    images,
    audit,
  ] = results;
  const members = (people.data ?? []).map((p) => ({
    value: p.id,
    label: p.full_name,
  }));
  const published: Field = {
    name: "published",
    label: "Visibility",
    options: [
      { value: "false", label: "Draft / private" },
      { value: "true", label: "Published" },
    ],
  };
  const sections: {
    title: string;
    table: string;
    fields: Field[];
    rows: Record<string, unknown>[];
  }[] = [
    {
      title: "Events & workshops",
      table: "events",
      rows: events.data ?? [],
      fields: [
        { name: "title", label: "Title", required: true },
        {
          name: "description",
          label: "Description",
          type: "textarea",
          required: true,
        },
        {
          name: "type",
          label: "Type",
          options: [
            "road-safety workshop",
            "maintenance workshop",
            "meetup",
            "training",
            "awareness campaign",
            "volunteer event",
            "partner event",
          ].map((value) => ({ value, label: value })),
        },
        {
          name: "starts_at",
          label: "Start (ISO timestamp with timezone)",
          required: true,
        },
        { name: "location", label: "Location", required: true },
        published,
      ],
    },
    {
      title: "Committee continuity",
      table: "committee_members",
      rows: committee.data ?? [],
      fields: [
        { name: "member_id", label: "Member", options: members },
        { name: "display_name", label: "Public display name", required: true },
        { name: "role", label: "Committee role", required: true },
        {
          name: "academic_year",
          label: "Academic year (2026-27)",
          required: true,
        },
        {
          name: "start_date",
          label: "Start date",
          type: "date",
          required: true,
        },
        { name: "end_date", label: "End date", type: "date" },
        {
          name: "responsibilities",
          label: "Responsibilities",
          type: "textarea",
          required: true,
        },
        {
          name: "status",
          label: "Status",
          options: [
            { value: "active", label: "Active" },
            { value: "past", label: "Past" },
          ],
        },
        published,
      ],
    },
    {
      title: "Partners & sponsors",
      table: "partners",
      rows: partners.data ?? [],
      fields: [
        { name: "name", label: "Name", required: true },
        {
          name: "description",
          label: "Partnership details",
          type: "textarea",
          required: true,
        },
        { name: "website", label: "Website (https://)" },
        published,
      ],
    },
    {
      title: "Achievements",
      table: "achievements",
      rows: achievements.data ?? [],
      fields: [
        { name: "name", label: "Achievement name", required: true },
        {
          name: "description",
          label: "How it is earned (no speed or risky-riding rewards)",
          type: "textarea",
          required: true,
        },
      ],
    },
    {
      title: "Gallery albums",
      table: "gallery_albums",
      rows: albums.data ?? [],
      fields: [
        { name: "title", label: "Album title", required: true },
        {
          name: "ride_id",
          label: "Associated ride",
          options: [
            { value: "", label: "No ride" },
            ...(rides.data ?? []).map((r) => ({ value: r.id, label: r.title })),
          ],
        },
        published,
      ],
    },
  ];
  return (
    <>
      <PageHeading
        eyebrow="BUILT TO OUTLAST A COMMITTEE"
        title="Club records."
        description="Preserve events, partnerships, achievements and annual committee history. Public records expose only the fields shown here."
      />
      {sections.map((s) => (
        <section key={s.table} className="panel">
          <h2 style={{ fontSize: "2rem" }}>{s.title}</h2>
          {s.rows.map((row) => (
            <details
              key={String(row.id)}
              style={{
                padding: "14px 0",
                borderBottom: "1px solid var(--line)",
              }}
            >
              <summary>
                {String(row.title ?? row.name ?? row.display_name)}{" "}
                {typeof row.published === "boolean" && (
                  <Badge>{row.published ? "published" : "draft"}</Badge>
                )}
              </summary>
              <p style={{ marginTop: 15 }}>
                {String(row.description ?? row.responsibilities ?? "")}
              </p>
              {typeof row.published === "boolean" && (
                <ActionForm
                  action="publish_record"
                  hidden={{
                    table: s.table,
                    id: String(row.id),
                    published: String(!row.published),
                  }}
                  submit={row.published ? "Unpublish" : "Publish"}
                />
              )}
            </details>
          ))}
          <details style={{ marginTop: 25 }}>
            <summary>Add record</summary>
            <div style={{ marginTop: 20, maxWidth: 650 }}>
              <ActionForm
                action="record"
                hidden={{ table: s.table }}
                fields={s.fields}
                submit="Create record"
              />
            </div>
          </details>
        </section>
      ))}
      <div className="grid-2">
        <section className="panel">
          <h3>Award a milestone</h3>
          <ActionForm
            action="record"
            hidden={{ table: "user_achievements" }}
            fields={[
              { name: "user_id", label: "Rider", options: members },
              {
                name: "achievement_id",
                label: "Achievement",
                options: (achievements.data ?? []).map((a) => ({
                  value: a.id,
                  label: a.name,
                })),
              },
            ]}
            submit="Award achievement"
          />
        </section>
        <section className="panel">
          <h3>Club announcement</h3>
          <ActionForm
            action="announcement"
            hidden={{ ride_id: "", group_id: "" }}
            fields={[
              { name: "title", label: "Title", required: true },
              {
                name: "message",
                label: "Message",
                type: "textarea",
                required: true,
              },
              {
                name: "audience",
                label: "Audience",
                options: [
                  { value: "all_members", label: "All members" },
                  { value: "committee", label: "Committee" },
                ],
              },
              {
                name: "priority",
                label: "Priority",
                options: ["normal", "important", "urgent"].map((value) => ({
                  value,
                  label: value,
                })),
              },
              { name: "expires_at", label: "Expires (ISO timestamp)" },
            ]}
            submit="Post announcement"
          />
        </section>
      </div>
      <section className="panel">
        <h2 style={{ fontSize: "2rem" }}>Gallery moderation</h2>
        <GalleryUpload albums={albums.data ?? []} />
        {images.data?.map((i) => (
          <div key={i.id} style={{ marginTop: 25 }}>
            <p>
              {i.caption} · {i.photographer_credit}
            </p>
            <ActionForm
              action="publish_record"
              hidden={{
                table: "gallery_images",
                id: i.id,
                published: String(!i.approved),
              }}
              submit={i.approved ? "Withdraw approval" : "Approve image"}
            />
          </div>
        ))}
      </section>
      <section className="panel">
        <h2 style={{ fontSize: "2rem" }}>Recent audit history</h2>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Time</th>
                <th>Action</th>
                <th>Actor ID</th>
              </tr>
            </thead>
            <tbody>
              {audit.data?.map((a) => (
                <tr key={a.id}>
                  <td>{new Date(a.created_at).toLocaleString("en-IN")}</td>
                  <td>{a.action}</td>
                  <td>{a.actor_id}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </>
  );
}
