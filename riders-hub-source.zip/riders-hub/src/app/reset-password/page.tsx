import { AuthForm } from "@/components/auth-form";
export default function Reset() {
  return (
    <div className="auth-box">
      <h1>A fresh start.</h1>
      <AuthForm mode="reset" />
    </div>
  );
}
