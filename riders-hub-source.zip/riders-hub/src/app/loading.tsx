export default function Loading() {
  return (
    <div className="loading-screen" role="status">
      <h2>
        MIT-WPU RIDERS<span className="orange-text"> /</span>
      </h2>
      <div className="loading-route" aria-hidden="true" />
      <p>INITIALIZING RIDE</p>
    </div>
  );
}
