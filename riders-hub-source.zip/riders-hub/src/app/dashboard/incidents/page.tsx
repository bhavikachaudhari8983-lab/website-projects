import { requireUser } from "@/lib/auth/access";
import { ActionForm } from "@/components/ui/action-form";
import { PageHeading, Badge, EmptyState } from "@/components/ui";
export default async function Incidents() {
  const { db, user } = await requireUser();
  const [{ data: rides, error }, { data: reports, error: re }] =
    await Promise.all([
      db
        .from("ride_registrations")
        .select("ride_id,rides(title)")
        .eq("user_id", user.id)
        .in("status", ["approved", "checked_in", "completed"]),
      db
        .from("incidents")
        .select("*")
        .eq("rider_id", user.id)
        .order("created_at", { ascending: false }),
    ]);
  if (error || re) throw new Error("Reports unavailable");
  return (
    <>
      <PageHeading
        eyebrow="LOOK OUT FOR EACH OTHER"
        title="Report an incident."
      />
      <div className="alert" role="note">
        This platform is not an emergency-response service. For a serious
        emergency, contact official emergency services immediately and alert
        your ride captain. Do not wait for a response here.
      </div>
      <div className="grid-2">
        <div className="panel">
          {rides?.length ? (
            <ActionForm
              action="incident"
              submit="Save incident report"
              fields={[
                {
                  name: "ride_id",
                  label: "Ride",
                  options: rides.map((r) => ({
                    value: r.ride_id,
                    label: (r.rides as unknown as { title: string }).title,
                  })),
                },
                {
                  name: "type",
                  label: "Type",
                  options: [
                    "puncture",
                    "mechanical",
                    "fuel",
                    "separated",
                    "minor",
                    "medical",
                    "emergency",
                    "other",
                  ].map((value) => ({ value, label: value })),
                },
                {
                  name: "description",
                  label: "What happened?",
                  type: "textarea",
                  required: true,
                },
                { name: "location", label: "Location (optional)" },
              ]}
            />
          ) : (
            <EmptyState title="No eligible rides">
              Incident reports are available for rides you are approved to join.
            </EmptyState>
          )}
        </div>
        <div>
          {reports?.map((r) => (
            <div className="panel" key={r.id}>
              <Badge>{r.status}</Badge>
              <h3 style={{ marginTop: 15 }}>{r.type}</h3>
              <p>{r.description}</p>
              {r.organizer_notes && <p>Organizer: {r.organizer_notes}</p>}
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
