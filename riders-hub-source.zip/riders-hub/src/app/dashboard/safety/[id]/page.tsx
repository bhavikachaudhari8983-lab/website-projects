import { notFound } from "next/navigation";
import { requireUser } from "@/lib/auth/access";
import { safetyItems } from "@/lib/config";
import { Badge, PageHeading } from "@/components/ui";
import { ActionForm } from "@/components/ui/action-form";
import { idSchema } from "@/lib/validators";
export default async function Safety({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  if (!idSchema.safeParse(id).success) notFound();
  const { db, user } = await requireUser();
  const { data: r, error } = await db
    .from("ride_registrations")
    .select("*,rides(*),safety_checklists(*)")
    .eq("id", id)
    .eq("user_id", user.id)
    .maybeSingle();
  if (error) throw new Error("Checklist unavailable");
  if (!r) notFound();
  const safety = Array.isArray(r.safety_checklists)
    ? r.safety_checklists[0]
    : r.safety_checklists;
  return (
    <>
      <PageHeading eyebrow="PRE-RIDE PREPARATION" title={r.rides.title} />
      <div className="detail-grid">
        <div className="panel">
          <Badge
            tone={safety?.status === "organizer_verified" ? "green" : "orange"}
          >
            {safety?.status?.replaceAll("_", " ") || "not started"}
          </Badge>
          <h2 style={{ fontSize: "2rem", marginTop: 25 }}>
            Nine checks. One safe start.
          </h2>
          <p>
            Confirm these only after inspecting your own gear and bike. An
            organizer will verify them at assembly.
          </p>
          {safety?.notes && (
            <p className="alert">Organizer note: {safety.notes}</p>
          )}
          {["pending", "approved", "waitlisted"].includes(r.status) &&
          safety?.status !== "organizer_verified" ? (
            <ActionForm
              action="safety"
              hidden={{ registration_id: id }}
              submit="Submit my safety checks"
            >
              {safetyItems.map((item) => (
                <label className="check-item" key={item}>
                  <input
                    type="checkbox"
                    name={item}
                    required
                    defaultChecked={safety?.checks?.[item] === true}
                  />
                  {item}
                </label>
              ))}
              <p style={{ marginTop: 20 }}>
                I have checked each item and will attend the ride briefing.
              </p>
            </ActionForm>
          ) : (
            <p>
              {safety?.status === "organizer_verified"
                ? "Your organizer has verified your safety checklist."
                : "Checks are unavailable for this registration status."}
            </p>
          )}
        </div>
        <aside className="panel">
          <p className="eyebrow">DIGITAL RIDE PASS</p>
          <h3>Your place on the road.</h3>
          <p>Registration: {r.status}</p>
          <p>
            Approval, active membership and organizer-verified safety are
            required before issuing a pass.
          </p>
          {r.status === "approved" &&
            safety?.status === "organizer_verified" && (
              <ActionForm
                action="pass"
                hidden={{ registration_id: id }}
                submit="Get my Ride Pass"
              />
            )}
        </aside>
      </div>
    </>
  );
}
