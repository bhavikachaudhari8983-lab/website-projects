import Link from "next/link";
import { requireUser } from "@/lib/auth/access";
import { Badge, PageHeading, EmptyState } from "@/components/ui";
import { ActionForm } from "@/components/ui/action-form";
export default async function MyRides() {
  const { db, user } = await requireUser();
  const { data, error } = await db
    .from("ride_registrations")
    .select("*,rides(*)")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false });
  if (error) throw new Error("Rides unavailable");
  return (
    <>
      <PageHeading eyebrow="YOUR JOURNEY" title="Every ride, remembered." />
      <div className="grid-2">
        {data.map((r) => (
          <article className="panel" key={r.id}>
            <Badge>{r.status}</Badge>
            <h3 style={{ marginTop: 15 }}>{r.rides.title}</h3>
            <p>
              {r.rides.ride_date} · {r.rides.distance_km} km
            </p>
            <Link className="orange-text" href={`/dashboard/safety/${r.id}`}>
              View safety & pass →
            </Link>
            {["pending", "approved", "waitlisted"].includes(r.status) && (
              <details style={{ marginTop: 20 }}>
                <summary>Cancel application</summary>
                <p>
                  This releases your place. Contact the organizer if you need to
                  reapply.
                </p>
                <ActionForm
                  action="cancel"
                  hidden={{ registration_id: r.id }}
                  submit="Confirm cancellation"
                />
              </details>
            )}
          </article>
        ))}
      </div>
      {!data.length && (
        <EmptyState title="No applications yet">
          <Link href="/rides">Find your first club ride →</Link>
        </EmptyState>
      )}
    </>
  );
}
