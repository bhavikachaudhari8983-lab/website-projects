import Link from "next/link";
import { requireUser } from "@/lib/auth/access";
import { ButtonLink, PageHeading, EmptyState, Badge } from "@/components/ui";
import {
  PassportIdentity,
  NextRideCockpit,
} from "@/components/dashboard/passport";
import type { Ride } from "@/types/domain";
export default async function Dashboard() {
  const { db, user, roles } = await requireUser();
  const results = await Promise.all([
    db.from("profiles").select("*").eq("id", user.id).single(),
    db.from("club_memberships").select("*").eq("user_id", user.id).single(),
    db
      .from("ride_registrations")
      .select("*,rides(*)")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false }),
    db
      .from("announcements")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(10),
    db
      .from("user_achievements")
      .select("*,achievements(*)")
      .eq("user_id", user.id),
    db.from("safety_checklists").select("status,registration_id"),
  ]);
  if (results.some((r) => r.error)) throw new Error("Passport could not load");
  const [profile, membership, registrations, announcements, awards, safety] =
    results;
  const completed = (registrations.data ?? []).filter(
    (r) => r.status === "completed",
  );
  const km = completed.reduce(
    (sum, r) => sum + (r.rides as Ride).distance_km,
    0,
  );
  return (
    <>
      <PageHeading
        eyebrow="YOUR RIDER PASSPORT"
        title={`Hey, ${profile.data.full_name.split(" ")[0]}.`}
        description="Your people. Your progress. Your next adventure."
      >
        <ButtonLink href="/rides">Find a ride ↗</ButtonLink>
      </PageHeading>
      <PassportIdentity
        name={profile.data.full_name}
        number={membership.data.membership_number}
        status={membership.data.status}
        completed={completed.length}
        km={km}
        safety={
          (safety.data ?? []).filter((s) => s.status === "organizer_verified")
            .length
        }
      />
      {(() => {
        const next = registrations.data?.find(
          (r) =>
            ["pending", "approved", "waitlisted", "checked_in"].includes(
              r.status,
            ) && !["cancelled", "completed"].includes(r.rides.status),
        );
        return next ? (
          <NextRideCockpit
            ride={next.rides as Ride}
            registrationId={next.id}
            status={next.status}
          />
        ) : null;
      })()}
      <div className="grid-2">
        <section>
          <h2 style={{ fontSize: "2rem" }}>On your horizon</h2>
          {(registrations.data ?? [])
            .filter(
              (r) => !["completed", "cancelled", "rejected"].includes(r.status),
            )
            .map((r) => (
              <div className="panel" key={r.id}>
                <Badge>{r.status}</Badge>
                <h3 style={{ marginTop: 15 }}>{r.rides.title}</h3>
                <p>{r.rides.ride_date}</p>
                <Link
                  className="orange-text"
                  href={`/dashboard/safety/${r.id}`}
                >
                  Review preparation →
                </Link>
              </div>
            ))}
          {!registrations.data?.length && (
            <EmptyState title="Your first chapter awaits">
              Complete your profile and explore the upcoming rides.
            </EmptyState>
          )}
        </section>
        <section>
          <h2 style={{ fontSize: "2rem" }}>Club noticeboard</h2>
          {announcements.data?.map((a) => (
            <div className="panel" key={a.id}>
              <Badge>{a.priority}</Badge>
              <h3 style={{ marginTop: 15 }}>{a.title}</h3>
              <p>{a.message}</p>
            </div>
          ))}
          {!announcements.data?.length && (
            <EmptyState title="All caught up">
              Club and ride announcements will appear here.
            </EmptyState>
          )}
        </section>
      </div>
      <h2 style={{ fontSize: "2rem", marginTop: 30 }}>
        Milestones, earned responsibly.
      </h2>
      <div className="grid-3">
        {awards.data?.map((a) => (
          <div className="panel" key={a.id}>
            <h3>{a.achievements.name}</h3>
            <p>{a.achievements.description}</p>
          </div>
        ))}
      </div>
      {!awards.data?.length && (
        <p>Your badges will appear after they are awarded by the committee.</p>
      )}
      {roles.some((r) =>
        ["captain", "organizer", "admin", "super_admin"].includes(r),
      ) && (
        <ButtonLink href="/admin" secondary>
          Open organizer workspace →
        </ButtonLink>
      )}
      <div className="cockpit-mobile-actions">
        <ButtonLink href="/dashboard/passes">My Ride Pass</ButtonLink>
        <ButtonLink href="/rides" secondary>
          Explore rides
        </ButtonLink>
      </div>
    </>
  );
}
