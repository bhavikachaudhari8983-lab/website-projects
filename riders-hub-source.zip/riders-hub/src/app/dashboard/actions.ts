"use server";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { requireUser } from "@/lib/auth/access";
import {
  bikeSchema,
  idSchema,
  incidentSchema,
  profileSchema,
  rideSchema,
} from "@/lib/validators";
import { safetyItems } from "@/lib/config";
export type Result = { message: string; error?: boolean; href?: string };
const friendly = [
  "Registration is not open",
  "An active membership is required",
  "Add an active bike before applying",
  "You have already applied for this ride",
  "This ride requires more group riding experience",
  "Group is at capacity",
  "Rider must complete self checks first",
  "Complete every safety check",
  "Add an emergency contact to your profile",
  "Invalid or expired pass",
  "This pass belongs to a different ride",
  "Rider is not cleared for check-in today",
  "Membership is not active",
  "Invalid ride status transition",
  "Registration cannot be changed now",
  "Contact your organizer to leave an active ride",
  "Approval, active membership and verified safety are required",
  "Group and approved rider must belong to the same ride",
  "Please wait a minute before trying again",
];
export async function mutate(_: Result, form: FormData): Promise<Result> {
  const { db, user, roles } = await requireUser();
  const data = Object.fromEntries(form);
  const action = String(data.action);
  const admin = roles.some((r) => ["admin", "super_admin"].includes(r));
  const staff = roles.some((r) =>
    ["captain", "organizer", "admin", "super_admin"].includes(r),
  );
  try {
    const check = (error: { message: string } | null) => {
      if (error) throw new Error(error.message);
    };
    const rpc = async (name: string, args: Record<string, unknown>) => {
      const { data, error } = await db.rpc(name, args);
      check(error);
      return data;
    };
    let message = "Saved successfully.";
    let href: string | undefined;
    switch (action) {
      case "profile": {
        const values = profileSchema.parse(data);
        const { error } = await db
          .from("profiles")
          .update(values)
          .eq("id", user.id);
        check(error);
        break;
      }
      case "bike": {
        const values = bikeSchema.parse(data);
        const { error } = await db
          .from("bikes")
          .insert({ ...values, user_id: user.id });
        check(error);
        break;
      }
      case "register": {
        const id = await rpc("register_for_ride", {
          rid: idSchema.parse(data.ride_id),
        });
        message = "Application submitted. Your organizer will review it.";
        href = `/dashboard/safety/${id}`;
        break;
      }
      case "cancel":
        await rpc("cancel_registration", {
          reg: idSchema.parse(data.registration_id),
        });
        message = "Application cancelled.";
        break;
      case "safety":
        await rpc("submit_safety", {
          reg: idSchema.parse(data.registration_id),
          items: Object.fromEntries(
            safetyItems.map((k) => [k, data[k] === "on"]),
          ),
        });
        message =
          "Self checks submitted. An organizer must verify your gear and bike.";
        break;
      case "pass": {
        const id = await rpc("issue_pass", {
          reg: idSchema.parse(data.registration_id),
        });
        message = "Your Ride Pass is ready.";
        href = `/dashboard/passes/${id}`;
        break;
      }
      case "incident": {
        const values = incidentSchema.parse(data);
        const { error } = await db
          .from("incidents")
          .insert({ ...values, rider_id: user.id });
        check(error);
        message =
          "Report saved. Contact your captain directly if you need immediate help.";
        break;
      }
      case "ride": {
        if (
          !roles.some((r) => ["organizer", "admin", "super_admin"].includes(r))
        )
          throw new Error("Not authorized");
        const values = rideSchema.parse(data);
        const { data: ride, error } = await db
          .from("rides")
          .insert({
            ...values,
            created_by: user.id,
            organizer_id: user.id,
            status: "draft",
          })
          .select("id")
          .single();
        check(error);
        message = "Draft ride created. Review it before opening registration.";
        href = `/admin/rides/${ride!.id}`;
        break;
      }
      case "decision":
        if (!staff) throw new Error("Not authorized");
        message = `Registration ${await rpc("decide_registration", { reg: idSchema.parse(data.registration_id), decision: z.enum(["approved", "rejected", "waitlisted"]).parse(data.decision) })}.`;
        break;
      case "verify":
        if (!staff) throw new Error("Not authorized");
        await rpc("verify_safety", {
          reg: idSchema.parse(data.registration_id),
          passed: data.passed === "true",
          note: z
            .string()
            .max(1000)
            .parse(data.notes || ""),
        });
        message = "Safety verification saved.";
        break;
      case "status":
        if (!staff) throw new Error("Not authorized");
        await rpc("set_ride_status", {
          rid: idSchema.parse(data.ride_id),
          next_status: z
            .enum([
              "registration_open",
              "registration_closed",
              "upcoming",
              "active",
              "completed",
              "cancelled",
            ])
            .parse(data.status),
        });
        break;
      case "checkin": {
        if (!staff) throw new Error("Not authorized");
        const raw = String(data.token)
          .trim()
          .replace(/^riders-pass:/, "");
        message = await rpc("check_in_pass", {
          rid: idSchema.parse(data.ride_id),
          pass_token: idSchema.parse(raw),
        });
        break;
      }
      case "group": {
        if (!staff) throw new Error("Not authorized");
        const values = z
          .object({
            ride_id: idSchema,
            name: z.string().trim().min(2).max(80),
            group_number: z.coerce.number().int().min(1),
            capacity: z.coerce.number().int().min(1).max(30),
            captain_id: z
              .union([idSchema, z.literal("")])
              .transform((v) => v || null),
            sweep_id: z
              .union([idSchema, z.literal("")])
              .transform((v) => v || null),
          })
          .parse(data);
        const { error } = await db.from("ride_groups").insert(values);
        check(error);
        break;
      }
      case "assign":
        if (!staff) throw new Error("Not authorized");
        await rpc("assign_group", {
          reg: idSchema.parse(data.registration_id),
          gid: idSchema.parse(data.group_id),
        });
        break;
      case "checkpoint": {
        if (!staff) throw new Error("Not authorized");
        const values = z
          .object({
            ride_id: idSchema,
            name: z.string().min(2).max(100),
            location: z.string().min(2).max(300),
            sequence: z.coerce.number().int().min(1),
            expected_arrival: z.string().transform((v) => v || null),
            latitude: z.preprocess(
              (v) => (v === "" ? null : v),
              z.coerce.number().min(-90).max(90).nullable(),
            ),
            longitude: z.preprocess(
              (v) => (v === "" ? null : v),
              z.coerce.number().min(-180).max(180).nullable(),
            ),
          })
          .parse(data);
        const { error } = await db.from("checkpoints").insert(values);
        check(error);
        break;
      }
      case "checkpoint_status": {
        if (!staff) throw new Error("Not authorized");
        const { error } = await db
          .from("checkpoints")
          .update({
            status: z
              .enum(["pending", "reached", "skipped"])
              .parse(data.status),
          })
          .eq("id", idSchema.parse(data.checkpoint_id));
        check(error);
        break;
      }
      case "announcement": {
        if (!staff) throw new Error("Not authorized");
        const values = z
          .object({
            title: z.string().min(3).max(120),
            message: z.string().min(3).max(3000),
            audience: z.enum(["all_members", "ride", "group", "committee"]),
            priority: z.enum(["normal", "important", "urgent"]),
            ride_id: z
              .union([idSchema, z.literal("")])
              .transform((v) => v || null),
            group_id: z
              .union([idSchema, z.literal("")])
              .transform((v) => v || null),
            expires_at: z.string().transform((v) => v || null),
          })
          .parse(data);
        const { error } = await db
          .from("announcements")
          .insert({ ...values, created_by: user.id });
        check(error);
        break;
      }
      case "resolve":
        if (!staff) throw new Error("Not authorized");
        await rpc("resolve_incident", {
          iid: idSchema.parse(data.incident_id),
          new_status: z
            .enum(["open", "acknowledged", "resolved"])
            .parse(data.status),
          note: z.string().max(2000).parse(data.notes),
        });
        break;
      case "membership": {
        if (!admin) throw new Error("Not authorized");
        const { error } = await db
          .from("club_memberships")
          .update({
            status: z
              .enum(["pending", "active", "suspended", "alumni"])
              .parse(data.status),
          })
          .eq("user_id", idSchema.parse(data.user_id));
        check(error);
        break;
      }
      case "role": {
        if (!roles.includes("super_admin")) throw new Error("Not authorized");
        await rpc("set_member_role", {
          uid: idSchema.parse(data.user_id),
          new_role: z
            .enum(["member", "captain", "organizer", "admin", "super_admin"])
            .parse(data.role),
          enabled: data.enabled === "true",
        });
        break;
      }
      case "record": {
        if (!admin) throw new Error("Not authorized");
        const table = z
          .enum([
            "events",
            "committee_members",
            "partners",
            "achievements",
            "gallery_albums",
            "user_achievements",
          ])
          .parse(data.table);
        const schemas = {
          events: z.object({
            title: z.string().min(3).max(120),
            description: z.string().min(3).max(4000),
            type: z.string().min(2).max(100),
            starts_at: z.string().min(10),
            location: z.string().min(2).max(300),
            published: z.string().transform((v) => v === "true"),
          }),
          committee_members: z.object({
            member_id: idSchema,
            display_name: z.string().min(2).max(100),
            role: z.string().min(2).max(100),
            academic_year: z.string().regex(/^\d{4}-\d{2,4}$/),
            start_date: z.iso.date(),
            end_date: z.string().transform((v) => v || null),
            responsibilities: z.string().min(3).max(3000),
            status: z.enum(["active", "past"]),
            published: z.string().transform((v) => v === "true"),
          }),
          partners: z.object({
            name: z.string().min(2).max(100),
            description: z.string().min(3).max(2000),
            website: z
              .union([
                z.url().refine((v) => v.startsWith("https://")),
                z.literal(""),
              ])
              .transform((v) => v || null),
            published: z.string().transform((v) => v === "true"),
          }),
          achievements: z.object({
            name: z.string().min(2).max(100),
            description: z.string().min(3).max(1000),
          }),
          gallery_albums: z.object({
            title: z.string().min(2).max(100),
            ride_id: z
              .union([idSchema, z.literal("")])
              .transform((v) => v || null),
            published: z.string().transform((v) => v === "true"),
          }),
          user_achievements: z.object({
            user_id: idSchema,
            achievement_id: idSchema,
          }),
        };
        const values = schemas[table].parse(data);
        const { error } = await db
          .from(table)
          .insert({
            ...values,
            ...(table === "user_achievements" ? { awarded_by: user.id } : {}),
          });
        check(error);
        break;
      }
      case "publish_record": {
        if (!admin) throw new Error("Not authorized");
        const table = z
          .enum([
            "events",
            "committee_members",
            "partners",
            "gallery_albums",
            "gallery_images",
          ])
          .parse(data.table);
        const { error } = await db
          .from(table)
          .update({
            [table === "gallery_images" ? "approved" : "published"]:
              data.published === "true",
          })
          .eq("id", idSchema.parse(data.id));
        check(error);
        break;
      }
      default:
        throw new Error("Invalid action");
    }
    revalidatePath("/dashboard", "layout");
    revalidatePath("/admin", "layout");
    revalidatePath("/rides");
    revalidatePath("/");
    return { message, href };
  } catch (error) {
    if (error instanceof z.ZodError)
      return {
        error: true,
        message: error.issues[0]?.message || "Check the form fields.",
      };
    const message = error instanceof Error ? error.message : "";
    return {
      error: true,
      message:
        friendly.find((v) => message.includes(v)) ||
        "This change could not be saved. Check your permissions and the entered values, then try again.",
    };
  }
}
