import { requireUser } from "@/lib/auth/access";
import { PageHeading, EmptyState, Badge } from "@/components/ui";
import { ActionForm } from "@/components/ui/action-form";
const opts = (v: string[]) => v.map((value) => ({ value, label: value }));
export default async function Profile() {
  const { db, user } = await requireUser();
  const [{ data: p, error }, { data: bikes, error: be }] = await Promise.all([
    db.from("profiles").select("*").eq("id", user.id).single(),
    db.from("bikes").select("*").eq("user_id", user.id),
  ]);
  if (error || be) throw new Error("Profile unavailable");
  return (
    <>
      <PageHeading
        eyebrow="YOUR DETAILS"
        title="Ready for the road."
        description="Your contact, student and bike registration details are private. Authorized ride staff can access them when needed for your rides."
      />
      <div className="grid-2">
        <section className="panel">
          <h2 style={{ fontSize: "2rem" }}>Rider profile</h2>
          <p>{p.email}</p>
          <ActionForm
            action="profile"
            submit="Save profile"
            fields={[
              {
                name: "full_name",
                label: "Full name",
                required: true,
                value: p.full_name,
              },
              {
                name: "student_id",
                label: "Student ID",
                value: p.student_id ?? "",
              },
              {
                name: "phone",
                label: "Phone",
                type: "tel",
                value: p.phone ?? "",
              },
              {
                name: "program",
                label: "Course / program",
                value: p.program ?? "",
              },
              {
                name: "academic_year",
                label: "Academic year",
                type: "number",
                min: 1,
                max: 8,
                value: p.academic_year ?? 1,
              },
              {
                name: "experience",
                label: "Experience",
                options: opts(["beginner", "intermediate", "experienced"]),
                value: p.experience,
              },
              {
                name: "preferred_pace",
                label: "Preferred pace",
                options: opts(["relaxed", "steady"]),
                value: p.preferred_pace,
              },
              {
                name: "emergency_contact",
                label: "Emergency contact number",
                type: "tel",
                value: p.emergency_contact ?? "",
              },
              {
                name: "emergency_relationship",
                label: "Emergency contact relationship",
                value: p.emergency_relationship ?? "",
              },
              {
                name: "blood_group",
                label: "Blood group (optional)",
                options: opts([
                  "",
                  "A+",
                  "A-",
                  "B+",
                  "B-",
                  "AB+",
                  "AB-",
                  "O+",
                  "O-",
                ]),
                value: p.blood_group ?? "",
              },
            ]}
          />
        </section>
        <section>
          <h2 style={{ fontSize: "2rem" }}>Your garage</h2>
          {bikes?.map((b) => (
            <div className="panel" key={b.id}>
              <Badge>{b.status}</Badge>
              <h3 style={{ marginTop: 15 }}>
                {b.manufacturer} {b.model}
              </h3>
              <p>
                {b.engine_cc} cc · {b.category}
                <br />
                {b.registration_identifier}
              </p>
            </div>
          ))}
          {!bikes?.length && (
            <EmptyState title="Add your motorcycle">
              An active bike is required to apply for rides.
            </EmptyState>
          )}
          <div className="panel" style={{ marginTop: 24 }}>
            <h3>Add a bike</h3>
            <ActionForm
              action="bike"
              submit="Add bike"
              fields={[
                { name: "manufacturer", label: "Manufacturer", required: true },
                { name: "model", label: "Model", required: true },
                {
                  name: "registration_identifier",
                  label: "Registration identifier (private)",
                  required: true,
                },
                {
                  name: "engine_cc",
                  label: "Engine capacity (cc)",
                  type: "number",
                  min: 1,
                  max: 3000,
                  required: true,
                },
                {
                  name: "year",
                  label: "Model year",
                  type: "number",
                  min: 1950,
                  max: 2100,
                  required: true,
                },
                {
                  name: "category",
                  label: "Category",
                  options: opts([
                    "street",
                    "touring",
                    "adventure",
                    "cruiser",
                    "sport",
                    "scooter",
                  ]),
                },
                {
                  name: "status",
                  label: "Status",
                  options: opts(["active", "inactive"]),
                },
              ]}
            />
          </div>
        </section>
      </div>
    </>
  );
}
