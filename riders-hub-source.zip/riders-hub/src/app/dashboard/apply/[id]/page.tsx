import { notFound } from "next/navigation";
import { getRide } from "@/lib/data";
import { requireUser } from "@/lib/auth/access";
import { PageHeading, ButtonLink } from "@/components/ui";
import { ActionForm } from "@/components/ui/action-form";
import { idSchema } from "@/lib/validators";
export default async function Apply({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  if (!idSchema.safeParse(id).success) notFound();
  const r = await getRide(id);
  if (!r) notFound();
  const { db, user } = await requireUser();
  const { data, error } = await db
    .from("ride_registrations")
    .select("id,status")
    .eq("ride_id", id)
    .eq("user_id", user.id)
    .maybeSingle();
  if (error) throw new Error("Application could not load");
  return (
    <>
      <PageHeading eyebrow="RIDE APPLICATION" title={r.title} />
      <div className="panel content-body">
        <p>{r.description}</p>
        <p>{r.required_gear}</p>
        <p>
          Applications are reviewed by the ride team. Approved places are
          limited to {r.capacity}; additional approvals enter the waitlist. Your
          pass becomes available after organizer safety verification.
        </p>
        {data ? (
          <>
            <p>Your application: {data.status}</p>
            <ButtonLink href={`/dashboard/safety/${data.id}`}>
              View preparation
            </ButtonLink>
          </>
        ) : (
          <ActionForm
            action="register"
            hidden={{ ride_id: id }}
            submit="Submit ride application"
          />
        )}
      </div>
    </>
  );
}
