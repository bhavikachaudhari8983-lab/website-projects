import Link from "next/link";
import { requireUser } from "@/lib/auth/access";
import { PageHeading, EmptyState, Badge } from "@/components/ui";
export default async function Passes() {
  const { db, user } = await requireUser();
  const { data, error } = await db
    .from("ride_passes")
    .select("*,ride_registrations!inner(user_id,rides(title,ride_date))")
    .eq("ride_registrations.user_id", user.id);
  if (error) throw new Error("Passes unavailable");
  return (
    <>
      <PageHeading
        eyebrow="READY AT ASSEMBLY"
        title="Your digital Ride Passes."
      />
      <div className="grid-2">
        {data.map((p) => (
          <Link className="panel" key={p.id} href={`/dashboard/passes/${p.id}`}>
            <Badge tone={p.revoked_at ? "orange" : "green"}>
              {p.revoked_at ? "inactive" : "issued"}
            </Badge>
            <h3 style={{ marginTop: 15 }}>
              {p.ride_registrations.rides.title}
            </h3>
            <p>{p.ride_registrations.rides.ride_date}</p>Open pass →
          </Link>
        ))}
      </div>
      {!data.length && (
        <EmptyState title="Your pass is waiting on preparation">
          Once your registration and safety checks are approved, generate a pass
          from your ride checklist.
        </EmptyState>
      )}
    </>
  );
}
