import { notFound } from "next/navigation";
import QRCode from "qrcode";
import { requireUser } from "@/lib/auth/access";
import { idSchema } from "@/lib/validators";
import { DigitalPass } from "@/components/dashboard/digital-pass";
async function serverTime() {
  return Date.now();
}
export default async function Pass({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  if (!idSchema.safeParse(id).success) notFound();
  const { db, user } = await requireUser();
  const { data: p, error } = await db
    .from("ride_passes")
    .select("*,ride_registrations!inner(*,rides(*))")
    .eq("id", id)
    .eq("ride_registrations.user_id", user.id)
    .maybeSingle();
  if (error) throw new Error("Pass unavailable");
  if (!p) notFound();
  const rr = p.ride_registrations;
  const results = await Promise.all([
    db.from("profiles").select("full_name").eq("id", user.id).single(),
    db
      .from("club_memberships")
      .select("membership_number")
      .eq("user_id", user.id)
      .single(),
    db
      .from("ride_group_members")
      .select("ride_groups(name,captain_id)")
      .eq("registration_id", rr.id)
      .maybeSingle(),
    db
      .from("safety_checklists")
      .select("status")
      .eq("registration_id", rr.id)
      .single(),
    db.rpc("ride_leader_names", { rid: rr.ride_id }),
  ]);
  if (results.some((r) => r.error)) throw new Error("Pass details unavailable");
  const [profile, membership, group, safety, leaders] = results;
  const assignedGroup = group.data?.ride_groups as unknown as {
    name: string;
  } | null;
  const qr = await QRCode.toDataURL(`riders-pass:${p.token}`, {
    width: 240,
    margin: 2,
    errorCorrectionLevel: "M",
  });
  const inactive =
    Boolean(p.revoked_at) || Date.parse(p.expires_at) < (await serverTime());
  return (
    <div className="pass-layout">
      <div className="pass-intro">
        <p className="eyebrow">YOUR PLACE ON THE ROAD</p>
        <h1>
          GEARED UP.
          <br />
          CHECKED IN.
          <br />
          <span className="orange-text">LET’S RIDE.</span>
        </h1>
        <p>
          Your digital credential brings your ride, group and safety status
          together. Show the QR code to your organizer at assembly.
        </p>
        <p>
          The QR code is your private admission credential. If you share a
          screenshot, cover the QR code and pass ID first.
        </p>
      </div>
      <DigitalPass
        pass={{
          id: p.id,
          riderName: profile.data!.full_name,
          riderNumber: membership.data!.membership_number,
          rideTitle: rr.rides.destination,
          rideNumber: rr.ride_id.slice(0, 8).toUpperCase(),
          date: rr.rides.ride_date,
          group: assignedGroup?.name ?? "Awaiting assignment",
          captain: leaders.data?.captain ?? "Awaiting assignment",
          route: rr.rides.route_info,
          safety: safety.data!.status.replaceAll("_", " "),
          checkIn:
            rr.status === "checked_in"
              ? "Checked in"
              : rr.status === "completed"
                ? "Completed"
                : "Not checked in",
          inactive,
          qr,
        }}
      />
    </div>
  );
}
