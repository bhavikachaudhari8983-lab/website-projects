import { requireUser } from "@/lib/auth/access";
import { WorkspaceNav } from "@/components/dashboard/workspace-nav";
export const dynamic = "force-dynamic";
export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  await requireUser();
  return (
    <div className="container">
      <WorkspaceNav />
      {children}
    </div>
  );
}
