"use client";
export default function ErrorPage({ reset }: { reset: () => void }) {
  return (
    <div className="container">
      <h1>A brief pit stop.</h1>
      <p>We could not load this page. Please try again.</p>
      <button className="primary" onClick={reset}>
        Try again
      </button>
    </div>
  );
}
