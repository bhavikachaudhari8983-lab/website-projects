import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { Hero } from "@/components/home/hero";
import {
  ClubIdentity,
  ClubStats,
  Experience,
  SafetyStatement,
  Milestones,
  Community,
  JoinCta,
} from "@/components/home/home-sections";
import { FeaturedRide } from "@/components/home/featured-ride";
import { EditorialGallery } from "@/components/gallery/editorial-gallery";
import { Reveal } from "@/components/motion/reveal";
import { inspirationGallery } from "@/lib/media";
import { getRides } from "@/lib/data";
import { isConfigured } from "@/lib/config";
import { createClient } from "@/lib/supabase/server";
export const dynamic = "force-dynamic";
export default async function Home() {
  const sample = !isConfigured();
  const rides = await getRides();
  const next = rides.find((r) =>
    ["registration_open", "upcoming", "registration_closed"].includes(r.status),
  );
  let occupied: number | null = null;
  let stats = {
    members: 327 as number | null,
    rides: 28 as number | null,
    km: 4720 as number | null,
    attendance: 96 as number | null,
  };
  if (!sample) {
    const db = await createClient();
    const { data, error } = await db.rpc("club_statistics");
    if (error) throw new Error("Club statistics unavailable");
    stats = data;
    if (next) {
      const { data, error } = await db.rpc("ride_capacity", { rid: next.id });
      if (error) throw new Error("Ride capacity unavailable");
      occupied = data;
    }
  }
  return (
    <div className="public-home">
      <Hero />
      <ClubIdentity />
      {next && <FeaturedRide ride={next} occupied={occupied} sample={sample} />}
      <ClubStats stats={stats} sample={sample} />
      <Experience />
      <SafetyStatement />
      <Milestones />
      <Community />
      <section className="gallery-section section-shell">
        <Reveal>
          <div className="section-top">
            <div>
              <p className="eyebrow">07 / THE RIDERS JOURNAL</p>
              <h2>
                SOME MOMENTS.
                <br />
                ALL THE FEELING.
              </h2>
            </div>
            <Link href="/gallery" className="text-link">
              Explore the gallery <ArrowUpRight size={17} />
            </Link>
          </div>
        </Reveal>
        <EditorialGallery photos={inspirationGallery} />
        <p className="photo-disclaimer">
          Representative photography, not actual club rides.{" "}
          <Link href="/gallery">Photo credits ↗</Link>
        </p>
      </section>
      <JoinCta />
    </div>
  );
}
