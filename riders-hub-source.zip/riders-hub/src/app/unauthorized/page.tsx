import { ButtonLink } from "@/components/ui";
export default function Unauthorized() {
  return (
    <div className="container">
      <p className="eyebrow">ACCESS RESTRICTED</p>
      <h1>This area is for the ride team.</h1>
      <p>Your account does not have permission to manage club operations.</p>
      <ButtonLink href="/dashboard">Back to your passport</ButtonLink>
    </div>
  );
}
