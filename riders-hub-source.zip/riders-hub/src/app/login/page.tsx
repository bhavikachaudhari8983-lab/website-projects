import { AuthForm } from "@/components/auth-form";
import { isConfigured } from "@/lib/config";
export default async function Login({
  searchParams,
}: {
  searchParams: Promise<Record<string, string>>;
}) {
  const query = await searchParams;
  return (
    <div className="auth-box">
      <p className="eyebrow">YOUR RIDER PASSPORT</p>
      <h1>Welcome back.</h1>
      <p>The next road is better together.</p>
      {!isConfigured() && (
        <p className="sample-note">
          Preview mode. Member access needs a connected Supabase project.
        </p>
      )}
      {query.verify && (
        <p role="status">Verify your email before signing in.</p>
      )}
      {query.reset && (
        <p role="status">Password updated. Sign in with your new password.</p>
      )}
      {query.error && (
        <p role="alert">
          That link could not be verified. Request a fresh email link.
        </p>
      )}
      <AuthForm mode="login" />
    </div>
  );
}
