import { notFound } from "next/navigation";
import Link from "next/link";
import { EditorialGallery } from "@/components/gallery/editorial-gallery";
import { inspirationGallery, media } from "@/lib/media";
import { PageHeading, ButtonLink, EmptyState, Badge } from "@/components/ui";
import { content } from "@/lib/public-content";
import { createClient } from "@/lib/supabase/server";
import { isConfigured } from "@/lib/config";
const titles: Record<string, [string, string, string]> = {
  events: [
    "LEARN / CONNECT / CONTRIBUTE",
    "More than weekend rides.",
    "Workshops, meetups and opportunities to give back.",
  ],
  achievements: [
    "PROGRESS WITH PURPOSE",
    "Milestones that matter.",
    "Recognition for preparation, participation and community service.",
  ],
  committee: [
    "THE PEOPLE WHO MAKE IT HAPPEN",
    "Meet the committee.",
    "Current leadership and the people who carried the club forward.",
  ],
  partners: [
    "BETTER, TOGETHER",
    "Our partners.",
    "Organizations supporting responsible riding and student development.",
  ],
  gallery: [
    "MOMENTS FROM THE ROAD",
    "The shared album.",
    "Published photographs from club rides and events.",
  ],
};
export async function generateMetadata({
  params,
}: {
  params: Promise<{ section: string }>;
}) {
  const { section } = await params;
  return { title: content[section]?.title ?? titles[section]?.[1] ?? "Club" };
}
export default async function PublicSection({
  params,
}: {
  params: Promise<{ section: string }>;
}) {
  const { section } = await params;
  const c = content[section];
  if (c)
    return (
      <div className="container">
        <PageHeading
          eyebrow={c.eyebrow}
          title={c.title}
          description={c.intro}
        />
        <div className="content-body">
          {c.sections.map((s) => (
            <section key={s.title}>
              <h2>{s.title}</h2>
              <p>{s.text}</p>
            </section>
          ))}
          {section === "join" && (
            <div className="actions">
              <ButtonLink href="/signup">
                Create your Rider Passport ↗
              </ButtonLink>
              <ButtonLink href="/safety" secondary>
                Read the safety promise
              </ButtonLink>
            </div>
          )}
          {section === "contact" && (
            <ButtonLink href="/committee">View committee →</ButtonLink>
          )}
        </div>
      </div>
    );
  if (!titles[section]) notFound();
  const [eyebrow, title, description] = titles[section];
  const configured = isConfigured();
  const table = {
    events: "events",
    achievements: "achievements",
    committee: "committee_members",
    partners: "partners",
    gallery: "gallery_albums",
  }[section]!;
  let records: Record<string, unknown>[] = [];
  let photos: { id: string; caption: string; url: string; credit: string }[] =
    [];
  if (configured) {
    const db = await createClient();
    const { data, error } = await db
      .from(table)
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw new Error("Club content unavailable");
    records = data;
    if (section === "gallery") {
      const { data: images, error: ie } = await db
        .from("gallery_images")
        .select("*")
        .eq("approved", true);
      if (ie) throw new Error("Gallery unavailable");
      photos = await Promise.all(
        (images ?? []).map(async (i) => {
          const { data, error } = await db.storage
            .from("gallery")
            .createSignedUrl(i.storage_path, 600);
          if (error) throw new Error("Gallery image unavailable");
          return {
            id: i.id,
            caption: i.caption,
            url: data.signedUrl,
            credit: i.photographer_credit ?? "",
          };
        }),
      );
    }
  }
  return (
    <div className="container">
      <PageHeading eyebrow={eyebrow} title={title} description={description} />
      {!configured && (
        <p className="sample-note">
          Development preview. Verified club records will appear after setup and
          publication.
        </p>
      )}
      {section === "achievements" && !records.length ? (
        <div className="grid-3">
          {[
            "First Ride",
            "5 Rides",
            "10 Rides",
            "25 Rides",
            "Safe Rider",
            "Road Safety Workshop",
            "Ride Captain",
            "Explorer",
            "Long Distance",
            "Volunteer",
          ].map((name) => (
            <div className="panel" key={name}>
              <Badge tone="green">Milestone</Badge>
              <h3 style={{ marginTop: 20 }}>{name}</h3>
              <p>
                Recognized through verified club participation. No speed-based
                or competitive distance scoring.
              </p>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid-3">
          {records.map((r) => (
            <article className="panel" key={String(r.id)}>
              <h3>{String(r.title ?? r.name ?? r.display_name)}</h3>
              {r.role ? <Badge>{String(r.role)}</Badge> : null}
              <p style={{ marginTop: 15 }}>
                {String(r.description ?? r.responsibilities ?? "")}
              </p>
              {r.academic_year ? (
                <p>
                  Academic year {String(r.academic_year)} · {String(r.status)}
                </p>
              ) : null}
              {r.starts_at ? (
                <p>
                  {new Date(String(r.starts_at)).toLocaleString("en-IN", {
                    timeZone: "Asia/Kolkata",
                  })}{" "}
                  IST
                  <br />
                  {String(r.location)}
                </p>
              ) : null}
              {typeof r.website === "string" &&
                r.website.startsWith("https://") && (
                  <a
                    className="orange-text"
                    href={r.website}
                    target="_blank"
                    rel="noreferrer"
                  >
                    Visit partner ↗
                  </a>
                )}
            </article>
          ))}
        </div>
      )}
      {section === "gallery" && (
        <EditorialGallery
          photos={
            photos.length
              ? photos.map((p) => ({
                  id: p.id,
                  src: p.url,
                  alt: p.caption,
                  title: p.caption,
                  location: "Club gallery",
                  date: "Published club photograph",
                  credit: p.credit,
                }))
              : inspirationGallery
          }
        />
      )}
      {!records.length && section !== "achievements" && (
        <EmptyState
          title={
            section === "gallery"
              ? "The next memory is still ahead."
              : "No published records yet."
          }
        >
          The committee will add reviewed {section} content here.
        </EmptyState>
      )}
      {section === "gallery" && (
        <div className="photo-disclaimer">
          <p>
            {!photos.length
              ? "Representative photography, not actual MIT-WPU club rides."
              : ""}{" "}
            Image credits:{" "}
            {Object.values(media).map((m) => (
              <Link href={m.source} key={m.src} style={{ marginRight: 12 }}>
                {m.credit} / Unsplash
              </Link>
            ))}
          </p>
        </div>
      )}
    </div>
  );
}
