# MIT-WPU Riders Hub — portfolio preview

Independent student ride-management project. Not an official university or club service.

The public preview shows sample rides and clearly labelled fictional metrics. Account forms in this publication copy are disabled so the demo does not collect credentials. Production source for Supabase member approval, ride registration, safety completion, passes and check-in remains available for future configuration.

## Run

Node.js 22+. `npm ci`, `npm run build`, `npm run start -- --port 5183`; open http://localhost:5183.

## Checks and remaining setup

Build and lint passed. All six existing tests passed, including PostgreSQL RLS and the registration → safety → pass → check-in workflow. A real Supabase project, schema deployment, provider configuration and live integration tests are still required. The server uses Next.js; adapting it for Sites Workers hosting remains a separate step. Public deployment is pending.

Representative photo sources and attribution are documented in src/lib/media.ts. They are not photographs of real club rides.
