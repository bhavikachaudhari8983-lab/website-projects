-- Public aggregate only. No individual rider records leave this function.
create function public.club_statistics() returns jsonb language sql stable security definer set search_path=public as $$
select jsonb_build_object(
 'members',(select count(*) from club_memberships where status='active'),
 'rides',(select count(*) from rides where status='completed'),
 'km',(select coalesce(sum(r.distance_km),0) from ride_registrations rr join rides r on r.id=rr.ride_id where rr.status='completed'),
 'attendance',(select case when count(*)=0 then null else round(100.0*count(*) filter(where rr.status='completed')/count(*)) end from ride_registrations rr join rides r on r.id=rr.ride_id where r.status='completed' and rr.status in ('approved','checked_in','completed'))
) $$;
revoke all on function public.club_statistics() from public;
grant execute on function public.club_statistics() to anon,authenticated;
