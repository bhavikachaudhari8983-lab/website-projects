-- Private by default: public gallery access is mediated by approved database records.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values
('member-assets','member-assets',false,5242880,array['image/jpeg','image/png','image/webp']),
('gallery','gallery',false,8388608,array['image/jpeg','image/png','image/webp']) on conflict(id) do nothing;
create policy member_asset_read on storage.objects for select to authenticated using(bucket_id='member-assets' and (storage.foldername(name))[1]=auth.uid()::text);
create policy member_asset_insert on storage.objects for insert to authenticated with check(bucket_id='member-assets' and (storage.foldername(name))[1]=auth.uid()::text);
create policy gallery_asset_read on storage.objects for select using(bucket_id='gallery' and (public.is_admin() or exists(select 1 from public.gallery_images i join public.gallery_albums a on a.id=i.album_id where i.storage_path=name and i.approved and a.published)));
create policy gallery_asset_insert on storage.objects for insert to authenticated with check(bucket_id='gallery' and public.is_admin());
create policy gallery_asset_delete on storage.objects for delete to authenticated using(bucket_id='gallery' and public.is_admin());
