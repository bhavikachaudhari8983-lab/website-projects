-- Expose a captain's display name only, never their private profile columns.
create function public.ride_leader_names(rid uuid) returns jsonb language sql stable security definer set search_path=public as $$
select jsonb_build_object('captain',c.full_name,'sweep',s.full_name)
from rides r left join profiles c on c.id=r.captain_id left join profiles s on s.id=r.sweep_id
where r.id=rid and (participates(rid) or manages_ride(rid))
$$;
revoke all on function public.ride_leader_names(uuid) from public,anon;
grant execute on function public.ride_leader_names(uuid) to authenticated;
