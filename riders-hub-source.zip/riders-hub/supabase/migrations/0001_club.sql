-- Initial additive migration. Apply to a new Supabase project.
create extension if not exists pgcrypto;
create table public.profiles (
 id uuid primary key references auth.users(id) on delete cascade, full_name text not null check(length(full_name) between 2 and 100), email text not null,
 student_id text, phone text, program text, academic_year int check(academic_year between 1 and 8), experience text not null default 'beginner' check(experience in ('beginner','intermediate','experienced')),
 preferred_pace text not null default 'relaxed' check(preferred_pace in ('relaxed','steady')), emergency_contact text, emergency_relationship text, blood_group text, avatar_path text,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.roles (name text primary key check(name in ('member','captain','organizer','admin','super_admin')));
insert into public.roles values ('member'),('captain'),('organizer'),('admin'),('super_admin');
create table public.user_roles (user_id uuid references public.profiles on delete cascade, role text references public.roles, primary key(user_id,role), created_at timestamptz not null default now());
create table public.club_memberships (id uuid primary key default gen_random_uuid(), user_id uuid not null unique references public.profiles, membership_number text not null unique default ('RDR-' || upper(substr(replace(gen_random_uuid()::text,'-',''),1,10))), status text not null default 'pending' check(status in ('pending','active','suspended','alumni')), joined_at timestamptz default now(), created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table public.bikes (id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles, manufacturer text not null, model text not null, registration_identifier text not null, engine_cc int check(engine_cc between 1 and 3000), year int check(year between 1950 and 2100), category text not null default 'street', photo_path text, status text not null default 'active' check(status in ('active','inactive')), created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table public.rides (
 id uuid primary key default gen_random_uuid(), title text not null check(length(title) between 3 and 120), destination text not null, description text not null,
 cover_url text, ride_date date not null, assembly_time time not null, departure_time time not null, expected_return timestamptz, meeting_point text not null,
 latitude double precision check(latitude between -90 and 90), longitude double precision check(longitude between -180 and 180), route_info text not null default '', distance_km int not null check(distance_km between 1 and 3000), difficulty text not null check(difficulty in ('easy','moderate','challenging')),
 capacity int not null check(capacity between 1 and 500), minimum_experience text not null default 'beginner' check(minimum_experience in ('beginner','intermediate','experienced')), required_gear text not null, safety_instructions text not null,
 captain_id uuid references public.profiles, sweep_id uuid references public.profiles, organizer_id uuid references public.profiles, created_by uuid references public.profiles default auth.uid(),
 registration_opens timestamptz not null, registration_deadline timestamptz not null, status text not null default 'draft' check(status in ('draft','registration_open','registration_closed','upcoming','active','completed','cancelled')),
 created_at timestamptz not null default now(), updated_at timestamptz not null default now(), check(registration_deadline>registration_opens), check(departure_time>=assembly_time)
);
create table public.ride_registrations (id uuid primary key default gen_random_uuid(), ride_id uuid not null references public.rides, user_id uuid not null references public.profiles, status text not null default 'pending' check(status in ('pending','approved','waitlisted','rejected','cancelled','checked_in','completed')), created_at timestamptz not null default now(), updated_at timestamptz not null default now(), unique(ride_id,user_id), unique(id,ride_id), unique(id,user_id));
create table public.ride_groups (id uuid primary key default gen_random_uuid(), ride_id uuid not null references public.rides, name text not null, group_number int not null check(group_number>0), captain_id uuid references public.profiles, sweep_id uuid references public.profiles, capacity int not null default 8 check(capacity between 1 and 30), created_at timestamptz not null default now(), updated_at timestamptz not null default now(), unique(ride_id,group_number), unique(id,ride_id));
create table public.ride_group_members (registration_id uuid primary key, group_id uuid not null, ride_id uuid not null references public.rides, foreign key(registration_id,ride_id) references public.ride_registrations(id,ride_id), foreign key(group_id,ride_id) references public.ride_groups(id,ride_id), created_at timestamptz not null default now());
create table public.safety_checklists (registration_id uuid primary key references public.ride_registrations, checks jsonb not null default '{}', status text not null default 'not_started' check(status in ('not_started','self_checked','organizer_verified','action_required')), verified_by uuid references public.profiles, verified_at timestamptz, notes text, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table public.ride_passes (id uuid primary key default gen_random_uuid(), registration_id uuid not null unique references public.ride_registrations, token uuid not null unique default gen_random_uuid(), revoked_at timestamptz, expires_at timestamptz not null, created_at timestamptz not null default now());
create table public.ride_checkins (id uuid primary key default gen_random_uuid(), registration_id uuid not null unique references public.ride_registrations, checked_in_by uuid not null references public.profiles, checked_in_at timestamptz not null default now());
create table public.checkpoints (id uuid primary key default gen_random_uuid(), ride_id uuid not null references public.rides, name text not null, location text not null, latitude double precision check(latitude between -90 and 90), longitude double precision check(longitude between -180 and 180), expected_arrival timestamptz, sequence int not null check(sequence>0), status text not null default 'pending' check(status in ('pending','reached','skipped')), created_at timestamptz not null default now(), updated_at timestamptz not null default now(), unique(ride_id,sequence));
create table public.incidents (id uuid primary key default gen_random_uuid(), rider_id uuid not null references public.profiles default auth.uid(), ride_id uuid not null references public.rides, group_id uuid references public.ride_groups, type text not null check(type in ('puncture','mechanical','fuel','separated','minor','medical','emergency','other')), description text not null check(length(description) between 5 and 2000), location text, status text not null default 'open' check(status in ('open','acknowledged','resolved')), organizer_notes text, resolved_at timestamptz, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table public.announcements (id uuid primary key default gen_random_uuid(), title text not null, message text not null, audience text not null check(audience in ('all_members','ride','group','committee')), ride_id uuid references public.rides, group_id uuid references public.ride_groups, priority text not null default 'normal' check(priority in ('normal','important','urgent')), expires_at timestamptz, created_by uuid references public.profiles default auth.uid(), created_at timestamptz not null default now(), updated_at timestamptz not null default now(), check((audience='ride' and ride_id is not null and group_id is null) or (audience='group' and group_id is not null and ride_id is not null) or (audience in ('all_members','committee') and ride_id is null and group_id is null)));
create table public.events (id uuid primary key default gen_random_uuid(), title text not null, description text not null, type text not null, starts_at timestamptz not null, location text not null, published boolean not null default false, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table public.committee_members (id uuid primary key default gen_random_uuid(), member_id uuid not null references public.profiles, display_name text not null, role text not null, academic_year text not null, start_date date not null, end_date date, responsibilities text not null, status text not null default 'active' check(status in ('active','past')), published boolean not null default false, created_at timestamptz not null default now(), updated_at timestamptz not null default now(), check(end_date is null or end_date>=start_date));
create table public.achievements (id uuid primary key default gen_random_uuid(), name text not null unique, description text not null, icon text not null default 'shield', created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table public.user_achievements (id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles, achievement_id uuid not null references public.achievements, awarded_by uuid references public.profiles, awarded_at timestamptz not null default now(), unique(user_id,achievement_id));
create table public.gallery_albums (id uuid primary key default gen_random_uuid(), title text not null, ride_id uuid references public.rides, event_id uuid references public.events, published boolean not null default false, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table public.gallery_images (id uuid primary key default gen_random_uuid(), album_id uuid not null references public.gallery_albums, storage_path text not null, caption text not null, photographer_credit text, taken_on date, approved boolean not null default false, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table public.partners (id uuid primary key default gen_random_uuid(), name text not null, description text not null, website text, published boolean not null default false, created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table public.audit_logs (id bigint generated always as identity primary key, actor_id uuid references public.profiles, action text not null, entity_id uuid, created_at timestamptz not null default now());
create table public.rate_limits (key text primary key, window_start timestamptz not null default now(), hits int not null default 1);

create function public.has_role(allowed text[]) returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from user_roles where user_id=auth.uid() and role=any(allowed)) $$;
create function public.is_admin() returns boolean language sql stable security definer set search_path=public as $$ select has_role(array['admin','super_admin']) $$;
create function public.manages_ride(rid uuid) returns boolean language sql stable security definer set search_path=public as $$ select is_admin() or exists(select 1 from rides where id=rid and (has_role(array['organizer']) and auth.uid() in (organizer_id,created_by) or has_role(array['captain']) and auth.uid() in (captain_id,sweep_id))) $$;
create function public.owns_registration(reg uuid) returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from ride_registrations where id=reg and user_id=auth.uid()) $$;
create function public.manages_registration(reg uuid) returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from ride_registrations where id=reg and manages_ride(ride_id)) $$;
create function public.participates(rid uuid) returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from ride_registrations where ride_id=rid and user_id=auth.uid() and status in ('approved','checked_in','completed')) $$;
create function public.in_group(gid uuid) returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from ride_group_members gm join ride_registrations r on r.id=gm.registration_id where gm.group_id=gid and r.user_id=auth.uid() and r.status in ('approved','checked_in','completed')) $$;
create function public.can_view_member(uid uuid) returns boolean language sql stable security definer set search_path=public as $$ select uid=auth.uid() or is_admin() or exists(select 1 from ride_registrations where user_id=uid and status in ('pending','approved','waitlisted','checked_in') and manages_ride(ride_id)) $$;

-- Every exposed table has RLS. No general client write policy exists for sensitive transitions.
do $$ declare t text; begin foreach t in array array['profiles','roles','user_roles','club_memberships','bikes','rides','ride_registrations','ride_groups','ride_group_members','safety_checklists','ride_passes','ride_checkins','checkpoints','incidents','announcements','events','committee_members','achievements','user_achievements','gallery_albums','gallery_images','partners','audit_logs','rate_limits'] loop execute format('alter table public.%I enable row level security',t); end loop; end $$;
create policy profile_read on public.profiles for select to authenticated using(can_view_member(id));
create policy profile_update on public.profiles for update to authenticated using(id=auth.uid()) with check(id=auth.uid());
create policy role_read on public.roles for select to authenticated using(true);
create policy user_role_read on public.user_roles for select to authenticated using(user_id=auth.uid() or is_admin());
create policy membership_read on public.club_memberships for select to authenticated using(can_view_member(user_id));
create policy membership_manage on public.club_memberships for update to authenticated using(is_admin()) with check(is_admin());
create policy bike_read on public.bikes for select to authenticated using(can_view_member(user_id));
create policy bike_insert on public.bikes for insert to authenticated with check(user_id=auth.uid());
create policy bike_update on public.bikes for update to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy rides_read on public.rides for select using(status<>'draft' or manages_ride(id));
create policy rides_create on public.rides for insert to authenticated with check(has_role(array['organizer','admin','super_admin']) and created_by=auth.uid() and (is_admin() or organizer_id=auth.uid()) and status='draft');
create policy registration_read on public.ride_registrations for select to authenticated using(user_id=auth.uid() or manages_ride(ride_id));
create policy group_read on public.ride_groups for select to authenticated using(participates(ride_id) or manages_ride(ride_id));
create policy group_manage on public.ride_groups for insert to authenticated with check(manages_ride(ride_id));
create policy group_members_read on public.ride_group_members for select to authenticated using(owns_registration(registration_id) or manages_ride(ride_id));
create policy safety_read on public.safety_checklists for select to authenticated using(owns_registration(registration_id) or manages_registration(registration_id));
create policy pass_read on public.ride_passes for select to authenticated using(owns_registration(registration_id) or manages_registration(registration_id));
create policy checkin_read on public.ride_checkins for select to authenticated using(owns_registration(registration_id) or manages_registration(registration_id));
create policy checkpoint_read on public.checkpoints for select to authenticated using(participates(ride_id) or manages_ride(ride_id));
create policy checkpoint_insert on public.checkpoints for insert to authenticated with check(manages_ride(ride_id));
create policy checkpoint_update on public.checkpoints for update to authenticated using(manages_ride(ride_id)) with check(manages_ride(ride_id));
create policy incident_read on public.incidents for select to authenticated using(rider_id=auth.uid() or manages_ride(ride_id));
create policy incident_insert on public.incidents for insert to authenticated with check(rider_id=auth.uid() and participates(ride_id) and status='open' and organizer_notes is null and resolved_at is null and (group_id is null or exists(select 1 from ride_groups where id=group_id and ride_id=incidents.ride_id)));
create policy announcement_read on public.announcements for select to authenticated using((expires_at is null or expires_at>now()) and (is_admin() or audience='all_members' or audience='ride' and (participates(ride_id) or manages_ride(ride_id)) or audience='group' and (in_group(group_id) or manages_ride(ride_id)) or audience='committee' and exists(select 1 from committee_members where member_id=auth.uid() and status='active')));
create policy announcement_insert on public.announcements for insert to authenticated with check(created_by=auth.uid() and (is_admin() or audience in ('ride','group') and manages_ride(ride_id)) and (group_id is null or exists(select 1 from ride_groups where id=group_id and ride_id=announcements.ride_id)));
create policy achievements_read on public.achievements for select using(true);
create policy achievements_manage on public.achievements for all to authenticated using(is_admin()) with check(is_admin());
create policy award_read on public.user_achievements for select to authenticated using(user_id=auth.uid() or is_admin());
create policy award_manage on public.user_achievements for insert to authenticated with check(is_admin() and awarded_by=auth.uid());
create policy audit_read on public.audit_logs for select to authenticated using(is_admin());
do $$ declare t text; begin foreach t in array array['events','committee_members','gallery_albums','partners'] loop execute format('create policy public_read on public.%I for select using(published or public.is_admin())',t); execute format('create policy admin_manage on public.%I for all to authenticated using(public.is_admin()) with check(public.is_admin())',t); end loop; end $$;
create policy gallery_read on public.gallery_images for select using(is_admin() or approved and exists(select 1 from gallery_albums where id=album_id and published));
create policy gallery_manage on public.gallery_images for all to authenticated using(is_admin()) with check(is_admin());

create function public.on_signup() returns trigger language plpgsql security definer set search_path=public as $$ begin
 insert into profiles(id,full_name,email) values(new.id,coalesce(nullif(left(new.raw_user_meta_data->>'full_name',100),''),'New rider'),new.email);
 insert into user_roles values(new.id,'member',now()); insert into club_memberships(user_id) values(new.id); return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.on_signup();
create function public.touch_updated_at() returns trigger language plpgsql set search_path=public as $$ begin new.updated_at=now(); return new; end $$;
do $$ declare t text; begin foreach t in array array['profiles','club_memberships','bikes','rides','ride_registrations','ride_groups','safety_checklists','checkpoints','incidents','announcements','events','committee_members','achievements','gallery_albums','gallery_images','partners'] loop execute format('create trigger touch_updated_at before update on public.%I for each row execute function public.touch_updated_at()',t); end loop; end $$;

-- Distributed per-user limiter, invoked inside workflow transactions. No service key needed.
create function public.enforce_rate_limit(scope text, max_hits int default 30) returns void language plpgsql security definer set search_path=public as $$ declare n int; begin
 if auth.uid() is null then raise exception 'Sign in required'; end if;
 insert into rate_limits(key) values(auth.uid()::text || ':' || scope) on conflict(key) do update set hits=case when rate_limits.window_start<now()-interval '1 minute' then 1 else rate_limits.hits+1 end, window_start=case when rate_limits.window_start<now()-interval '1 minute' then now() else rate_limits.window_start end returning hits into n;
 if n>max_hits then raise exception 'Please wait a minute before trying again'; end if;
end $$;
create function public.register_for_ride(rid uuid) returns uuid language plpgsql security definer set search_path=public as $$ declare r rides; reg uuid; exp text; begin
 perform enforce_rate_limit('register'); select * into r from rides where id=rid for update;
 if r.id is null or r.status<>'registration_open' or now()<r.registration_opens or now()>r.registration_deadline then raise exception 'Registration is not open'; end if;
 if not exists(select 1 from club_memberships where user_id=auth.uid() and status='active') then raise exception 'An active membership is required'; end if;
 select experience into exp from profiles where id=auth.uid();
 if array_position(array['beginner','intermediate','experienced'],exp)<array_position(array['beginner','intermediate','experienced'],r.minimum_experience) then raise exception 'This ride requires more group riding experience'; end if;
 if not exists(select 1 from bikes where user_id=auth.uid() and status='active') then raise exception 'Add an active bike before applying'; end if;
 insert into ride_registrations(ride_id,user_id) values(rid,auth.uid()) returning id into reg;
 insert into safety_checklists(registration_id) values(reg); insert into audit_logs(actor_id,action,entity_id) values(auth.uid(),'registration.created',reg); return reg;
 exception when unique_violation then raise exception 'You have already applied for this ride';
end $$;
create function public.decide_registration(reg uuid, decision text) returns text language plpgsql security definer set search_path=public as $$ declare rr ride_registrations; r rides; result text; begin
 perform enforce_rate_limit('decision',60); select * into rr from ride_registrations where id=reg;
 if rr.id is null or not manages_ride(rr.ride_id) then raise exception 'Not authorized'; end if;
 select * into r from rides where id=rr.ride_id for update; select * into rr from ride_registrations where id=reg for update;
 if r.status in ('completed','cancelled','active') or rr.status in ('checked_in','completed','cancelled') then raise exception 'Registration cannot be changed now'; end if;
 if decision not in ('approved','rejected','waitlisted') then raise exception 'Invalid decision'; end if;
 result=decision;
 if decision='approved' then
 if not exists(select 1 from club_memberships where user_id=rr.user_id and status='active') then raise exception 'Membership is not active'; end if;
 if (select count(*) from ride_registrations where ride_id=r.id and id<>reg and status in ('approved','checked_in','completed'))>=r.capacity then result='waitlisted'; end if;
 end if;
 update ride_registrations set status=result where id=reg;
 if result<>'approved' then update ride_passes set revoked_at=now() where registration_id=reg; delete from ride_group_members where registration_id=reg; end if;
 insert into audit_logs(actor_id,action,entity_id) values(auth.uid(),'registration.'||result,reg); return result;
end $$;
create function public.cancel_registration(reg uuid) returns void language plpgsql security definer set search_path=public as $$ declare rr ride_registrations; r rides; begin
 perform enforce_rate_limit('cancel'); select * into rr from ride_registrations where id=reg;
 if rr.id is null or rr.user_id<>auth.uid() then raise exception 'Not authorized'; end if;
 select * into r from rides where id=rr.ride_id for update;
 select * into rr from ride_registrations where id=reg for update;
 if rr.status in ('checked_in','completed') or r.status in ('active','completed') then raise exception 'Contact your organizer to leave an active ride'; end if;
 update ride_registrations set status='cancelled' where id=reg; update ride_passes set revoked_at=now() where registration_id=reg; delete from ride_group_members where registration_id=reg;
 insert into audit_logs(actor_id,action,entity_id) values(auth.uid(),'registration.cancelled',reg);
end $$;
create function public.submit_safety(reg uuid, items jsonb) returns void language plpgsql security definer set search_path=public as $$ declare required text; rr ride_registrations; begin
 perform enforce_rate_limit('safety'); select * into rr from ride_registrations where id=reg for update;
 if rr.id is null or rr.user_id<>auth.uid() or rr.status not in ('pending','approved','waitlisted') then raise exception 'Checklist is unavailable'; end if;
 foreach required in array array['Helmet','Riding gear','Driving licence','Fuel','Tyres','Brakes','Lights','Emergency contact','Basic bike condition'] loop if (items->required) is distinct from 'true'::jsonb then raise exception 'Complete every safety check'; end if; end loop;
 if not exists(select 1 from profiles where id=auth.uid() and length(emergency_contact)>=5 and length(emergency_relationship)>=2) then raise exception 'Add an emergency contact to your profile'; end if;
 update safety_checklists set checks=items,status='self_checked',verified_by=null,verified_at=null,notes=null where registration_id=reg;
 update ride_passes set revoked_at=now() where registration_id=reg;
end $$;
create function public.verify_safety(reg uuid, passed boolean, note text default '') returns void language plpgsql security definer set search_path=public as $$ declare rr ride_registrations; begin
 perform enforce_rate_limit('verify',60); select * into rr from ride_registrations where id=reg for update;
 if rr.id is null or not manages_ride(rr.ride_id) or rr.status<>'approved' then raise exception 'Approved registration and organizer access required'; end if;
 if passed and not exists(select 1 from safety_checklists where registration_id=reg and status='self_checked') then raise exception 'Rider must complete self checks first'; end if;
 update safety_checklists set status=case when passed then 'organizer_verified' else 'action_required' end,verified_by=auth.uid(),verified_at=now(),notes=left(note,1000) where registration_id=reg;
 update ride_passes set revoked_at=now() where registration_id=reg;
 insert into audit_logs(actor_id,action,entity_id) values(auth.uid(),'safety.'||case when passed then 'verified' else 'failed' end,reg);
end $$;
create function public.issue_pass(reg uuid) returns uuid language plpgsql security definer set search_path=public as $$ declare rr ride_registrations; r rides; pid uuid; begin
 perform enforce_rate_limit('pass'); select * into rr from ride_registrations where id=reg for update;
 if rr.id is null or not (owns_registration(reg) or manages_registration(reg)) then raise exception 'Not authorized'; end if;
 select * into r from rides where id=rr.ride_id;
 if rr.status<>'approved' or r.status not in ('registration_open','registration_closed','upcoming','active') or r.ride_date<current_date or not exists(select 1 from safety_checklists where registration_id=reg and status='organizer_verified') or not exists(select 1 from club_memberships where user_id=rr.user_id and status='active') then raise exception 'Approval, active membership and verified safety are required'; end if;
 insert into ride_passes(registration_id,expires_at) values(reg,((r.ride_date+1)::timestamp at time zone 'Asia/Kolkata')) on conflict(registration_id) do update set token=case when ride_passes.revoked_at is not null then gen_random_uuid() else ride_passes.token end,revoked_at=null,expires_at=excluded.expires_at returning id into pid;
 return pid;
end $$;
create function public.check_in_pass(rid uuid, pass_token uuid) returns text language plpgsql security definer set search_path=public as $$ declare p ride_passes; rr ride_registrations; r rides; begin
 perform enforce_rate_limit('checkin',60);
 if not manages_ride(rid) then raise exception 'Not authorized'; end if;
 select * into r from rides where id=rid for update;
 select * into p from ride_passes where token=pass_token;
 if p.id is null or p.revoked_at is not null or p.expires_at<=now() then raise exception 'Invalid or expired pass'; end if;
 select * into rr from ride_registrations where id=p.registration_id for update;
 if rr.ride_id<>rid then raise exception 'This pass belongs to a different ride'; end if;
 if rr.status='checked_in' then return 'Already checked in'; end if;
 if rr.status<>'approved' or r.status not in ('upcoming','registration_closed','registration_open','active') or r.ride_date<>(now() at time zone 'Asia/Kolkata')::date or not exists(select 1 from safety_checklists where registration_id=rr.id and status='organizer_verified') or not exists(select 1 from club_memberships where user_id=rr.user_id and status='active') then raise exception 'Rider is not cleared for check-in today'; end if;
 insert into ride_checkins(registration_id,checked_in_by) values(rr.id,auth.uid()); update ride_registrations set status='checked_in' where id=rr.id;
 insert into audit_logs(actor_id,action,entity_id) values(auth.uid(),'rider.checked_in',rr.id); return 'Check-in successful';
end $$;
create function public.assign_group(reg uuid, gid uuid) returns void language plpgsql security definer set search_path=public as $$ declare rr ride_registrations; g ride_groups; begin
 perform enforce_rate_limit('group',60); select * into rr from ride_registrations where id=reg;
 if rr.id is null or not manages_ride(rr.ride_id) then raise exception 'Not authorized'; end if;
 perform 1 from rides where id=rr.ride_id for update; select * into rr from ride_registrations where id=reg for update; select * into g from ride_groups where id=gid for update;
 if g.id is null or g.ride_id<>rr.ride_id or rr.status not in ('approved','checked_in') then raise exception 'Group and approved rider must belong to the same ride'; end if;
 if (select count(*) from ride_group_members where group_id=gid and registration_id<>reg)>=g.capacity then raise exception 'Group is at capacity'; end if;
 insert into ride_group_members values(reg,gid,rr.ride_id,now()) on conflict(registration_id) do update set group_id=excluded.group_id;
 insert into audit_logs(actor_id,action,entity_id) values(auth.uid(),'group.assigned',reg);
end $$;
create function public.set_ride_status(rid uuid, next_status text) returns void language plpgsql security definer set search_path=public as $$ declare r rides; begin
 perform enforce_rate_limit('status'); if not manages_ride(rid) then raise exception 'Not authorized'; end if;
 select * into r from rides where id=rid for update;
 if not (r.status='draft' and next_status in ('registration_open','cancelled') or r.status='registration_open' and next_status in ('registration_closed','upcoming','cancelled') or r.status='registration_closed' and next_status in ('registration_open','upcoming','cancelled') or r.status='upcoming' and next_status in ('active','cancelled') or r.status='active' and next_status in ('completed','cancelled')) then raise exception 'Invalid ride status transition'; end if;
 update rides set status=next_status where id=rid;
 if next_status='completed' then update ride_registrations set status='completed' where ride_id=rid and status='checked_in'; end if;
 if next_status='cancelled' then update ride_registrations set status='cancelled' where ride_id=rid and status in ('pending','approved','waitlisted','checked_in'); end if;
 if next_status in ('completed','cancelled') then update ride_passes set revoked_at=now() where registration_id in (select id from ride_registrations where ride_id=rid); end if;
 insert into audit_logs(actor_id,action,entity_id) values(auth.uid(),'ride.'||next_status,rid);
end $$;
create function public.set_member_role(uid uuid, new_role text, enabled boolean) returns void language plpgsql security definer set search_path=public as $$ begin
 if not has_role(array['super_admin']) then raise exception 'Super admin required'; end if;
 if uid=auth.uid() and new_role='super_admin' and not enabled then raise exception 'You cannot remove your own super admin access'; end if;
 if enabled then insert into user_roles(user_id,role) values(uid,new_role) on conflict do nothing; else delete from user_roles where user_id=uid and role=new_role; end if;
 insert into audit_logs(actor_id,action,entity_id) values(auth.uid(),'role.'||new_role||'.'||enabled::text,uid);
end $$;
create function public.resolve_incident(iid uuid, new_status text, note text) returns void language plpgsql security definer set search_path=public as $$ declare i incidents; begin
 select * into i from incidents where id=iid for update; if i.id is null or not manages_ride(i.ride_id) then raise exception 'Not authorized'; end if;
 if new_status not in ('open','acknowledged','resolved') then raise exception 'Invalid status'; end if;
 update incidents set status=new_status,organizer_notes=left(note,2000),resolved_at=case when new_status='resolved' then now() else null end where id=iid;
 insert into audit_logs(actor_id,action,entity_id) values(auth.uid(),'incident.'||new_status,iid);
end $$;
create function public.ride_capacity(rid uuid) returns int language sql stable security definer set search_path=public as $$ select count(*)::int from ride_registrations where ride_id=rid and status in ('approved','checked_in','completed') and exists(select 1 from rides where id=rid and (status<>'draft' or manages_ride(rid))) $$;

-- Explicit grants keep privileged functions unavailable anonymously.
revoke all on all tables in schema public from anon,authenticated;
grant select on public.rides,public.events,public.committee_members,public.achievements,public.gallery_albums,public.gallery_images,public.partners to anon;
grant select,insert,update,delete on all tables in schema public to authenticated;
revoke all on public.rate_limits from anon,authenticated;
revoke insert,update,delete on public.audit_logs from authenticated;
revoke update on public.profiles from authenticated;
grant update(full_name,student_id,phone,program,academic_year,experience,preferred_pace,emergency_contact,emergency_relationship,blood_group,avatar_path) on public.profiles to authenticated;
revoke execute on all functions in schema public from public,anon;
grant execute on all functions in schema public to authenticated;
grant execute on function public.has_role(text[]), public.is_admin(), public.manages_ride(uuid),public.ride_capacity(uuid) to anon;
revoke execute on function public.on_signup(),public.touch_updated_at(),public.enforce_rate_limit(text,int) from authenticated;

create index rides_date_status on public.rides(ride_date,status);
create index registrations_ride_status on public.ride_registrations(ride_id,status);
create index registrations_user on public.ride_registrations(user_id);
create index bikes_user on public.bikes(user_id);
create index groups_ride on public.ride_groups(ride_id);
create index group_members_group on public.ride_group_members(group_id);
create index incidents_ride_status on public.incidents(ride_id,status);
create index announcements_audience on public.announcements(audience,ride_id,expires_at);
create index checkpoints_ride on public.checkpoints(ride_id,sequence);
create index awards_user on public.user_achievements(user_id);
create index gallery_images_album on public.gallery_images(album_id);
create index committee_year on public.committee_members(academic_year);
create index audit_created on public.audit_logs(created_at);
