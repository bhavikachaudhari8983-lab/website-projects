# MIT-WPU Riders Hub implementation plan

## Architecture

- Next.js App Router: public pages, protected member workspace, protected organizer workspace.
- React + TypeScript + Tailwind: reusable accessible interface and explicit domain types.
- Supabase Auth: verified identity in secure cookie sessions; roles come from database records.
- PostgreSQL: normalized records, RLS on every table, transactional RPCs for capacity and check-in.
- Supabase Storage: private member assets and moderated public gallery assets.
- Mapbox: optional route map using public restricted token; textual route remains available.
- Vercel: deployment target. Brand strings live in `src/lib/config.ts`.

## Delivery sequence

1. Inspect and isolate project; establish this plan, README and app foundation.
2. Design tokens, layout, public home and ride catalogue; run initial preview.
3. Database, seed data, RLS, authentication and protected routes.
4. Rider profile, bikes, registration, approval, safety, passes and check-in.
5. Groups, checkpoints, announcements, incidents and operations.
6. Public content, gallery, committee, admin records and analytics.
7. Domain and database tests, security review, lint, types, production build, browser checks.

## Permission boundaries

Visitors read only published club content. Members access their own private records. Captains operate only assigned rides. Organizers operate rides assigned to them or created by them. Club admins manage club records; only super admins grant privileged roles. No client-supplied role is trusted. Safety and attendance write paths use database functions to keep related updates atomic.

## Runtime modes

Without Supabase environment variables, public pages show clearly labelled fictional development content. Authentication and all writes fail closed. No demo identity can access live member/admin records. Connected mode uses Supabase, with no fallback masking database errors.

## Verification boundaries

Database and authentication integration checks require a Supabase project (or a local PostgreSQL test instance). Unit tests alone cannot establish deployed RLS correctness. Production launch also requires email delivery, storage, redirect/domain configuration and Vercel environment values.
