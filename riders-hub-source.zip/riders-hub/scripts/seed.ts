import { createClient } from "@supabase/supabase-js";
import { randomBytes } from "node:crypto";
import { sampleRides } from "../src/lib/seed-data";
// Explicit opt-in prevents accidentally adding fictional accounts to a real club.
if (process.env.ALLOW_DEVELOPMENT_SEED !== "true")
  throw new Error(
    "Set ALLOW_DEVELOPMENT_SEED=true only for a development Supabase project.",
  );
const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!url || !key)
  throw new Error("Development Supabase URL and service role key required.");
const db = createClient(url, key, { auth: { persistSession: false } });
const ensure = (error: { message: string } | null) => {
  if (error) throw new Error(error.message);
};
const { data: existing, error: usersError } = await db.auth.admin.listUsers();
ensure(usersError);
const people = [
  ["Aarav Demo", "aarav@riders.example.test", "member"],
  ["Mira Demo", "mira@riders.example.test", "member"],
  ["Captain Demo", "captain@riders.example.test", "captain"],
  ["Admin Demo", "admin@riders.example.test", "super_admin"],
];
const ids: string[] = [];
for (const [full_name, email, role] of people) {
  let id = existing?.users.find((u) => u.email === email)?.id;
  if (!id) {
    const { data, error } = await db.auth.admin.createUser({
      email,
      password: randomBytes(30).toString("base64url"),
      email_confirm: true,
      user_metadata: { full_name },
    });
    ensure(error);
    id = data.user!.id;
  }
  ids.push(id);
  ensure(
    (
      await db
        .from("user_roles")
        .upsert({ user_id: id, role }, { onConflict: "user_id,role" })
    ).error,
  );
  ensure(
    (
      await db
        .from("club_memberships")
        .update({ status: "active" })
        .eq("user_id", id)
    ).error,
  );
  ensure(
    (
      await db
        .from("profiles")
        .update({
          program: "Demo engineering program",
          academic_year: 2,
          emergency_contact: "0000000000",
          emergency_relationship: "Fictional contact",
        })
        .eq("id", id)
    ).error,
  );
  const { count, error } = await db
    .from("bikes")
    .select("id", { count: "exact", head: true })
    .eq("user_id", id);
  ensure(error);
  if (!count)
    ensure(
      (
        await db
          .from("bikes")
          .insert({
            user_id: id,
            manufacturer: "Royal Enfield",
            model: "Himalayan",
            registration_identifier: `DEMO-${role}-${ids.length}`,
            engine_cc: 450,
            year: 2025,
            category: "adventure",
          })
      ).error,
    );
}
for (const r of sampleRides)
  ensure(
    (
      await db
        .from("rides")
        .upsert({
          ...r,
          created_by: ids[3],
          organizer_id: ids[3],
          captain_id: ids[2],
        })
    ).error,
  );
ensure(
  (
    await db.from("achievements").upsert(
      [
        "First Ride",
        "5 Rides",
        "10 Rides",
        "25 Rides",
        "Safe Rider",
        "Road Safety Workshop",
        "Ride Captain",
        "Explorer",
        "Long Distance",
        "Volunteer",
      ].map((name) => ({
        name,
        description:
          "Verified participation and responsible club contribution. No speed-based competition.",
      })),
      { onConflict: "name" },
    )
  ).error,
);
const { data: events } = await db
  .from("events")
  .select("id")
  .eq("title", "Sample: Road-safety workshop");
if (!events?.length)
  ensure(
    (
      await db
        .from("events")
        .insert({
          title: "Sample: Road-safety workshop",
          description:
            "Fictional development event covering preparation and group discipline.",
          type: "road-safety workshop",
          starts_at: "2026-10-10T10:00:00+05:30",
          location: "Sample campus venue",
          published: true,
        })
    ).error,
  );
ensure(
  (
    await db
      .from("ride_groups")
      .upsert(
        {
          ride_id: sampleRides[0].id,
          name: "Sahyadri A",
          group_number: 1,
          captain_id: ids[2],
          capacity: 8,
        },
        { onConflict: "ride_id,group_number" },
      )
  ).error,
);
console.log(
  "Development records seeded. No passwords or keys were printed. Set a demo account password through the Supabase dashboard if you need to sign in.",
);
