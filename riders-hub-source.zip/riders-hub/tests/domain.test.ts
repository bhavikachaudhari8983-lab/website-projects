import test from "node:test";
import assert from "node:assert/strict";
import { safeNext, profileSchema, rideSchema } from "../src/lib/validators";
import { summarize } from "../src/lib/analytics";
test("authentication redirects cannot escape the application", () => {
  for (const input of [
    "https://evil.test",
    "//evil.test",
    "/\\evil.test",
    null,
  ])
    assert.equal(safeNext(input), "/dashboard");
  assert.equal(safeNext("/reset-password"), "/reset-password");
});
test("profile validation rejects invalid experience and student year", () => {
  assert.equal(
    profileSchema.safeParse({
      full_name: "Test Rider",
      academic_year: 12,
      experience: "racer",
      preferred_pace: "relaxed",
      blood_group: "",
    }).success,
    false,
  );
});
test("analytics use actual completed rides and preserve absence in denominator", () => {
  const s = summarize(
    [
      { ride_id: "a", status: "completed" },
      { ride_id: "a", status: "approved" },
      { ride_id: "b", status: "approved" },
    ],
    [
      { id: "a", distance_km: 160, status: "completed" },
      { id: "b", distance_km: 130, status: "upcoming" },
    ],
    [{ status: "organizer_verified" }, { status: "self_checked" }],
  );
  assert.equal(s.clubKm, 160);
  assert.equal(s.attendance, 50);
  assert.equal(s.safety, 50);
  assert.equal(s.completedRides, 1);
});
test("empty analytics distinguish unavailable percentages from zero", () => {
  const s = summarize([], [], []);
  assert.equal(s.attendance, null);
  assert.equal(s.safety, null);
  assert.equal(s.clubKm, 0);
});
test("ride validation rejects unsafe malformed creation values", () => {
  assert.equal(
    rideSchema.safeParse({ title: "x", capacity: -5 }).success,
    false,
  );
});
