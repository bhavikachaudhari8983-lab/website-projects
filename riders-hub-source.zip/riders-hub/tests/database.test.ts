import { PGlite } from "@electric-sql/pglite";
import { readFileSync } from "node:fs";
import test from "node:test";
import assert from "node:assert/strict";
const ids = {
  member: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
  other: "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb",
  admin: "cccccccc-cccc-4ccc-8ccc-cccccccccccc",
  ride: "dddddddd-dddd-4ddd-8ddd-dddddddddddd",
};
async function database() {
  const db = new PGlite();
  await db.exec(
    `create role anon; create role authenticated; create schema auth; create table auth.users(id uuid primary key,email text,raw_user_meta_data jsonb default '{}'); create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid $$; grant usage on schema auth to anon,authenticated; grant execute on function auth.uid() to anon,authenticated;`,
  );
  await db.exec(
    readFileSync("supabase/migrations/0001_club.sql", "utf8").replace(
      "create extension if not exists pgcrypto;",
      "",
    ),
  );
  return db;
}
async function asUser(db: PGlite, id: string) {
  await db.exec(
    `reset role; select set_config('request.jwt.claim.sub','${id}',false); set role authenticated;`,
  );
}
test("PostgreSQL RLS and complete registration → safety → pass → check-in workflow", async () => {
  const db = await database();
  try {
    for (const [name, id] of Object.entries(ids).filter(([k]) => k !== "ride"))
      await db.query(
        `insert into auth.users(id,email,raw_user_meta_data) values($1,$2,$3)`,
        [
          id,
          `${name}@example.test`,
          JSON.stringify({ full_name: `Test ${name}` }),
        ],
      );
    await db.exec(
      `insert into user_roles(user_id,role) values('${ids.admin}','super_admin'); update club_memberships set status='active'; update profiles set emergency_contact='0000000000',emergency_relationship='Test parent'; insert into bikes(user_id,manufacturer,model,registration_identifier) values('${ids.member}','Test','Bike','TEST-1'),('${ids.other}','Test','Bike','TEST-2'); insert into rides(id,title,destination,description,ride_date,assembly_time,departure_time,meeting_point,distance_km,difficulty,capacity,required_gear,safety_instructions,registration_opens,registration_deadline,status) values('${ids.ride}','Test ride','Test','Test route',(now() at time zone 'Asia/Kolkata')::date,'06:00','06:30','Gate',100,'easy',1,'Helmet','Briefing',now()-interval '1 day',now()+interval '1 day','registration_open');`,
    );
    await asUser(db, ids.member);
    const privacy = await db.query("select id from profiles");
    assert.equal(privacy.rows.length, 1, "Members cannot read other profiles");
    await assert.rejects(
      db.exec(
        `insert into user_roles(user_id,role) values('${ids.member}','admin')`,
      ),
      /row-level security/,
    );
    await assert.rejects(
      db.exec(`select set_member_role('${ids.member}','admin',true)`),
      /Super admin required/,
    );
    const reg = (
      await db.query<{ id: string }>(
        `select register_for_ride('${ids.ride}') as id`,
      )
    ).rows[0].id;
    await assert.rejects(
      db.exec(`select register_for_ride('${ids.ride}')`),
      /already applied/,
    );
    await assert.rejects(
      db.exec(`select decide_registration('${reg}','approved')`),
      /Not authorized/,
    );
    await assert.rejects(db.exec(`select issue_pass('${reg}')`), /Approval/);
    await asUser(db, ids.other);
    const reg2 = (
      await db.query<{ id: string }>(
        `select register_for_ride('${ids.ride}') as id`,
      )
    ).rows[0].id;
    assert.equal(
      (await db.query(`select * from ride_registrations where id='${reg}'`))
        .rows.length,
      0,
    );
    await asUser(db, ids.admin);
    assert.equal(
      (
        await db.query<{ s: string }>(
          `select decide_registration('${reg}','approved') s`,
        )
      ).rows[0].s,
      "approved",
    );
    assert.equal(
      (
        await db.query<{ s: string }>(
          `select decide_registration('${reg2}','approved') s`,
        )
      ).rows[0].s,
      "waitlisted",
    );
    await asUser(db, ids.member);
    await assert.rejects(
      db.exec(`select submit_safety('${reg}','{}')`),
      /Complete every/,
    );
    const items = Object.fromEntries(
      [
        "Helmet",
        "Riding gear",
        "Driving licence",
        "Fuel",
        "Tyres",
        "Brakes",
        "Lights",
        "Emergency contact",
        "Basic bike condition",
      ].map((x) => [x, true]),
    );
    await db.query("select submit_safety($1,$2)", [reg, JSON.stringify(items)]);
    await assert.rejects(
      db.exec(`select verify_safety('${reg}',true,'')`),
      /organizer access/,
    );
    await asUser(db, ids.admin);
    await db.exec(`select verify_safety('${reg}',true,'Checked at assembly')`);
    await asUser(db, ids.member);
    await db.exec(`select issue_pass('${reg}')`);
    const token = (
      await db.query<{ token: string }>(
        `select token from ride_passes where registration_id='${reg}'`,
      )
    ).rows[0].token;
    await assert.rejects(
      db.exec(`select check_in_pass('${ids.ride}','${token}')`),
      /Not authorized/,
    );
    await asUser(db, ids.admin);
    await assert.rejects(
      db.exec(
        `select check_in_pass('${ids.ride}','eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee')`,
      ),
      /Invalid/,
    );
    assert.equal(
      (
        await db.query<{ s: string }>(
          `select check_in_pass('${ids.ride}','${token}') s`,
        )
      ).rows[0].s,
      "Check-in successful",
    );
    assert.equal(
      (
        await db.query<{ s: string }>(
          `select check_in_pass('${ids.ride}','${token}') s`,
        )
      ).rows[0].s,
      "Already checked in",
    );
    await db.exec(
      `select set_ride_status('${ids.ride}','upcoming'); select set_ride_status('${ids.ride}','active'); select set_ride_status('${ids.ride}','completed');`,
    );
    assert.equal(
      (
        await db.query<{ status: string }>(
          `select status from ride_registrations where id='${reg}'`,
        )
      ).rows[0].status,
      "completed",
    );
    await db.exec("reset role; set role anon;");
    assert.equal((await db.query("select title from rides")).rows.length, 1);
    await assert.rejects(
      db.exec("select * from profiles"),
      /permission denied/,
    );
  } finally {
    await db.close();
  }
});
