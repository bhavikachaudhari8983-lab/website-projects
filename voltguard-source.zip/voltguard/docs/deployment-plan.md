# VoltGuard deployment plan

## Phase 0: room survey

Map the room's distribution board with a licensed electrician. Confirm whether the geyser or AC has a dedicated circuit and identify the appliance's normal restart behaviour. Record the appliance rating, existing breaker, room layout, sensor locations, and any moving sources such as ceiling fans or curtains.

## Phase 1: 14-day observation pilot

Install only sensing, local logging, and a separately installed energy meter. Do not control mains power. Tune radar distance gates in an empty room and then evaluate normal sleeping, studying, showering, leaving, returning, fans, curtains, and shared-room use.

Measure:

- appliance kWh and active time
- number of vacancy-eligible events
- sensor faults and reboots
- manual reports of incorrect vacancy decisions
- installation time and support effort

## Phase 2: supervised one-appliance trial

After Phase 1 acceptance, a qualified professional installs a reviewed switching interface on one separately protected appliance circuit. Start with a conservative vacancy delay and maintain a physical service/bypass option. Review every automatic event with the hostel manager and pilot residents.

## Phase 3: 10-room paid evaluation

Deploy only in rooms with successful circuit surveys. Compare metered energy against a defined baseline method, accounting for occupancy and weather where relevant for AC use. Track installation cost, maintenance, customer complaints, and bypass events alongside energy results.

## Commercial validation

Treat the following as hypotheses rather than launch claims until the pilot produces evidence:

| Input | Current hypothesis | Evidence needed |
|---|---:|---|
| Hardware BOM | ₹880 per room | supplier quotations and manufacturing yield |
| Monthly gross saving | ₹800–₹1,400 per room | metered baseline versus pilot results |
| Upfront price | ₹1,499 | installed cost, warranty cost, and margin |
| Subscription | ₹39 or ₹99 per room/month | support cost and buyer willingness |

For example, at ₹800 gross savings and ₹39 monthly service, the owner retains ₹761 per month. At ₹1,400 gross savings, the owner retains ₹1,361 per month. The upfront ₹1,499 price therefore recovers in roughly 59 to 33 days before installation and support costs. These are arithmetic illustrations, not guarantees.
