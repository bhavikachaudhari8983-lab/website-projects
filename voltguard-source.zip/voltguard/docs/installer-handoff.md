# Installer and electrical-engineering handoff

This document intentionally does not include a mains wiring diagram. The pilot controller is low voltage only. A licensed electrician and an electrical engineer must own the final 230 V design and installation.

## Required survey information

| Item | Record |
|---|---|
| Room and board identifier |  |
| Selected appliance | geyser / AC / other |
| Dedicated circuit confirmed | yes / no |
| Existing breaker and cable details |  |
| Appliance nameplate data |  |
| Appliance restart restrictions |  |
| Earthing status |  |
| Enclosure location and available DIN space |  |
| Bypass and service procedure |  |
| Resident consent and contact process |  |

## Design questions for the engineer

1. What switching device and utilisation rating suits this specific load and duty cycle?
2. What protective device coordination, isolation, earth continuity, wire sizing, terminals, and enclosure are required?
3. How will the appliance avoid unsafe or damaging restart behavior after interruption?
4. What conditions force the system to preserve appliance availability?
5. What acceptance tests must pass before the room enters a controlled trial?

## Commissioning criteria

The electrician must test bypass behavior, existing protection, supply isolation, earth continuity, enclosure closure, control-interface isolation, and appliance normal operation. The project team must separately confirm sensor placement, observation-log review, event timestamps, and fault behavior.
