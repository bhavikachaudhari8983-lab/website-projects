# VoltGuard system architecture

## Purpose

VoltGuard uses local sensor evidence to identify likely vacancy and reduce avoidable operation of one selected high-load appliance. It does not observe people with cameras or microphones.

```mermaid
flowchart LR
  R[Bedroom mmWave radar] --> C[ESP32 decision controller]
  B[Bathroom activity sensor] --> C
  D[Door contact] --> C
  M[Energy-meter pulse output] --> C
  C --> L[Local event log]
  C --> H[Optional owner dashboard]
  C -. approved low-voltage control signal .-> I[Certified appliance switching interface]
  I --> A[Dedicated geyser or AC circuit]
  S[Manual bypass and existing protection] --> A
```

## Decision model

The controller uses a conservative state machine.

```mermaid
stateDiagram-v2
  [*] --> OBSERVE
  OBSERVE --> OCCUPIED: bedroom presence or bathroom activity
  OCCUPIED --> SUSPECTED_VACANT: no evidence for vacancy delay
  SUSPECTED_VACANT --> OCCUPIED: any presence, bathroom activity, or door event
  SUSPECTED_VACANT --> VACANT_ELIGIBLE: delay expires and controller is healthy
  VACANT_ELIGIBLE --> OCCUPIED: any activity
  VACANT_ELIGIBLE --> FAULT_HOLD: sensor or controller fault
  FAULT_HOLD --> OCCUPIED: health restored with activity
  FAULT_HOLD --> OBSERVE: health restored with no activity
```

In observation mode, `VACANT_ELIGIBLE` creates a log event only. In a later controlled pilot, it may request power removal from a qualified, separately engineered switching interface. A sensor fault, uncertain signal, reboot, or missing configuration must leave the control output inactive. The current radar GPIO output does not expose a heartbeat, so the controlled version must add UART health polling or an equivalent health signal.

## Why each component exists

| Component | Use |
|---|---|
| mmWave radar | Detects bedroom movement and stationary presence evidence. It needs per-room calibration. |
| Bathroom activity sensor | Extends the grace period after recent bathroom movement. It does not prove continuous bathroom occupancy. |
| Door contact | Provides context for a departure or return. It cannot establish vacancy by itself. |
| Energy meter | Records actual appliance energy through an isolated pulse interface. This supports the baseline and savings calculation. |
| ESP32 | Runs local logic, logging, watchdog recovery, and output interlock without Wi-Fi. |
| Certified switching interface | Receives an isolated low-voltage request to control a separately protected appliance circuit. |
| Physical bypass | Allows a qualified installer to restore normal appliance availability during service. |

## Electrical boundary

The low-voltage controller and the mains switching assembly must remain separate design responsibilities. A final design needs an appliance-specific load rating, fault protection, enclosure assessment, thermal design, earth continuity, isolation, surge strategy, emergency/bypass behavior, and commissioning tests. A generic relay current rating, MOV, or snubber alone does not prove suitability for an AC compressor.

For a future controlled pilot, the low-voltage sensor interface must drive `SENSOR_HEALTH_PIN` low on a detected sensor, wiring, or sensor-power fault. The controller enters `FAULT_HOLD` and keeps the appliance control request inactive. The observation firmware counts energy-meter pulses on a falling-edge interrupt, preventing a long pulse from being counted repeatedly.

## Data and privacy

Store the minimum operational data needed for the pilot: timestamp, sensor-health state, decision state, energy reading, override state, and controller faults. The owner dashboard should show aggregate energy and equipment health; it should not expose an individual student's movement or sleep history.

## Acceptance criteria for a controlled pilot

1. A qualified installer confirms the appliance has a separate circuit and the switching interface is suitable.
2. The observation period records no unexplained vacancy decisions during known occupancy.
3. The system preserves appliance availability on a sensor fault, restart, or missing configuration.
4. Metered kWh supports the reported baseline and savings method.
5. Student complaints and manual bypass use are reviewed before expansion.
