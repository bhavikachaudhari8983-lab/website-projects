/*
  VoltGuard observation-mode controller
  Target: ESP32-WROOM-32E

  This sketch uses only low-voltage sensor inputs. ACTUATOR_PIN remains LOW
  unless CONTROL_PILOT_ENABLED is explicitly set after an engineer-reviewed,
  separately certified appliance interface has been installed.
*/

#include <Preferences.h>
#include <esp_task_wdt.h>
#include <esp_idf_version.h>

constexpr uint8_t BEDROOM_PRESENCE_PIN = 34;   // 3.3 V GPIO output from radar interface
constexpr uint8_t BATHROOM_ACTIVITY_PIN = 35;  // 3.3 V conditioned sensor output
constexpr uint8_t DOOR_CONTACT_PIN = 27;       // INPUT_PULLUP, closed door = LOW
constexpr uint8_t METER_PULSE_PIN = 26;        // isolated pulse interface only
constexpr uint8_t SENSOR_HEALTH_PIN = 33;      // HIGH = low-voltage sensor interface healthy
constexpr uint8_t ACTUATOR_PIN = 25;           // low-voltage request to certified interface

constexpr bool CONTROL_PILOT_ENABLED = false;
constexpr uint32_t VACANCY_DELAY_MS = 12UL * 60UL * 1000UL;
constexpr uint32_t BATHROOM_GRACE_MS = 5UL * 60UL * 1000UL;
constexpr uint32_t DEBOUNCE_MS = 80;
constexpr uint32_t PULSES_PER_KWH = 1000;      // Set to the installed meter's stated value.
constexpr uint32_t MIN_METER_PULSE_GAP_US = 5000;

enum class RoomState { OBSERVE, OCCUPIED, SUSPECTED_VACANT, VACANT_ELIGIBLE, FAULT_HOLD };

Preferences store;
RoomState state = RoomState::OBSERVE;
uint32_t lastBedroomEvidence = 0;
uint32_t lastBathroomEvidence = 0;
uint32_t lastDoorChange = 0;
volatile uint32_t meterPulseCount = 0;
volatile uint32_t lastMeterPulseUs = 0;
portMUX_TYPE meterMux = portMUX_INITIALIZER_UNLOCKED;
bool previousDoor = true;

void IRAM_ATTR onMeterPulse() {
  const uint32_t nowUs = micros();
  portENTER_CRITICAL_ISR(&meterMux);
  if (nowUs - lastMeterPulseUs >= MIN_METER_PULSE_GAP_US) {
    ++meterPulseCount;
    lastMeterPulseUs = nowUs;
  }
  portEXIT_CRITICAL_ISR(&meterMux);
}

uint32_t readMeterPulseCount() {
  portENTER_CRITICAL(&meterMux);
  const uint32_t count = meterPulseCount;
  portEXIT_CRITICAL(&meterMux);
  return count;
}

void configureWatchdog() {
#if ESP_IDF_VERSION_MAJOR >= 5
  esp_task_wdt_config_t config;
  config.timeout_ms = 5000;
  config.idle_core_mask = 0;
  config.trigger_panic = true;
  esp_task_wdt_init(&config);
#else
  esp_task_wdt_init(5, true);
#endif
  esp_task_wdt_add(NULL);
}

bool readDebounced(uint8_t pin, bool &lastStable, uint32_t &lastChanged) {
  bool current = digitalRead(pin);
  if (current != lastStable && millis() - lastChanged > DEBOUNCE_MS) {
    lastStable = current;
    lastChanged = millis();
  }
  return lastStable;
}

const char* stateName(RoomState value) {
  switch (value) {
    case RoomState::OBSERVE: return "OBSERVE";
    case RoomState::OCCUPIED: return "OCCUPIED";
    case RoomState::SUSPECTED_VACANT: return "SUSPECTED_VACANT";
    case RoomState::VACANT_ELIGIBLE: return "VACANT_ELIGIBLE";
    case RoomState::FAULT_HOLD: return "FAULT_HOLD";
  }
  return "UNKNOWN";
}

void setState(RoomState next, const char* reason) {
  if (next == state) return;
  state = next;
  Serial.printf("event=state state=%s reason=%s ms=%lu pulses=%lu\n",
                stateName(state), reason, millis(), readMeterPulseCount());
  store.putUInt("pulses", readMeterPulseCount());
}

void applyActuatorInterlock() {
  // Fail-safe default: deassert control request on every loop unless the
  // supervised control pilot was deliberately compiled in.
  bool requestShutdown = CONTROL_PILOT_ENABLED && state == RoomState::VACANT_ELIGIBLE;
  digitalWrite(ACTUATOR_PIN, requestShutdown ? HIGH : LOW);
}

void setup() {
  Serial.begin(115200);
  pinMode(BEDROOM_PRESENCE_PIN, INPUT);
  pinMode(BATHROOM_ACTIVITY_PIN, INPUT);
  pinMode(DOOR_CONTACT_PIN, INPUT_PULLUP);
  pinMode(METER_PULSE_PIN, INPUT_PULLUP);
  pinMode(SENSOR_HEALTH_PIN, INPUT_PULLUP);
  pinMode(ACTUATOR_PIN, OUTPUT);
  digitalWrite(ACTUATOR_PIN, LOW);

  store.begin("voltguard", false);
  meterPulseCount = store.getUInt("pulses", 0);
  attachInterrupt(digitalPinToInterrupt(METER_PULSE_PIN), onMeterPulse, FALLING);
  previousDoor = digitalRead(DOOR_CONTACT_PIN);
  lastDoorChange = lastBedroomEvidence = lastBathroomEvidence = millis();

  configureWatchdog();
  Serial.println("VoltGuard observation mode started");
}

void loop() {
  const uint32_t now = millis();
  const bool bedroomPresent = digitalRead(BEDROOM_PRESENCE_PIN) == HIGH;
  const bool bathroomActive = digitalRead(BATHROOM_ACTIVITY_PIN) == HIGH;
  const bool doorOpen = readDebounced(DOOR_CONTACT_PIN, previousDoor, lastDoorChange) == HIGH;

  if (bedroomPresent) lastBedroomEvidence = now;
  if (bathroomActive) lastBathroomEvidence = now;
  const bool recentBathroom = now - lastBathroomEvidence < BATHROOM_GRACE_MS;
  const bool recentBedroom = now - lastBedroomEvidence < VACANCY_DELAY_MS;
  // SENSOR_HEALTH_PIN must be driven LOW by the low-voltage sensor interface
  // on detected wiring, power, or radar-health failure. Until such an
  // interface is installed, CONTROL_PILOT_ENABLED must remain false.
  const bool controllerHealthy = digitalRead(SENSOR_HEALTH_PIN) == HIGH;

  if (!controllerHealthy) {
    setState(RoomState::FAULT_HOLD, "controller_health_failed");
  } else if (bedroomPresent || bathroomActive || doorOpen || recentBathroom) {
    setState(RoomState::OCCUPIED, "presence_or_activity");
  } else if (recentBedroom) {
    setState(RoomState::SUSPECTED_VACANT, "vacancy_delay_running");
  } else {
    setState(RoomState::VACANT_ELIGIBLE, "conservative_delay_elapsed");
  }

  applyActuatorInterlock();
  static uint32_t lastPersistMs = 0;
  if (now - lastPersistMs >= 60000) {
    store.putUInt("pulses", readMeterPulseCount());
    lastPersistMs = now;
  }
  esp_task_wdt_reset();
  delay(100);
}
