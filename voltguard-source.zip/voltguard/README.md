# VoltGuard

Observation-mode energy-management prototype and interactive dashboard demo. All dashboard readings are fictional; no completed pilot or measured savings are claimed.

Open dist/index.html to explore the dashboard. Firmware and design notes are in firmware/ and docs/. Electrical deployment requires qualified installation and a real metered pilot. The demo never controls hardware.
