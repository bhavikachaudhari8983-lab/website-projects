import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL("https://bhavikachaudhari.com"),
  title: {
    default: "Bhavika Chaudhari",
    template: "%s | Bhavika Chaudhari",
  },
  description: "The personal website of Bhavika Chaudhari.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
