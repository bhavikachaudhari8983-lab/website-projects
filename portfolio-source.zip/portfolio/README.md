# Bhavika's project portfolio

A responsive project index built from the existing personal-site foundation. Completed work, concepts and ongoing projects have explicit labels. Expense tracker and Pro-Karters are excluded from this batch.

Node.js 22+. `npm ci`, `npm run build`, then `npm run start -- --port 5184`; open http://localhost:5184.

Build and lint passed. This is a Next.js server project, with public hosting adaptation and demo links still pending. The domain bhavikachaudhari.com is not claimed to have been connected in this task.
